package com.rafiq6.study

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

// ===== مولّد الجدول المحلي =====
// منطق نقي 100% (بدون Android) يحوّل مسودة المعالج إلى ملف rafiq_schedule v1 فعلي.
// لا يخترع أرقام محاضرات ولا مددًا ولا أوقاتًا: أي معلومة ناقصة تُرجَع في missingInputs ويتوقف التوليد.

data class GenSubjectSummary(
    val subject: String,
    val oldPlaced: Int,
    val oldLeftover: Int,
    val firstLeftoverNo: Int?,     // رقم أول محاضرة قديمة لم تتسع لها الفترة
    val newPlaced: Int
)

data class GenSummary(
    val dayCount: Int,             // أيام الفترة كاملة
    val studyDayCount: Int,        // أيام الدراسة (بعد استبعاد الراحة)
    val totalAvailableMin: Int,
    val newCount: Int, val oldCount: Int, val examCount: Int,
    val newMin: Int, val oldMin: Int, val examMin: Int,
    val leftoverOld: Int,
    val unusedMinAtEnd: Int,       // دقائق متاحة لم تُستخدم (قد تكون موزعة على أيام لا تتسع لمحاضرة كاملة)
    val dailyMin: Map<String, Int>,
    val perSubject: List<GenSubjectSummary>,
    val overLimitDays: List<String>,
    val feasible: Boolean,         // كل التراكم أُدرج ضمن الفترة
    val extraDays: Int = 0,        // أيام أُضيفت بعد تاريخ النهاية المُدخل
    val effectiveEnd: String = "", // آخر يوم فعلي في الجدول
    val extensionBlocked: Boolean = false // التمديد لا يُنهي التراكم → توقّف وتحذير
) {
    val extraWeeks: Int get() = (extraDays + 6) / 7
}

data class GeneratedPlan(
    val json: String?,
    val file: ScheduleFile?,
    val summary: GenSummary?,
    val missingInputs: List<String>,
    val warnings: List<String>,
    val errors: List<String>
) {
    val ok: Boolean get() = json != null && file != null && missingInputs.isEmpty() && errors.isEmpty()
}

object ScheduleGenerator {
    private val timeRx = Regex("^([01]?\\d|2[0-3]):([0-5]\\d)$")

    private fun parseTime(s: String): Int? {
        val m = timeRx.matchEntire(s.trim()) ?: return null
        return m.groupValues[1].toInt() * 60 + m.groupValues[2].toInt()
    }

    /** كل ما يجب أن يدخله المستخدم قبل التوليد. فارغة = جاهز. */
    fun missingInputs(d: WizardDraft): List<String> {
        val p = mutableListOf<String>()
        if (d.subjects.isEmpty()) p += "اختر مادة واحدة على الأقل."
        if (d.startDate.isBlank() || d.endDate.isBlank()) p += "حدد تاريخ بداية الجدول ونهايته."
        else d.validateDates()?.let { p += it }
        if (d.dailyStudyMin <= 0) p += "حدد وقت الدراسة اليومي."
        d.missingBacklogs().forEach { p += "حدد عدد تراكم مادة $it (أو أكّد أنه صفر)." }
        d.subjects.forEach { s ->
            val n = d.backlogs[s] ?: 0
            if (n > 0 && (d.firstOldNo[s] ?: 0) < 1)
                p += "أدخل رقم أول محاضرة قديمة متبقية لمادة $s — لا يمكن تخمين أرقام المحاضرات."
            if (n > 0 && d.usableDays(s).isEmpty())
                p += "وزّع مادة $s على يوم دراسة واحد على الأقل غير يوم راحة (لها $n تراكم)."
            if (n > 0 && d.durOf(s) > d.dailyStudyMin)
                p += "مدة محاضرة $s (${d.durOf(s)} د) أكبر من الحد اليومي (${d.dailyStudyMin} د) — لا يمكن جدولتها."
        }
        d.invalidLectureTimes().forEach { p += "وقت نشر $it بصيغة غير صحيحة — استخدم HH:MM." }
        d.exams.forEach { e ->
            val label = "اختبار ${e.day} (${e.subjects.joinToString("، ")})"
            if (e.day !in WizardConst.DAYS) p += "$label: يوم غير معروف."
            if (e.kind != "daily" && e.kind != "cumulative") p += "$label: النوع يجب أن يكون يومي أو تراكمي."
            if (e.subjects.isEmpty()) p += "$label: لم تُحدد مادة."
            e.subjects.filter { it !in d.subjects }.forEach { p += "$label: المادة «$it» ليست ضمن مواد الجدول." }
            if ((e.durationMin ?: 0) <= 0) p += "$label: أدخل مدة الاختبار — لا تُخترع المدة."
            if (e.time.isNotBlank() && parseTime(e.time) == null) p += "$label: وقت غير صحيح (HH:MM)."
        }
        return p.distinct()
    }

    /**
     * يولّد الجدول ويمدّده تلقائيًا (إن autoExtend) بعد تاريخ النهاية حتى يكتمل التراكم.
     * إن تبيّن أن التمديد لا ينفع (تقدّم صفري أو سقف) يُقصّ الجدول عند آخر يوم تقدّم فيه التراكم
     * ويُحذَّر بدل الادّعاء بالإكمال — لا حلقة لا نهائية ولا تغيير صامت لاختيارات الطالب.
     */
    fun generate(d: WizardDraft): GeneratedPlan {
        val first = build(d, d.autoExtend)
        if (!first.stalled) return first.plan
        val origEnd = LocalDate.parse(d.endDate)
        val cut = first.lastOldDay?.let { if (it.isAfter(origEnd)) it else origEnd } ?: origEnd
        val fixed = build(d.copy(endDate = cut.toString()), false).plan
        val extra = java.time.temporal.ChronoUnit.DAYS.between(origEnd, cut).toInt()
        return fixed.copy(
            warnings = (fixed.warnings + PlanAllocator.BLOCKED_MSG).distinct(),
            summary = fixed.summary?.copy(extensionBlocked = true, extraDays = extra))
    }

    private class Built(val plan: GeneratedPlan, val stalled: Boolean, val lastOldDay: LocalDate?)

    private fun build(d: WizardDraft, extend: Boolean): Built {
        val missing = missingInputs(d)
        if (missing.isNotEmpty()) return Built(GeneratedPlan(null, null, null, missing, emptyList(), emptyList()), false, null)

        val start = LocalDate.parse(d.startDate)
        val end = LocalDate.parse(d.endDate)
        val idx = d.subjects.withIndex().associate { it.value to it.index }
        val warnings = mutableListOf<String>()

        val oldLeft = d.subjects.associateWith { d.backlogs[it] ?: 0 }.toMutableMap()
        val nextOld = d.subjects.associateWith { d.firstOldNo[it] ?: 0 }.toMutableMap()
        val nextNew = d.firstNewNo.toMutableMap()
        val oldPlaced = d.subjects.associateWith { 0 }.toMutableMap()
        val newPlaced = d.subjects.associateWith { 0 }.toMutableMap()

        var newCount = 0; var oldCount = 0; var examCount = 0
        var newMin = 0; var oldMin = 0; var examMin = 0
        var dayCount = 0; var studyDays = 0; var unused = 0
        val dailyMin = linkedMapOf<String, Int>()
        val overLimit = mutableListOf<String>()
        val carried = mutableListOf<Pair<String, LocalDate>>()   // (مادة، تاريخ النشر) نُشرت في يوم راحة
        val daysJson = JSONArray()
        val plan = d.weekPlan

        val tr = ExtensionTracker(extend)
        var lastDay = start
        var cur = start
        while (true) {
            if (cur.isAfter(end) && !tr.shouldContinue(oldLeft, oldPlaced)) break
            lastDay = cur
            dayCount++
            val dn = WizardConst.dayOfWeekName(cur.dayOfWeek)
            val published = if (d.oldOnly) emptyList()
                else d.subjects.filter { dn in (d.newLectureDays[it] ?: emptySet()) }

            if (dn in d.restDays) {
                published.forEach { carried += it to cur }
                d.exams.filter { it.day == dn }.forEach {
                    warnings += "اختبار ${it.day} ${cur} (${it.subjects.joinToString("، ")}) وقع في يوم راحة فلم يُدرج."
                }
                cur = cur.plusDays(1)
                continue
            }
            studyDays++
            val tasks = JSONArray()
            var used = 0

            // 1) الجديد المستحق: المنقول من أيام الراحة أولًا ثم منشور اليوم
            val due = carried.toList() + published.map { it to cur }
            carried.clear()
            due.forEach { (s, pubDate) ->
                val dur = d.durOf(s)
                val no = nextNew[s]
                if (no != null) nextNew[s] = no + 1
                val notes = mutableListOf<String>()
                if (pubDate != cur) notes += "نُشرت يوم $pubDate (يوم راحة) ونُقلت لأول يوم دراسة"
                d.newLectureTime[s]?.takeIf { it.isNotBlank() }?.let { notes += "وقت النشر $it" }
                tasks.put(JSONObject().apply {
                    put("id", "new-${idx[s]}-$pubDate")
                    put("subject", s); put("type", "newLecture")
                    put("title", if (no != null) "محاضرة جديدة $no — $s" else "محاضرة جديدة — $s")
                    if (no != null) put("lectureNo", no)
                    put("durationMin", dur)
                    put("flexible", false); put("fixed", false); put("notify", true)
                    if (notes.isNotEmpty()) put("note", notes.joinToString(" · "))
                })
                used += dur; newMin += dur; newCount++
                newPlaced[s] = (newPlaced[s] ?: 0) + 1
            }

            // 2) الاختبارات المحددة في هذا اليوم (مدة مؤكدة فقط)
            val timedSlots = mutableListOf<Pair<Int, Int>>()
            d.exams.filter { it.day == dn }.forEach { e ->
                var offset = 0
                val base = parseTime(e.time)
                e.subjects.forEach { s ->
                    val len = e.durationMin ?: 0
                    var st: Int? = null; var en: Int? = null
                    val notes = mutableListOf<String>()
                    if (e.notes.isNotBlank()) notes += e.notes
                    if (base != null) {
                        val s0 = base + offset; val e0 = s0 + len
                        val clash = timedSlots.any { s0 < it.second && it.first < e0 }
                        if (s0 < 19 * 60) notes += "الوقت المطلوب ${e.time} قبل 7:00 مساءً فلم يُثبَّت"
                        else if (e0 > 24 * 60) notes += "الوقت المطلوب ${e.time} يتجاوز منتصف الليل فلم يُثبَّت"
                        else if (clash) notes += "الوقت المطلوب ${e.time} يتداخل مع اختبار آخر فلم يُثبَّت"
                        else { st = s0; en = e0; timedSlots += s0 to e0 }
                    }
                    offset += len
                    val stV: Int? = st; val enV: Int? = en
                    val label = if (e.kind == "daily") "اختبار يومي" else "اختبار تراكمي"
                    tasks.put(JSONObject().apply {
                        put("id", "exam-${e.id}-$cur-${idx[s]}")
                        put("subject", s)
                        put("type", if (e.kind == "daily") "dailyExam" else "cumulativeExam")
                        put("title", e.title.ifBlank { "$label — $s" })
                        put("durationMin", len)
                        if (stV != null && enV != null) {
                            put("start", Subjects.fromMin(stV)); put("end", Subjects.fromMin(enV))
                        }
                        put("flexible", false); put("fixed", stV != null); put("notify", true)
                        if (notes.isNotEmpty()) put("note", notes.joinToString(" · "))
                    })
                    used += len; examMin += len; examCount++
                }
            }

            // 3) القديم في الوقت المتبقي، الأكثر تراكمًا بين المواد المسموحة اليوم
            var free = d.dailyStudyMin - used
            if (free < 0) {
                overLimit += cur.toString()
                warnings += "يوم $dn $cur: الجديد والاختبارات (${used}د) تتجاوز الحد اليومي (${d.dailyStudyMin}د) — لم يوضع فيه تراكم."
            }
            while (true) {
                val pick = d.subjects
                    .filter { (oldLeft[it] ?: 0) > 0 && d.durOf(it) <= free && (plan.isEmpty() || it in (plan[dn] ?: emptySet())) }
                    .maxByOrNull { (oldLeft[it] ?: 0) * d.durOf(it) } ?: break
                val dur = d.durOf(pick)
                val no = nextOld[pick] ?: break
                nextOld[pick] = no + 1
                oldLeft[pick] = (oldLeft[pick] ?: 0) - 1
                oldPlaced[pick] = (oldPlaced[pick] ?: 0) + 1
                tasks.put(JSONObject().apply {
                    put("id", "old-${idx[pick]}-$no")
                    put("subject", pick); put("type", "oldLecture")
                    put("title", "تراكم $no — $pick")
                    put("lectureNo", no)
                    put("durationMin", dur)
                    put("flexible", true); put("fixed", false); put("notify", true)
                })
                free -= dur; used += dur; oldMin += dur; oldCount++
                tr.noteOldPlaced(cur)
            }
            if (free > 0) unused += free

            if (tasks.length() > 0) {
                daysJson.put(JSONObject().apply {
                    put("date", cur.toString()); put("weekday", ScheduleParser.weekday(cur)); put("tasks", tasks)
                })
                dailyMin[cur.toString()] = used
            }
            cur = cur.plusDays(1)
        }

        if (carried.isNotEmpty())
            warnings += "${carried.size} محاضرة جديدة نُشرت في أيام راحة آخر الفترة ولا يوجد يوم دراسة بعدها داخل الفترة، فلم تُدرج."
        if (!d.oldOnly && d.newLectureDays.values.none { it.isNotEmpty() })
            warnings += "لم تُحدد أيام نشر لأي مادة — لن تُنشأ محاضرات جديدة."
        val leftover = oldLeft.values.sum()
        val effEnd = if (tr.extDays > 0) lastDay else end
        if (tr.extDays > 0) warnings += "الفترة المُدخلة لا تكفي فتمدّد الجدول ${tr.extDays} يومًا (≈ ${(tr.extDays + 6) / 7} أسبوعًا) حتى $effEnd."
        if (leftover > 0) warnings += "عجز: $leftover محاضرة قديمة لا تتسع لها الفترة والوقت اليومي المحددان."
        if (daysJson.length() == 0)
            return Built(GeneratedPlan(null, null, null, emptyList(), warnings,
                listOf("لا توجد أي مهمة ضمن الفترة (تحقق من أيام الراحة والتراكمات وأيام النشر).")), false, null)

        val root = JSONObject().apply {
            put("format", "rafiq_schedule"); put("formatVersion", 1)
            put("metadata", JSONObject().apply { put("scheduleName", "جدول رفيق من $start إلى $effEnd") })
            put("startDate", start.toString()); put("endDate", effEnd.toString())
            put("days", daysJson)
        }
        val text = root.toString()

        // التحقق بنفس المحلل الذي يستخدمه الاستيراد — لا نسلّم ملفًا لا يُستورد
        val parsed = ScheduleParser.parse(text)
        val errors = mutableListOf<String>()
        if (!parsed.ok) errors += parsed.errors.map { "${it.path}: ${it.message}" }
        parsed.file?.let { f -> errors += WizardVerify.compliance(f, d) }

        val summary = GenSummary(
            dayCount, studyDays, studyDays * d.dailyStudyMin,
            newCount, oldCount, examCount, newMin, oldMin, examMin,
            leftover, unused, dailyMin.toMap(),
            d.subjects.map { s ->
                val left = oldLeft[s] ?: 0
                GenSubjectSummary(s, oldPlaced[s] ?: 0, left,
                    if (left > 0) nextOld[s] else null, newPlaced[s] ?: 0)
            },
            overLimit.toList(), leftover == 0,
            extraDays = tr.extDays, effectiveEnd = effEnd.toString()
        )
        return Built(GeneratedPlan(if (errors.isEmpty()) text else null, parsed.file, summary, emptyList(),
            warnings.distinct(), errors), tr.stalled, tr.lastOldDay)
    }
}
