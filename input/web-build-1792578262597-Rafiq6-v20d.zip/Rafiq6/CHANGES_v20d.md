# تعديلات v20d (تراكمية على v20c)

## القسم أ — مولّد الجدول والمُخصص
- `ScheduleGenerator.kt` (جديد): توليد rafiq_schedule v1 فعلي ويُتحقَّق منه بمحلل الاستيراد نفسه. أرقام أول محاضرة قديمة إلزامية (لا تخمين).
- `PlanAllocator`: يحترم أيام الراحة وأيام المادة وخيار «تراكمات فقط»؛ تصحيح اختبار عجز خاطئ.
- المسودة: `firstOldNo/firstNewNo` (متوافقة مع القديم). واجهة معاينة/اعتماد/حفظ JSON.

## القسم ب — وضع التركيز
- Lock Task حقيقي عبر Device Owner (`FocusLockdown.kt`, `FocusAdminReceiver`, `device_admin.xml`)، تطبيقان مسموحان، تطبيق الاتصال للطوارئ.
- إصلاحات: `FocusStore.clear()` كان يمسح السجل؛ تسجيل مزدوج لنهاية الجلسة؛ إعادة فتح التطبيقات مع كل تدوير.

## القسم ج (هذه الجولة)
### الإشعارات (`Notify.kt`, `AlarmTimes.kt` جديد, `Vm.kt`, `AndroidManifest.xml`)
- PendingIntent فريد لكل (مهمة، نوع) بدل الاعتماد على hashCode.
- المستقبِل يتجاهل مهام الجداول غير الفعّالة/المنجزة/المعطّل تنبيهها.
- إلغاء تنبيهات الجدول الفعّال عند أي استيراد جديد (كان يحدث فقط عند الاستبدال)، وإزالة الإشعار الظاهر عند الإلغاء.
- إعادة الجدولة عند تحديث التطبيق، وحساب المواعيد في دالة نقية.
### النسخ الاحتياطي (`BackupCodec.kt` جديد, `Backup.kt`, `Focus.kt`, `Ui.kt`, `Vm.kt`)
- إضافة الإعدادات وسجل التركيز (اختياريان)؛ فحص كامل قبل الاسترجاع برسائل واضحة؛ تأكيد بالأعداد؛ نسخة أمان تلقائية؛ إلغاء التنبيهات قبل الاستبدال.
- (كان الاسترجاع ينفَّذ فور اختيار الملف دون تأكيد، ورسائل الأخطاء خام.)
### منع التكرار (`ScheduleFingerprint.kt` جديد, `Data.kt`, `Db.kt`, `JsonCodec.kt`, `Vm.kt`, `Ui.kt`, `ScheduleWizardUi.kt`)
- بصمة SHA-256 + عمود `contentHash` + **Migration 4→5** + حوار الإلغاء/المتابعة في المواضع الثلاثة + حارس في `importSchedule`.
- إصلاح: رسالة «تم الاستيراد/الاستبدال» كانت تظهر دون فحص نتيجة العملية.

## الملفات المتغيرة
جديدة: `ScheduleGenerator.kt, ScheduleFingerprint.kt, BackupCodec.kt, AlarmTimes.kt, FocusLockdown.kt, res/xml/device_admin.xml`، اختبارات `ScheduleGeneratorTest, BackupCodecTest, ScheduleFingerprintTest, AlarmTimesTest`، وثائق `docs/schedule_generator.md, docs/focus_mode.md, docs/backup_notifications_import.md`.
معدّلة: `AndroidManifest.xml, Backup.kt, Data.kt, Db.kt, Focus.kt, FocusApps.kt, FocusAppsUi.kt, FocusLogic.kt, FocusUi.kt, JsonCodec.kt, Notify.kt, ScheduleWizardLogic.kt, ScheduleWizardUi.kt, Ui.kt, Vm.kt` واختبارات `FocusLogicTest, ScheduleWizardTest`.

## الاختبارات
**كُتبت (JVM، لم تُنفَّذ — لا Gradle/Kotlin هنا):** AlarmTimes 4 · BackupCodec 9 · ScheduleFingerprint 5 · ScheduleGenerator 15 · FocusLogic 13 · ScheduleWizard 22 · (قديمة) AuditFix 7، BankLogic 11، ScheduleLogic 17.
**نُفّذ فعلًا في هذه البيئة:** فحص توازن الأقواس لكل ملفات Kotlin (36 ملفًا، 0 خلل) وفحص تطابق الرموز المستدعاة. محاكاة Python لخوارزمية التوزيع كانت مصدر أرقام اختبارات المولّد فقط ولا تُعدّ بديلًا عن اختبارات Kotlin.
**لم يُنفَّذ ويحتاج بيئة/جهاز:** كل اختبارات Kotlin أعلاه، بناء APK، اختبار Migration 4→5 (يحتاج androidTest/MigrationTestHelper)، Lock Task وDevice Owner، وصول الإشعارات فعليًا، استرجاع نسخة على قاعدة حقيقية (مغطى منطقيًا بـ BackupCodecTest للترميز فقط).

## البناء
لا يوجد Gradle Wrapper في المشروع. الأوامر:
`gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug` (Gradle 8.10.2 + JDK 17 + Android SDK 34) أو من Android Studio. لم يُنتَج APK.
