package com.rafiq6.study

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class ScheduleWizardTest {
    private fun answers() = WizardAnswers(
        stage = "السادس العلمي", subjects = "فيزياء، كيمياء",
        oldLectures = "فيزياء=2", startDate = "2026-01-01", endDate = "2026-01-31",
        dailyGoalMin = 360
    )

    @Test fun draftRoundtrip() {
        val a = answers()
        val back = WizardDraftCodec.fromJson(WizardDraftCodec.toJson(a))
        assertEquals(a.stage, back.stage); assertEquals(a.subjects, back.subjects)
        assertEquals(a.oldLectures, back.oldLectures)
        assertEquals(a.dailyGoalMin, back.dailyGoalMin)
        assertEquals(a.strictPlan, back.strictPlan)
        assertEquals(a.wakeMin, back.wakeMin)
        assertEquals(a.mode, back.mode)
    }

    @Test fun draftToleratesGarbage() {
        val back = WizardDraftCodec.fromJson(JSONObject())
        assertEquals(45, back.lectureDur)
        assertEquals(390, back.wakeMin)
        assertTrue(back.strictPlan)
        assertEquals("new", back.mode)
    }

    @Test fun promptContainsAnswersAndRules() {
        val p = WizardPromptBuilder.build(answers())
        assertTrue(p.contains("السادس العلمي"))
        assertTrue(p.contains("فيزياء=2"))
        assertTrue(p.contains("2026-01-01"))
        assertTrue(p.contains("rafiq_schedule"))
        assertTrue(p.contains("formatVersion"))
        assertTrue(p.contains("rafiq_part"))
        (1..10).forEach { assertTrue("rule $it", p.contains("$it.")) }
        assertTrue(p.contains("لا تخترع"))
    }

    @Test fun promptReplanMentionsKeepDone() {
        val p = WizardPromptBuilder.build(answers().copy(mode = "replan", keepDone = true))
        assertTrue(p.contains("المهام المنجزة"))
    }

    @Test fun partAssemblyMergesDays() {
        fun part(i: Int, t: Int, vararg dates: String) = org.json.JSONObject().apply {
            put("format", "rafiq_part"); put("partIndex", i); put("totalParts", t)
            put("payload", org.json.JSONObject().apply {
                put("metadata", org.json.JSONObject().put("scheduleName", "جدول تجريبي"))
                put("startDate", "2026-01-01"); put("endDate", "2026-01-03")
                put("days", org.json.JSONArray().apply { dates.forEach { d ->
                    put(org.json.JSONObject().put("date", d).put("tasks", org.json.JSONArray())) } })
            })
        }.toString()
        val asm = PartAssembler.assemble(listOf(
            part(2, 2, "2026-01-03"),
            part(1, 2, "2026-01-01", "2026-01-02")
        ))
        assertTrue(asm.errors.isEmpty())
        val root = org.json.JSONObject(asm.text)
        assertEquals("rafiq_schedule", root.getString("format"))
        assertEquals("جدول تجريبي", root.getJSONObject("metadata").getString("scheduleName"))
        assertEquals(3, root.getJSONArray("days").length())
        assertEquals("2026-01-01", root.getJSONArray("days").getJSONObject(0).getString("date"))
    }

    @Test fun partAssemblyDetectsGapsDuplicatesAndBadParts() {
        fun part(i: Int, t: Int, vararg dates: String) = org.json.JSONObject().apply {
            put("format", "rafiq_part"); put("partIndex", i); put("totalParts", t)
            put("payload", org.json.JSONObject().apply {
                put("days", org.json.JSONArray().apply { dates.forEach { d ->
                    put(org.json.JSONObject().put("date", d).put("tasks", org.json.JSONArray())) } })
            })
        }.toString()
        // نقص جزء
        assertTrue(PartAssembler.assemble(listOf(part(1, 2, "2026-01-01"))).errors.isNotEmpty())
        // ترقيم غير متسلسل
        assertTrue(PartAssembler.assemble(listOf(part(1, 2, "2026-01-01"), part(3, 2, "2026-01-03"))).errors.isNotEmpty())
        // تاريخ مكرر بين جزأين
        assertTrue(PartAssembler.assemble(listOf(
            part(1, 2, "2026-01-01"), part(2, 2, "2026-01-01", "2026-01-02")
        )).errors.any { it.contains("مكرر") })
        // جزء غير JSON
        assertTrue(PartAssembler.assemble(listOf("ليس json", part(1, 2, "2026-01-01"))).errors.isNotEmpty())
    }

    @Test fun statsComputeTotalsAndHighLoad() {
        val json = """{"format":"rafiq_schedule","formatVersion":1,"startDate":"2026-01-01","endDate":"2026-01-02",
            "days":[
            {"date":"2026-01-01","tasks":[{"id":"t1","subject":"فيزياء","type":"oldLecture","title":"تراكم 1","durationMin":240},{"id":"t2","subject":"فيزياء","type":"newLecture","title":"جديدة 1","durationMin":200}]},
            {"date":"2026-01-02","tasks":[{"id":"t3","subject":"كيمياء","type":"review","title":"مراجعة","durationMin":100}]}]}"""
        val r = ScheduleParser.parse(json)
        assertTrue(r.errors.toString(), r.ok)
        val st = WizardVerify.stats(r.file!!, answers())
        assertEquals(2, st.dayCount); assertEquals(3, st.taskCount)
        assertEquals(540, st.totalMin)
        assertEquals(1, st.oldLectures); assertEquals(1, st.newLectures)
        assertEquals(mapOf("فيزياء" to 1), st.missingOld)
        assertTrue(st.highLoadDays.isNotEmpty())
        assertTrue(st.warnings.any { it.contains("فيزياء") })
    }

    @Test fun verifyDetectsBadRangeAndCountsDays() {
        assertTrue(WizardVerify.validateRange(answers()) == null)
        assertNotNull(WizardVerify.validateRange(answers().copy(endDate = "2025-12-01")))
        assertNotNull(WizardVerify.validateRange(answers().copy(startDate = "باطل")))
        assertEquals(31, WizardVerify.daysBetween(answers()))
    }
}
