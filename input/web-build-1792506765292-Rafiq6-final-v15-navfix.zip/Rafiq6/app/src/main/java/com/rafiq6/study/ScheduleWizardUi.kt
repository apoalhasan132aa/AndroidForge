package com.rafiq6.study

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

// تخزين مسودة المعالج
val Context.wizardDs by preferencesDataStore("rafiq6_wizard")
private val DRAFT = stringPreferencesKey("draft")

suspend fun saveWizardDraft(c: Context, a: WizardAnswers) {
    c.wizardDs.edit { it[DRAFT] = WizardDraftCodec.toJson(a).toString() }
}
suspend fun loadWizardDraft(c: Context): WizardAnswers? {
    val raw = c.wizardDs.data.first()[DRAFT] ?: return null
    return try { WizardDraftCodec.fromJson(org.json.JSONObject(raw)) } catch (e: Exception) { null }
}
suspend fun clearWizardDraft(c: Context) { c.wizardDs.edit { it.remove(DRAFT) } }

// ---------- الشاشة الرئيسية للميزة ----------

@Composable fun ScheduleBuilderHubScreen(vm: MainVm) {
    var stage by remember { mutableStateOf("intro") } // intro · wizard · summary · prompt · import
    var answers by remember { mutableStateOf(WizardAnswers()) }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var restored by remember { mutableStateOf(false) }

    // استعادة المسودة عند الدخول أول مرة
    LaunchedEffect(Unit) {
        if (!restored) { restored = true
            loadWizardDraft(ctx)?.let { answers = it } }
    }

    when (stage) {
        "intro" -> Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("📅 إنشاء / تغيير الجدول السنوي", style = MaterialTheme.typography.headlineSmall)
            Text("أجب عن أسئلة مرتبة، وسيبني التطبيق برومبتًا مخصصًا ترسله لأي أداة ذكاء اصطناعي تحبها، ثم تستورد ملف JSON الذي تنتجه وتعاينه قبل اعتماده. جدولك الحالي وبياناتك لا تُمسح حتى تعتمد الجديد، وتستطيع الرجوع إليه في أي وقت.")
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("١) إنشاء جدول سنوي جديد", style = MaterialTheme.typography.titleMedium)
                Text("من الصفر بناءً على إجاباتك: موادك، تراكماتك، دوامك، نومك، وأهدافك.")
                Button(onClick = { answers = WizardAnswers(mode = "new"); stage = "wizard" }, modifier = Modifier.fillMaxWidth()) { Text("ابدأ معالج جدول جديد") }
            } }
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("٢) تعديل الجدول الحالي / إعادة تنظيمه", style = MaterialTheme.typography.titleMedium)
                Text("عندما تتغير ظروفك: تراكمات جديدة، تأخر أيام، تغيّر النوم أو الدوام. يبقى إنجازك محفوظًا.")
                OutlinedButton(onClick = {
                    answers = WizardAnswers(mode = "replan"); stage = "wizard"
                }, modifier = Modifier.fillMaxWidth()) { Text("أعد تنظيم جدولي") }
            } }
            if (answers != WizardAnswers()) Text("يوجد مسودة محفوظة — اختر أحد الخيارين أعلاه لتعديلها.", style = MaterialTheme.typography.bodySmall)
        }
        "wizard" -> ScheduleWizardScreen(
            vm = vm, initial = answers,
            onDraft = { a -> answers = a; scope.launch { saveWizardDraft(ctx, a) } },
            onBackToIntro = { stage = "intro" },
            onDone = { a -> answers = a; scope.launch { saveWizardDraft(ctx, a) }; stage = "summary" })
        "summary" -> WizardSummaryScreen(answers,
            onEdit = { stage = "wizard" },
            onCancel = { stage = "intro" },
            onNext = { stage = "prompt" })
        "prompt" -> PromptScreen(vm, answers,
            onBack = { stage = "summary" },
            onGoImport = { stage = "import" })
        "import" -> WizardImportScreen(vm, answers,
            onBack = { stage = "prompt" },
            onCancel = { stage = "intro" })
    }
}

// ---------- المعالج خطوة بخطوة ----------

@Composable fun ScheduleWizardScreen(
    vm: MainVm, initial: WizardAnswers,
    onDraft: (WizardAnswers) -> Unit,
    onBackToIntro: () -> Unit, onDone: (WizardAnswers) -> Unit
) {
    var a by remember { mutableStateOf(initial) }
    var step by remember { mutableStateOf(0) }
    val steps = WizardSteps.all
    val cur = steps[step.coerceIn(0, steps.size - 1)]
    val scope = rememberCoroutineScope()

    fun upd(copy: WizardAnswers) { a = copy; onDraft(copy) }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { if (step == 0) onBackToIntro() else step-- }) { Text(if (step == 0) "إلغاء" else "‹ السابق") }
            Text("الخطوة ${step + 1} من ${steps.size}: ${cur.title}", style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (cur.optional) TextButton(onClick = { if (step == steps.size - 1) onDone(a) else step++ }) { Text("تخطٍّ ›") }
        }
        LinearProgressIndicator(progress = { (step + 1).toFloat() / steps.size }, modifier = Modifier.fillMaxWidth())
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (cur.id) {
                "stage" -> StepStage(a) { upd(it) }
                "teachers" -> StepTeachers(a) { upd(it) }
                "durations" -> StepDurations(a) { upd(it) }
                "range" -> StepRange(a) { upd(it) }
                "routine" -> StepRoutine(vm, a) { upd(it) }
                "study" -> StepStudy(vm, a) { upd(it) }
                "prefs" -> StepPrefs(a) { upd(it) }
                "extras" -> StepExtras(a) { upd(it) }
            }
        }
        Button(onClick = { if (step == steps.size - 1) onDone(a) else step++ },
            enabled = cur.optional || when (cur.id) {
                "stage" -> a.stage.isNotBlank() && a.subjects.isNotBlank()
                "range" -> a.startDate.isNotBlank() && a.endDate.isNotBlank() && WizardVerify.validateRange(a) == null
                else -> true
            }, modifier = Modifier.fillMaxWidth()) {
            Text(if (step == steps.size - 1) "عرض الملخص والتالي" else "التالي ›")
        }
        WizardVerify.validateRange(a)?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable private fun StepStage(a: WizardAnswers, onA: (WizardAnswers) -> Unit) {
    Text("ما مرحلتك وموادك؟", style = MaterialTheme.typography.titleMedium)
    OutlinedTextField(value = a.stage, onValueChange = { onA(a.copy(stage = it)) }, modifier = Modifier.fillMaxWidth(), label = { Text("المرحلة والصف (مثال: السادس العلمي — العراق)") })
    OutlinedTextField(value = a.subjects, onValueChange = { onA(a.copy(subjects = it)) }, modifier = Modifier.fillMaxWidth(), label = { Text("المواد — افصل بينها بفاصلة (فيزياء، كيمياء، …)") })
    Text("ستُبنى الأعداد والتوزيعات على هذه المواد فقط — لن يخترع النظام مواد غير موجودة هنا.", style = MaterialTheme.typography.bodySmall)
}

@Composable private fun StepTeachers(a: WizardAnswers, onA: (WizardAnswers) -> Unit) {
    Text("المدرسون والمحاضرات (اختياري لكنه يحسّن الجدول)", style = MaterialTheme.typography.titleMedium)
    OutlinedTextField(value = a.teachers, onValueChange = { onA(a.copy(teachers = it)) }, modifier = Modifier.fillMaxWidth(), label = { Text("المدرسون — مادة: اسم (فيزياء: أ. أحمد)") })
    OutlinedTextField(value = a.oldLectures, onValueChange = { onA(a.copy(oldLectures = it)) }, modifier = Modifier.fillMaxWidth(), label = { Text("عدد التراكمات لكل مادة — مادة=عدد (فيزياء=12، كيمياء=7)") })
    OutlinedTextField(value = a.newLectures, onValueChange = { onA(a.copy(newLectures = it)) }, modifier = Modifier.fillMaxWidth(), label = { Text("المحاضرات الجديدة المتوقعة (فيزياء=2 أسبوعيًا …)") })
}

@Composable private fun StepDurations(a: WizardAnswers, onA: (WizardAnswers) -> Unit) {
    Text("المدد ومواعيد الامتحانات", style = MaterialTheme.typography.titleMedium)
    Row(verticalAlignment = Alignment.CenterVertically) { Text("مدة المحاضرة: ${a.lectureDur} د")
        Slider(value = a.lectureDur.toFloat(), onValueChange = { onA(a.copy(lectureDur = it.toInt())) }, valueRange = 20f..120f, modifier = Modifier.fillMaxWidth()) }
    Row(verticalAlignment = Alignment.CenterVertically) { Text("حل الواجبات: ${a.homeworkMin} د")
        Slider(value = a.homeworkMin.toFloat(), onValueChange = { onA(a.copy(homeworkMin = it.toInt())) }, valueRange = 10f..120f, modifier = Modifier.fillMaxWidth()) }
    Row(verticalAlignment = Alignment.CenterVertically) { Text("المراجعة اليومية: ${a.reviewMin} د")
        Slider(value = a.reviewMin.toFloat(), onValueChange = { onA(a.copy(reviewMin = it.toInt())) }, valueRange = 10f..120f, modifier = Modifier.fillMaxWidth()) }
    OutlinedTextField(value = a.examDates, onValueChange = { onA(a.copy(examDates = it)) }, modifier = Modifier.fillMaxWidth(), label = { Text("مواعيد الامتحانات والتراكمات القادمة (اختياري)") })
}

@Composable private fun StepRange(a: WizardAnswers, onA: (WizardAnswers) -> Unit) {
    Text("نطاق الجدول والهدف", style = MaterialTheme.typography.titleMedium)
    OutlinedTextField(value = a.startDate, onValueChange = { onA(a.copy(startDate = it)) }, modifier = Modifier.fillMaxWidth(), label = { Text("تاريخ بداية الجدول YYYY-MM-DD") })
    OutlinedTextField(value = a.endDate, onValueChange = { onA(a.copy(endDate = it)) }, modifier = Modifier.fillMaxWidth(), label = { Text("تاريخ نهاية الجدول YYYY-MM-DD") })
    WizardVerify.daysBetween(a)?.let { Text("المدة: $it يومًا تقريبًا.", style = MaterialTheme.typography.bodySmall) }
    OutlinedTextField(value = a.finalGoal, onValueChange = { onA(a.copy(finalGoal = it)) }, modifier = Modifier.fillMaxWidth(), label = { Text("موعد الامتحانات النهائية أو هدف مهم (اختياري)") })
}

@Composable private fun StepRoutine(vm: MainVm, a: WizardAnswers, onA: (WizardAnswers) -> Unit) {
    val s by vm.settings.collectAsState()
    Text("الروتين اليومي", style = MaterialTheme.typography.titleMedium)
    Text("محمّلة من إعداداتك الحالية — عدّل ما ينطبق عليك:", style = MaterialTheme.typography.bodySmall)
    Row(verticalAlignment = Alignment.CenterVertically) { Text("الاستيقاظ: ${Subjects.fmt12(a.wakeMin)}")
        Slider(value = a.wakeMin.toFloat(), onValueChange = { onA(a.copy(wakeMin = it.toInt())) }, valueRange = 240f..600f, modifier = Modifier.fillMaxWidth()) }
    Row(verticalAlignment = Alignment.CenterVertically) { Text("النوم: ${Subjects.fmt12(a.sleepMin)}")
        Slider(value = a.sleepMin.toFloat(), onValueChange = { onA(a.copy(sleepMin = it.toInt())) }, valueRange = 1200f..1440f, modifier = Modifier.fillMaxWidth()) }
    Row(verticalAlignment = Alignment.CenterVertically) { Text("الذهاب للمدرسة: ${Subjects.fmt12(a.schoolStart)}")
        Slider(value = a.schoolStart.toFloat(), onValueChange = { onA(a.copy(schoolStart = it.toInt())) }, valueRange = 360f..720f, modifier = Modifier.fillMaxWidth()) }
    Row(verticalAlignment = Alignment.CenterVertically) { Text("العودة: ${Subjects.fmt12(a.schoolEnd)}")
        Slider(value = a.schoolEnd.toFloat(), onValueChange = { onA(a.copy(schoolEnd = it.toInt())) }, valueRange = 720f..1080f, modifier = Modifier.fillMaxWidth()) }
    Text("أيام الدوام:", style = MaterialTheme.typography.titleSmall)
    val all = listOf("السبت","الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة")
    val sel = a.schoolDays.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableSet()
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        all.forEach { d -> FilterChip(selected = d in sel, onClick = {
            if (d in sel) sel.remove(d) else sel.add(d)
            onA(a.copy(schoolDays = all.filter { it in sel }.joinToString(",")))
        }, label = { Text(d) }) }
    }
    Text("الإعدادات الحالية للتطبيق: استيقاظ ${Subjects.fmt12(s.wakeMin)} · نوم ${Subjects.fmt12(s.sleepMin)}", style = MaterialTheme.typography.bodySmall)
}

@Composable private fun StepStudy(vm: MainVm, a: WizardAnswers, onA: (WizardAnswers) -> Unit) {
    Text("وقت الدراسة والاستراحات", style = MaterialTheme.typography.titleMedium)
    Row(verticalAlignment = Alignment.CenterVertically) { Text("الحد الأقصى يوميًا: ${a.dailyGoalMin / 60} ساعات")
        Slider(value = a.dailyGoalMin.toFloat(), onValueChange = { onA(a.copy(dailyGoalMin = it.toInt())) }, valueRange = 120f..900f, modifier = Modifier.fillMaxWidth()) }
    OutlinedTextField(value = a.prayerTimes, onValueChange = { onA(a.copy(prayerTimes = it)) }, modifier = Modifier.fillMaxWidth(), label = { Text("أوقات الصلاة الثابتة (اختياري)") })
    OutlinedTextField(value = a.mealsBreaks, onValueChange = { onA(a.copy(mealsBreaks = it)) }, modifier = Modifier.fillMaxWidth(), label = { Text("أوقات الطعام والاستراحات (اختياري)") })
    OutlinedTextField(value = a.personalTime, onValueChange = { onA(a.copy(personalTime = it)) }, modifier = Modifier.fillMaxWidth(), label = { Text("وقت القراءة/الترفيه اليومي (اختياري)") })
}

@Composable private fun StepPrefs(a: WizardAnswers, onA: (WizardAnswers) -> Unit) {
    Text("طريقة تنظيم الجدول", style = MaterialTheme.typography.titleMedium)
    Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = a.strictPlan, onClick = { onA(a.copy(strictPlan = true)) }); Text("جدول صارم بمواعيد محددة") }
    Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = !a.strictPlan, onClick = { onA(a.copy(strictPlan = false)) }); Text("جدول مرن (مهام بلا ساعات ثابتة)") }
    listOf(
        Triple("mixOldNew", "توزيع التراكمات مع الجديد في اليوم الواحد", a.mixOldNew),
        Triple("dailyReview", "وقت يومي ثابت للمراجعة", a.dailyReview),
        Triple("separateExams", "أقسام منفصلة للامتحانات والواجبات", a.separateExams),
        Triple("handleDelay", "خطة جاهزة لمعالجة التأخر وضياع اليوم", a.handleDelay)
    ).forEach { (key, label, v) -> Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(checked = v, onCheckedChange = { onA(when (key) {
            "mixOldNew" -> a.copy(mixOldNew = it); "dailyReview" -> a.copy(dailyReview = it)
            "separateExams" -> a.copy(separateExams = it); else -> a.copy(handleDelay = it) }) })
        Text(label) } }
    if (a.mode == "replan") Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(checked = a.keepDone, onCheckedChange = { onA(a.copy(keepDone = it)) })
        Text("الإبقاء على المهام المنجزة في الجدول الجديد") }
}

@Composable private fun StepExtras(a: WizardAnswers, onA: (WizardAnswers) -> Unit) {
    Text("طلعات وأيام خاصة", style = MaterialTheme.typography.titleMedium)
    OutlinedTextField(value = a.outings, onValueChange = { onA(a.copy(outings = it)) }, modifier = Modifier.fillMaxWidth(), label = { Text("أيام تتكرر عادة (جمعة عند العائلة، مناسبات…) — اختياري") })
    Text("تستطيع لاحقًا إعادة التخطيط بأسئلة أقل عندما تتغير الظروف فقط.", style = MaterialTheme.typography.bodySmall)
}

// ---------- الملخص ----------

@Composable fun WizardSummaryScreen(a: WizardAnswers, onEdit: () -> Unit, onCancel: () -> Unit, onNext: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("مراجعة إجاباتك", style = MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("النوع: ${if (a.mode == "replan") "إعادة تنظيم الجدول الحالي" else "جدول سنوي جديد"}")
            Text("المرحلة: ${a.stage.ifBlank { "—" }}")
            Text("المواد: ${a.subjects.ifBlank { "—" }}")
            if (a.teachers.isNotBlank()) Text("المدرسون: ${a.teachers}")
            if (a.oldLectures.isNotBlank()) Text("التراكمات: ${a.oldLectures}")
            if (a.newLectures.isNotBlank()) Text("الجديد المتوقع: ${a.newLectures}")
            Text("المدد: محاضرة ${a.lectureDur}د · واجب ${a.homeworkMin}د · مراجعة ${a.reviewMin}د")
            Text("النطاق: ${a.startDate.ifBlank { "؟" }} → ${a.endDate.ifBlank { "؟" }}" +
                (WizardVerify.daysBetween(a)?.let { " ($it يوم)" } ?: ""))
            Text("الروتين: استيقاظ ${Subjects.fmt12(a.wakeMin)} · نوم ${Subjects.fmt12(a.sleepMin)} · مدرسة ${Subjects.fmt12(a.schoolStart)}→${Subjects.fmt12(a.schoolEnd)}")
            Text("الحد اليومي: ${a.dailyGoalMin / 60} ساعات · الدوام: ${a.schoolDays}")
            Text("النمط: ${if (a.strictPlan) "صارم" else "مرن"} · تراكم+جديد: ${if (a.mixOldNew) "نعم" else "لا"} · مراجعة يومية: ${if (a.dailyReview) "نعم" else "لا"}")
            if (a.examDates.isNotBlank()) Text("الامتحانات: ${a.examDates}")
            if (a.finalGoal.isNotBlank()) Text("الهدف: ${a.finalGoal}")
        } }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onEdit, modifier = Modifier.weight(1f)) { Text("تعديل الإجابات") }
            OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("إلغاء") }
        }
        Button(onClick = onNext, enabled = a.isRequiredFilled(), modifier = Modifier.fillMaxWidth()) { Text("إنشاء البرومبت ✨") }
        if (!a.isRequiredFilled()) Text("أكمل الحقول المطلوبة (المرحلة، المواد، تاريخا البداية والنهاية) أولًا.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
    }
}

// ---------- شاشة البرومبت ----------

@Composable fun PromptScreen(vm: MainVm, a: WizardAnswers, onBack: () -> Unit, onGoImport: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prompt = remember(a) { WizardPromptBuilder.build(a) }
    var msg by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("البرومبت الجاهز", style = MaterialTheme.typography.headlineSmall)
        Text("١) انسخه أو شاركه ٢) أرسله لأداة الذكاء الاصطناعي ٣) نزّل ملف JSON الناتج ٤) عد واضغط «استيراد الجدول».")
        Card(Modifier.weight(1f)) {
            Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
                Text(prompt, style = MaterialTheme.typography.bodySmall)
            }
        }
        if (msg.isNotBlank()) Text(msg, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        Button(onClick = {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("rafiq-wizard-prompt", prompt))
            msg = "تم نسخ البرومبت ✅"
        }, modifier = Modifier.fillMaxWidth()) { Text("📋 نسخ البرومبت") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, prompt) }
                ctx.startActivity(Intent.createChooser(send, "مشاركة البرومبت مع…"))
            }, modifier = Modifier.weight(1f)) { Text("📤 مشاركة") }
            OutlinedButton(onClick = {
                val pkgs = listOf("com.openai.chat", "com.google.android.apps.gemini.canary",
                    "com.google.android.apps.bard", "com.microsoft.copilot", "com.meta.ai", "com.deepseek.chat")
                val pm = ctx.packageManager
                val target = pkgs.firstOrNull { pm.getLaunchIntentForPackage(it) != null }
                if (target != null) try { ctx.startActivity(pm.getLaunchIntentForPackage(target)) }
                    catch (e: ActivityNotFoundException) { msg = "تعذر فتح التطبيق — استخدم «مشاركة»." }
                else msg = "لم يُعثر على تطبيق ذكاء اصطناعي مثبت — استخدم «مشاركة» لإرسال البرومبت لأي تطبيق أو موقع."
            }, modifier = Modifier.weight(1f)) { Text("🤖 فتح أداة AI") }
        }
        Button(onClick = onGoImport, modifier = Modifier.fillMaxWidth()) { Text("⬇ استيراد ملف الجدول الجديد") }
        TextButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("‹ الرجوع للملخص") }
    }
}

// ---------- الاستيراد والمعاينة والاعتماد ----------

@Composable fun WizardImportScreen(vm: MainVm, a: WizardAnswers, onBack: () -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val bundle by vm.bundle.collectAsState(initial = ScheduleBundle())
    var parts by remember { mutableStateOf(listOf<String>()) }
    var result by remember { mutableStateOf<ScheduleParseResult?>(null) }
    var stats by remember { mutableStateOf<PlanStats?>(null) }
    var fileText by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var adopted by remember { mutableStateOf(false) }
    var prevScheduleId by remember { mutableStateOf<String?>(null) }
    var showAdoptConfirm by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    val openDoc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true
            try {
                val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
                val trimmed = text.trim()
                if (trimmed.startsWith("{") && trimmed.contains("\"rafiq_part\"") && !trimmed.contains("\"rafiq_schedule\"")) {
                    parts = parts + trimmed
                    message = "أُضيف جزء ${parts.size}. أضف بقية الأجزاء ثم اضغط «تحقق وتجميع»."
                    result = null
                } else {
                    fileText = trimmed
                    val r = ScheduleParser.parse(trimmed)
                    result = r
                    stats = r.file?.let { WizardVerify.stats(it, a) }
                    parts = emptyList()
                    message = if (r.ok) "الملف صالح ✅ راجع المعاينة ثم اعتمد." else "يوجد أخطاء — راجعها أدناه."
                }
            } catch (e: Exception) { message = "تعذر قراءة الملف: ${e.message ?: "خطأ"}" }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("استيراد الجدول الجديد", style = MaterialTheme.typography.headlineSmall)
        Text("اختر ملف JSON الذي أنتجه الذكاء الاصطناعي. لن يُستبدل جدولك الحالي قبل أن تعتمد أنت المعاينة.")
        Button(onClick = { openDoc.launch(arrayOf("application/json", "text/plain", "*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "جارٍ الفحص…" else "اختيار ملف الجدول") }
        if (parts.isNotEmpty()) {
            Text("الأجزاء المستلمة: ${parts.size}")
            Button(onClick = {
                val asm = PartAssembler.assemble(parts)
                if (asm.text != null) {
                    fileText = asm.text
                    val r = ScheduleParser.parse(asm.text)
                    result = r; stats = r.file?.let { WizardVerify.stats(it, a) }
                    message = if (r.ok) "اكتمل التجميع والملف صالح ✅" else "اكتمل التجميع لكن فحص الجدول أظهر أخطاء."
                } else message = asm.errors.joinToString("\n")
            }, modifier = Modifier.fillMaxWidth()) { Text("تحقق وتجميع الأجزاء") }
        }
        if (message.isNotBlank()) Text(message, style = MaterialTheme.typography.bodySmall)

        result?.let { r ->
            if (!r.ok) Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("أخطاء يجب إصلاحها في ملف الجدول:", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.titleSmall)
                Text(r.errorText(), style = MaterialTheme.typography.bodySmall)
            } }
            r.file?.let { f ->
                stats?.let { st ->
                    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("المعاينة", style = MaterialTheme.typography.titleMedium)
                        Text("الأيام: ${st.dayCount} · المهام: ${st.taskCount} · مجموع الدراسة: ${st.totalMin / 60}س ${st.totalMin % 60}د")
                        Text("محاضرات جديدة: ${st.newLectures} · تراكمات موزعة: ${st.oldLectures}")
                        val cur = bundle.tasks
                        if (cur.isNotEmpty()) Text("مقارنة بالجدول الحالي: حاليًا ${cur.size} مهمة، والجدول الجديد ${st.taskCount} مهمة.")
                        if (st.perSubject.isNotEmpty()) {
                            Text("التوزيع على المواد:", style = MaterialTheme.typography.titleSmall)
                            st.perSubject.forEach { (s2, n) -> Text("• $s2: $n مهام") }
                        }
                        if (st.highLoadDays.isNotEmpty()) {
                            Text("أيام ضغط مرتفع:", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.titleSmall)
                            st.highLoadDays.take(5).forEach { (d, m) -> Text("⚠ $d: ${m / 60}س ${m % 60}د") }
                        }
                        if (st.warnings.isNotEmpty()) {
                            Text("تحذيرات:", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.titleSmall)
                            st.warnings.take(6).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                        }
                        if (r.warnings.isNotEmpty()) { Text("ملاحظات الملف:", style = MaterialTheme.typography.titleSmall)
                            Text(r.warningText(), style = MaterialTheme.typography.bodySmall) }
                    } }
                }
            }
        }

        if (adopted) {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("✅ تم اعتماد الجدول الجديد بنجاح", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
                result?.file?.let { Text("النطاق: ${it.startDate ?: "؟"} → ${it.endDate ?: "؟"} · ${it.taskCount()} مهمة") }
                Text("الجدول السابق محفوظ داخل التطبيق (قسم الجداول) ولم تُمس إنجازاته.")
                prevScheduleId?.let { pid ->
                    OutlinedButton(onClick = {
                        scope.launch { vm.activateSchedule(pid) }
                        message = "تمت استعادة الجدول السابق."
                        adopted = false
                    }, modifier = Modifier.fillMaxWidth()) { Text("↩ استعادة الجدول السابق") }
                }
                OutlinedButton(onClick = { scope.launch { clearWizardDraft(ctx) }; onCancel() }, modifier = Modifier.fillMaxWidth()) { Text("إنهاء") }
            } }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("‹ تعديل البيانات") }
                OutlinedButton(onClick = { parts = emptyList(); result = null; stats = null; message = "" }, modifier = Modifier.weight(1f)) { Text("مسح") }
                TextButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("إلغاء العملية") }
            }
            if (result?.ok == true) Button(onClick = { showAdoptConfirm = true }, modifier = Modifier.fillMaxWidth()) { Text("اعتماد الجدول الجديد ✓") }
        }
    }

    if (showAdoptConfirm) {
        val f = result?.file
        AlertDialog(onDismissRequest = { showAdoptConfirm = false },
            title = { Text("تأكيد اعتماد الجدول الجديد") },
            text = { Text("سيصبح «${f?.meta?.name ?: "الجدول الجديد"}» هو الجدول الفعّال ابتداءً من اليوم، وتُعاد جدولة كل التنبيهات عليه. يبقى جدولك الحالي محفوظًا وتستطيع استعادته من هنا أو من قسم الجداول. هل أنت متأكد؟") },
            confirmButton = { TextButton(onClick = {
                showAdoptConfirm = false
                scope.launch {
                    busy = true
                    prevScheduleId = bundle.schedule?.scheduleId
                    vm.importSchedule(fileText, null)
                    adopted = true
                    busy = false
                    message = ""
                }
            }) { Text("نعم، اعتمد الجدول الجديد") } },
            dismissButton = { TextButton(onClick = { showAdoptConfirm = false }) { Text("تراجع") } })
    }
}
