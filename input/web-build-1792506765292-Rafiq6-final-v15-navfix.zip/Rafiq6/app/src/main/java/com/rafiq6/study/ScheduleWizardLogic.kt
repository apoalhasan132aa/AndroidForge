package com.rafiq6.study

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

// ---------- منطق معالج إنشاء/تغيير الجدول السنوي (نقي 100% — قابل للاختبار على JVM) ----------

data class WizardAnswers(
    val mode: String = "new",                 // new = جدول جديد · replan = إعادة تنظيم
    val stage: String = "",                   // المرحلة والصف
    val subjects: String = "",                // المواد مفصولة بفواصل
    val teachers: String = "",                // أسماء المدرسين (اختياري)
    val oldLectures: String = "",             // "فيزياء=12، كيمياء=8"
    val newLectures: String = "",              // "فيزياء=2 أسبوعيًا" أو أعداد
    val lectureDur: Int = 45,
    val homeworkMin: Int = 30,
    val reviewMin: Int = 30,
    val examDates: String = "",               // مواعيد الامتحانات (اختياري)
    val startDate: String = "",
    val endDate: String = "",
    val finalGoal: String = "",               // الامتحانات النهائية / الأهداف
    val schoolDays: String = "السبت,الأحد,الاثنين,الثلاثاء,الأربعاء,الخميس",
    val wakeMin: Int = 390, val sleepMin: Int = 1290,
    val schoolStart: Int = 480, val schoolEnd: Int = 840,
    val dailyGoalMin: Int = 360,
    val prayerTimes: String = "",
    val mealsBreaks: String = "",
    val personalTime: String = "",            // قراءة/ترفيه
    val outings: String = "",                 // أيام الطلعات المتكررة
    val strictPlan: Boolean = true,
    val mixOldNew: Boolean = true,
    val dailyReview: Boolean = true,
    val separateExams: Boolean = true,
    val handleDelay: Boolean = true,
    val keepDone: Boolean = true              // للوضع replan: الإبقاء على المنجز
) {
    fun isRequiredFilled(): Boolean =
        stage.isNotBlank() && subjects.isNotBlank() &&
            startDate.isNotBlank() && endDate.isNotBlank()
}

data class WizardStep(val id: String, val title: String, val optional: Boolean = false)

object WizardSteps {
    val all: List<WizardStep> = listOf(
        WizardStep("stage", "المرحلة والمواد"),
        WizardStep("teachers", "المدرسون والأعداد", optional = true),
        WizardStep("durations", "المدد ومواعيد الامتحانات", optional = true),
        WizardStep("range", "نطاق الجدول"),
        WizardStep("routine", "الروتين اليومي"),
        WizardStep("study", "وقت الدراسة والاستراحات"),
        WizardStep("prefs", "طريقة تنظيم الجدول"),
        WizardStep("extras", "طلعات وأيام خاصة", optional = true)
    )
    val count: Int get() = all.size
    fun indexOf(id: String): Int = all.indexOfFirst { it.id == id }
}

// ---------- ترميز المسودة (حفظ/استعادة الإجابات) ----------

object WizardDraftCodec {
    fun toJson(a: WizardAnswers): JSONObject = JSONObject().apply {
        put("mode", a.mode); put("stage", a.stage); put("subjects", a.subjects)
        put("teachers", a.teachers); put("oldLectures", a.oldLectures)
        put("newLectures", a.newLectures); put("examDates", a.examDates)
        put("startDate", a.startDate); put("endDate", a.endDate)
        put("finalGoal", a.finalGoal); put("schoolDays", a.schoolDays)
        put("prayerTimes", a.prayerTimes); put("mealsBreaks", a.mealsBreaks)
        put("personalTime", a.personalTime); put("outings", a.outings)
        put("lectureDur", a.lectureDur); put("homeworkMin", a.homeworkMin)
        put("reviewMin", a.reviewMin); put("wakeMin", a.wakeMin)
        put("sleepMin", a.sleepMin); put("schoolStart", a.schoolStart)
        put("schoolEnd", a.schoolEnd); put("dailyGoalMin", a.dailyGoalMin)
        put("strictPlan", a.strictPlan); put("mixOldNew", a.mixOldNew)
        put("dailyReview", a.dailyReview); put("separateExams", a.separateExams)
        put("handleDelay", a.handleDelay); put("keepDone", a.keepDone)
    }

    fun fromJson(o: JSONObject): WizardAnswers = WizardAnswers(
        mode = o.optString("mode", "new"), stage = o.optString("stage"),
        subjects = o.optString("subjects"), teachers = o.optString("teachers"),
        oldLectures = o.optString("oldLectures"), newLectures = o.optString("newLectures"),
        lectureDur = o.optInt("lectureDur", 45), homeworkMin = o.optInt("homeworkMin", 30),
        reviewMin = o.optInt("reviewMin", 30), examDates = o.optString("examDates"),
        startDate = o.optString("startDate"), endDate = o.optString("endDate"),
        finalGoal = o.optString("finalGoal"), schoolDays = o.optString("schoolDays", "السبت,الأحد"),
        wakeMin = o.optInt("wakeMin", 390), sleepMin = o.optInt("sleepMin", 1290),
        schoolStart = o.optInt("schoolStart", 480), schoolEnd = o.optInt("schoolEnd", 840),
        dailyGoalMin = o.optInt("dailyGoalMin", 360), prayerTimes = o.optString("prayerTimes"),
        mealsBreaks = o.optString("mealsBreaks"), personalTime = o.optString("personalTime"),
        outings = o.optString("outings"),
        strictPlan = o.optBoolean("strictPlan", true), mixOldNew = o.optBoolean("mixOldNew", true),
        dailyReview = o.optBoolean("dailyReview", true), separateExams = o.optBoolean("separateExams", true),
        handleDelay = o.optBoolean("handleDelay", true), keepDone = o.optBoolean("keepDone", true)
    )
}

// ---------- بنّاء البرومبت ----------

object WizardPromptBuilder {
    fun build(a: WizardAnswers): String {
        val schoolDays = a.schoolDays.split(",").filter { it.isNotBlank() }.map { it.trim() }
        return buildString {
            appendLine("أنت منظّم جداول دراسية سنوية لطالب مرحلة السادس العلمي. مهمتك إنشاء ملف JSON فقط وفق صيغة rafiq_schedule_v1.")
            appendLine("اقرأ إجابات الطالب كاملة، ولا تخترع أي محاضرة أو رقم أو اسم أو محتوى لم يذكره الطالب صراحةً.")
            appendLine()
            appendLine("=== بيانات الطالب ===")
            appendLine("- العملية: ${if (a.mode == "replan") "إعادة تنظيم جدول موجود مع الإبقاء على المهام المنجزة" else "إنشاء جدول سنوي جديد"}")
            appendLine("- المرحلة والصف: ${a.stage.ifBlank { "غير محددة" }}")
            appendLine("- المواد: ${a.subjects.ifBlank { "غير محددة" }}")
            if (a.teachers.isNotBlank()) appendLine("- المدرسون: ${a.teachers}")
            if (a.oldLectures.isNotBlank()) appendLine("- التراكمات لكل مادة: ${a.oldLectures}")
            if (a.newLectures.isNotBlank()) appendLine("- المحاضرات الجديدة المتوقعة: ${a.newLectures}")
            appendLine("- مدة المحاضرة: ${a.lectureDur} دقيقة · حل الواجبات: ${a.homeworkMin} دقيقة · المراجعة اليومية: ${a.reviewMin} دقيقة")
            if (a.examDates.isNotBlank()) appendLine("- مواعيد الامتحانات والتراكمات: ${a.examDates}")
            appendLine("- نطاق الجدول: ${a.startDate.ifBlank { "؟" }} إلى ${a.endDate.ifBlank { "؟" }}")
            if (a.finalGoal.isNotBlank()) appendLine("- الهدف النهائي: ${a.finalGoal}")
            appendLine("- أيام الدوام المدرسي: ${schoolDays.joinToString("، ")}")
            appendLine("- الاستيقاظ: ${fmt(a.wakeMin)} · النوم: ${fmt(a.sleepMin)}")
            appendLine("- المدرسة: ${fmt(a.schoolStart)} → ${fmt(a.schoolEnd)}")
            appendLine("- الحد الأقصى للدراسة اليومية: ${a.dailyGoalMin} دقيقة")
            if (a.prayerTimes.isNotBlank()) appendLine("- أوقات الصلاة: ${a.prayerTimes}")
            if (a.mealsBreaks.isNotBlank()) appendLine("- الطعام والاستراحات: ${a.mealsBreaks}")
            if (a.personalTime.isNotBlank()) appendLine("- وقت شخصي (قراءة/ترفيه): ${a.personalTime}")
            if (a.outings.isNotBlank()) appendLine("- أيام طلعات أو ظروف متكررة: ${a.outings}")
            appendLine()
            appendLine("=== تفضيلات التنظيم ===")
            appendLine("- نمط الجدول: ${if (a.strictPlan) "صارم بمواعيد محددة" else "مرن بدون مواعيد ثابتة"}")
            appendLine("- توزيع التراكمات مع الجديد: ${yn(a.mixOldNew)}")
            appendLine("- مراجعة يومية ثابتة: ${yn(a.dailyReview)}")
            appendLine("- أقسام منفصلة للامتحانات والواجبات: ${yn(a.separateExams)}")
            appendLine("- معالجة التأخر وضياع اليوم: ${yn(a.handleDelay)}")
            if (a.mode == "replan") appendLine("- مهم جدًا: أبقِ المهام المنجزة كما هي؛ فقط أعد توزيع المتبقي")
            appendLine()
            appendLine("=== خطوات إلزامية قبل الإخراج ===")
            appendLine("1. احسب حجم التراكمات لكل مادة ومجموعها من بيانات الطالب.")
            appendLine("2. احسب عدد الأيام المتاحة بين تاريخ البداية والنهاية.")
            appendLine("3. وزّع المحاضرات الجديدة والتراكمات والمراجعات والامتحانات على الأيام مع مراعاة أيام الدوام والنوم والصلوات والطعام.")
            appendLine("4. لا تتجاوز الحد اليومي (${a.dailyGoalMin} دقيقة) إلا بيوم خفيف مسوّغ وموضّح في الملاحظات.")
            appendLine("5. لا تخترع محتوى: إذا نقصت معلومة ضرورية أدرجها في مصفوفة issues ولا تخمّن.")
            appendLine("6. أظهر أي تعارض أو نقص بدل إخفائه.")
            appendLine("7. كل مهمة يجب أن يكون لها تاريخ ومادة ونوع وعنوان ومدة (>0)؛ الأوقات الثابتة اختيارية وإن وُضعت فبصيغة HH:MM.")
            appendLine("8. تحقق أن مجموع المحاضرات الموزعة يساوي الأعداد المطلوبة لكل مادة.")
            appendLine("9. إذا كان الجدول كبيرًا جدًا، قسّمه إلى أجزاء JSON صغيرة وفق بروتوكول الأجزاء أدناه.")
            appendLine("10. أخرج JSON فقط بلا مقدمات ولا Markdown ولا نص خارج JSON.")
            appendLine()
            appendLine("=== مخطط ملف الإخراج (rafiq_schedule_v1) ===")
            appendLine("""{"format":"rafiq_schedule","formatVersion":1,"metadata":{"scheduleName":"...","stage":"..."},"startDate":"YYYY-MM-DD","endDate":"YYYY-MM-DD","days":[{"date":"YYYY-MM-DD","weekday":"...","tasks":[{"id":"فريد","subject":"المادة","type":"newLecture|oldLecture|review|dailyExam|cumulativeExam|quiz|homework|commitment","title":"عنوان واضح","lectureNo":1,"durationMin":45,"start":"HH:MM","end":"HH:MM","note":"..."}],"constraints":[{"id":"...","subject":"التزام","type":"commitment","title":"المدرسة","durationMin":...,"start":"...","end":"..."}]}]}""")
            appendLine("الأنواع المسموحة: newLecture (جديدة) · oldLecture (تراكم) · review · homework · dailyExam · cumulativeExam · quiz · commitment (التزام ثابت كالمدرسة/الغداء/النوم).")
            appendLine()
            appendLine("=== بروتوكول الأجزاء (فقط إذا كان الملف كبيرًا) ===")
            appendLine("أخرج كل جزء كملف JSON مستقل وصالح بنفسه:")
            appendLine("""{"format":"rafiq_part","partIndex":1,"totalParts":3,"payload":{"metadata":{"scheduleName":"..."},"startDate":"YYYY-MM-DD","endDate":"YYYY-MM-DD","days":[<بعض أيام الجدول كاملة، بلا تقطيع أي يوم بين جزأين>]}}""")
            appendLine("الجزء الأول يحمل metadata والتواريخ، وكل جزء يحمل مجموعة كاملة من أيام days لا تتقاطع مع غيرها.")
        }
    }

    private fun yn(b: Boolean) = if (b) "نعم" else "لا"
    private fun fmt(min: Int) = "%02d:%02d".format(min / 60, min % 60)
}

// ---------- تجميع الأجزاء ----------

object PartAssembler {
    data class Assembly(val text: String?, val errors: List<String>)

    /**
     * كل جزء JSON مستقل: {"format":"rafiq_part","partIndex":i,"totalParts":n,
     * "payload":{"metadata":{...},"startDate":"...","endDate":"...","days":[...جزء من الأيام...]}}
     * يجمع التجميع metadata ونطاق التواريخ من الجزء الأول، ويدمج مصفوفات days بالترتيب.
     */
    fun assemble(parts: List<String>): Assembly {
        if (parts.isEmpty()) return Assembly(null, listOf("لا توجد أجزاء."))
        val metas = mutableListOf<Triple<Int, Int, JSONObject>>()
        val errors = mutableListOf<String>()
        parts.forEachIndexed { i, raw ->
            try {
                val o = JSONObject(raw.trim())
                if (o.optString("format") != "rafiq_part") {
                    errors += "الجزء ${i + 1} ليس جزءًا (format=rafiq_part)."
                    return@forEachIndexed
                }
                val payload = o.optJSONObject("payload")
                    ?: run { errors += "الجزء ${i + 1} يفتقد payload."; return@forEachIndexed }
                if (!payload.has("days")) { errors += "الجزء ${i + 1} يفتقد payload.days."; return@forEachIndexed }
                metas += Triple(o.getInt("partIndex"), o.getInt("totalParts"), payload)
            } catch (e: Exception) { errors += "الجزء ${i + 1} ليس JSON صالحًا." }
        }
        if (errors.isNotEmpty()) return Assembly(null, errors)
        val total = metas.first().second
        if (metas.any { it.second != total }) return Assembly(null, listOf("عدد الأجزاء الكلي غير متطابق بين الأجزاء."))
        if (metas.size != total) return Assembly(null, listOf("الأجزاء المستلمة ${metas.size} من أصل $total."))
        val sorted = metas.sortedBy { it.first }
        if (sorted.map { it.first } != (1..total).toList())
            return Assembly(null, listOf("أرقام الأجزاء غير متسلسلة: ${sorted.map { it.first }}"))

        val first = sorted.first().third
        val days = JSONArray()
        val seenDates = mutableSetOf<String>()
        sorted.forEach { (_, _, payload) ->
            val arr = payload.getJSONArray("days")
            for (j in 0 until arr.length()) {
                val day = arr.getJSONObject(j)
                val d = day.optString("date")
                if (d.isNotBlank() && !seenDates.add(d)) errors += "تاريخ مكرر بين الأجزاء: $d"
                days.put(day)
            }
        }
        if (errors.isNotEmpty()) return Assembly(null, errors.distinct())
        val root = JSONObject().apply {
            put("format", "rafiq_schedule"); put("formatVersion", 1)
            put("metadata", first.optJSONObject("metadata") ?: JSONObject())
            if (first.has("startDate")) put("startDate", first.getString("startDate"))
            if (first.has("endDate")) put("endDate", first.getString("endDate"))
            put("days", days)
        }
        return Assembly(root.toString(), emptyList())
    }
}

// ---------- ملخص المعاينة والتحقق الإضافي ----------

data class PlanStats(
    val dayCount: Int, val taskCount: Int, val totalMin: Int,
    val perSubject: Map<String, Int>, val highLoadDays: List<Pair<String, Int>>,
    val oldLectures: Int, val newLectures: Int,
    val expectedOld: Map<String, Int>, val missingOld: Map<String, Int>,
    val warnings: List<String>
)

object WizardVerify {
    fun expectedOldMap(a: WizardAnswers): Map<String, Int> =
        a.oldLectures.split("،", ",").mapNotNull { chunk ->
            val p = chunk.split("=", ":").map { it.trim() }
            if (p.size == 2) p[0] to (p[1].toIntOrNull() ?: return@mapNotNull null) else null
        }.toMap()

    fun stats(file: ScheduleFile, a: WizardAnswers): PlanStats {
        val perSubject = mutableMapOf<String, Int>()
        var total = 0
        var oldL = 0; var newL = 0
        val daily = mutableMapOf<String, Int>()
        file.days.forEach { d ->
            var dayMin = 0
            d.tasks.forEach { t ->
                perSubject[t.subject] = (perSubject[t.subject] ?: 0) + 1
                total += t.durationMin; dayMin += t.durationMin
                if (t.type == TaskTypes.OLD) oldL++
                if (t.type == TaskTypes.NEW) newL++
            }
            daily[d.date.toString()] = dayMin
        }
        val expected = expectedOldMap(a)
        val actualOldPerSubject = mutableMapOf<String, Int>()
        file.days.forEach { d -> d.tasks.filter { it.type == TaskTypes.OLD }.forEach { t ->
            actualOldPerSubject[t.subject] = (actualOldPerSubject[t.subject] ?: 0) + 1 } }
        val missing = expected.mapValues { (sub, n) -> (n - (actualOldPerSubject[sub] ?: 0)).coerceAtLeast(0) }
            .filterValues { it > 0 }
        val warnings = mutableListOf<String>()
        val high = daily.filter { it.value > a.dailyGoalMin }.toList().sortedByDescending { it.second }
        high.forEach { (d, m) -> warnings += "يوم $d يتجاوز الحد اليومي (${m / 60}س ${m % 60}د > ${a.dailyGoalMin / 60}س)." }
        if (expected.isNotEmpty() && missing.isNotEmpty())
            warnings += "نواقص التراكمات: " + missing.entries.joinToString("، ") { "${it.key}: ${it.value}" }
        val start = file.startDate; val end = file.endDate
        if (start != null && end != null) {
            val days = ChronoUnit.DAYS.between(start, end) + 1
            if (days < file.days.size) warnings += "عدد الأيام في الملف (${file.days.size}) أكبر من نطاق التواريخ ($days)."
        }
        return PlanStats(file.days.size, file.taskCount(), total, perSubject.toList().sortedByDescending { it.second }.toMap(),
            high, oldL, newL, expected, missing, warnings.distinct())
    }

    fun validateRange(a: WizardAnswers): String? {
        if (a.startDate.isBlank() || a.endDate.isBlank()) return null
        return try {
            val s = LocalDate.parse(a.startDate); val e = LocalDate.parse(a.endDate)
            when {
                e < s -> "تاريخ النهاية يسبق تاريخ البداية."
                ChronoUnit.DAYS.between(s, e) > 370 -> "النطاق يتجاوز سنة كاملة — هل هذا مقصود؟"
                else -> null
            }
        } catch (e: Exception) { "التواريخ يجب أن تكون بصيغة YYYY-MM-DD." }
    }

    fun daysBetween(a: WizardAnswers): Long? = try {
        if (a.startDate.isBlank() || a.endDate.isBlank()) null
        else ChronoUnit.DAYS.between(LocalDate.parse(a.startDate), LocalDate.parse(a.endDate)) + 1
    } catch (e: Exception) { null }
}
