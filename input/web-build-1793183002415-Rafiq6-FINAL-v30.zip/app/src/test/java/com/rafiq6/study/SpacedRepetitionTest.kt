package com.rafiq6.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/** اختبارات الميزة 5 (المراجعة حسب النسيان) — تغطي البنود 10 و11 من قائمة الاختبارات: إنشاء مراجعات
 * مستقبلية وحفظ تقييم التذكر، وعدم تكرار المراجعات عند إعادة فتح التطبيق (معرّف ثابت لكل مرحلة). */
class SpacedRepetitionTest {
    private fun settings(dailyGoalMin: Int = 900) = Settings(
        wakeMin = 6 * 60, schoolStart = 8 * 60, schoolEnd = 14 * 60,
        sleepMin = 22 * 60, breakMin = 15, dailyGoalMin = dailyGoalMin, maxPostponeDays = 7
    )

    private val today = LocalDate.of(2026, 10, 27)

    private fun item(stage: Int = 0) = ReviewItemEntity(
        id = "r1", scheduleId = "s", subject = "فيزياء", title = "قانون نيوتن الثاني",
        lectureNo = 5, studyDate = today.toString(), notes = "ليش القوة = الكتلة × التسارع؟", stage = stage
    )

    @Test fun `default intervals follow tomorrow then a few days then a week`() {
        assertEquals(1, SpacedRepetitionEngine.nextIntervalDays(0, ReviewRating.MEDIUM))
        assertEquals(4, SpacedRepetitionEngine.nextIntervalDays(1, ReviewRating.MEDIUM))
        assertEquals(7, SpacedRepetitionEngine.nextIntervalDays(2, ReviewRating.MEDIUM))
    }

    @Test fun `easy rating pushes the next review further than medium`() {
        val easy = SpacedRepetitionEngine.nextIntervalDays(1, ReviewRating.EASY)
        val medium = SpacedRepetitionEngine.nextIntervalDays(1, ReviewRating.MEDIUM)
        assertTrue(easy > medium)
    }

    @Test fun `hard rating pulls the next review closer than medium`() {
        val hard = SpacedRepetitionEngine.nextIntervalDays(2, ReviewRating.HARD)
        val medium = SpacedRepetitionEngine.nextIntervalDays(2, ReviewRating.MEDIUM)
        assertTrue(hard < medium)
    }

    @Test fun `interval never drops below one day even after a hard rating`() {
        assertTrue(SpacedRepetitionEngine.nextIntervalDays(0, ReviewRating.HARD) >= 1)
    }

    @Test fun `first scheduled review lands after the study date, never on or before it`() {
        val task = SpacedRepetitionEngine.scheduleNext(item(), ReviewRating.MEDIUM, today, emptyList(), settings())
        assertNotNull(task)
        assertTrue(LocalDate.parse(task!!.date).isAfter(today))
    }

    @Test fun `review task is its own type, separate from lectures and homework`() {
        val task = SpacedRepetitionEngine.scheduleNext(item(), ReviewRating.MEDIUM, today, emptyList(), settings())!!
        assertEquals(TaskTypes.REVIEW, task.type)
        assertEquals("r1", task.reviewItemId)
    }

    @Test fun `review task never invents a title beyond what the user entered`() {
        val task = SpacedRepetitionEngine.scheduleNext(item(), ReviewRating.MEDIUM, today, emptyList(), settings())!!
        assertTrue(task.title.contains("قانون نيوتن الثاني"))
        assertEquals(item().notes, task.note)
    }

    @Test fun `each stage produces a stable unique task id so reopening the app never duplicates it`() {
        val t1 = SpacedRepetitionEngine.scheduleNext(item(stage = 0), ReviewRating.MEDIUM, today, emptyList(), settings())!!
        val t1Again = SpacedRepetitionEngine.scheduleNext(item(stage = 0), ReviewRating.MEDIUM, today, emptyList(), settings())!!
        assertEquals(t1.id, t1Again.id)   // نفس المرحلة ⇒ نفس المعرّف دائمًا، فلا تكرار عند إعادة الحساب
        val t2 = SpacedRepetitionEngine.scheduleNext(item(stage = 1), ReviewRating.MEDIUM, today, emptyList(), settings())!!
        assertTrue(t1.id != t2.id)
    }

    @Test fun `review respects the daily study limit like any other task`() {
        val busyDay = (0..30).map { i ->
            val d = today.plusDays((i + 1).toLong())
            UiTask(TaskEntity(
                id = "s::full$i", scheduleId = "s", sourceId = "full$i", date = d.toString(),
                dayName = ScheduleParser.weekday(d), subject = "رياضيات", type = TaskTypes.NEW,
                title = "ممتلئ", lectureNo = null, durationMin = 900, startMin = 360, endMin = 1260
            ))
        }
        val task = SpacedRepetitionEngine.scheduleNext(item(), ReviewRating.MEDIUM, today, busyDay, settings(dailyGoalMin = 900), horizonDays = 31)
        assertNull(task)   // كل الأيام ممتلئة بالكامل ضمن الحد اليومي — لا مكان لمراجعة 20 دقيقة
    }

    @Test fun `overdue reviews reuse the same balanced redistribution as feature 1`() {
        val overdueReview = UiTask(TaskEntity(
            id = "s::revLate", scheduleId = "s", sourceId = "revLate", date = today.minusDays(3).toString(),
            dayName = ScheduleParser.weekday(today.minusDays(3)), subject = "فيزياء", type = TaskTypes.REVIEW,
            title = "مراجعة: قانون نيوتن", lectureNo = null, durationMin = 20, startMin = null, endMin = null,
            flexible = true, reviewItemId = "r1"
        ))
        val plan = SpacedRepetitionEngine.rebalanceOverdueReviews(listOf(overdueReview), today, settings())
        assertEquals(1, plan.movedCount)
        assertTrue(LocalDate.parse(plan.moves.single().toDate) >= today)
    }
}
