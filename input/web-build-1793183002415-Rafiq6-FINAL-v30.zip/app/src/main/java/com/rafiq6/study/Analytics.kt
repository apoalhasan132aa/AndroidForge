package com.rafiq6.study

import java.time.LocalDate

// ============================================================
// الميزة 2: إحصائيات الإنجاز الحقيقية (Study Analytics)
// منطق نقي (pure) يعتمد فقط على بيانات المهام الفعلية وسجل المؤقت
// (UiTask.done / UiTask.actualMin)، ولا يغيّر أي حالة — القراءة فقط.
// لا علاقة له بعدد مرات فتح التطبيق أو بدء المؤقت دون إنجاز فعلي.
// ============================================================

enum class StatsPeriod { WEEK, MONTH, ALL }

/** إحصائيات مادة واحدة ضمن الفترة المختارة. "Old" = محاضرات التراكم (قديمة)، "New" = محاضرات جديدة. */
data class SubjectAnalytics(
    val subject: String,
    val newTotal: Int, val newDone: Int,
    val oldTotal: Int, val oldDone: Int,
    val completedCount: Int,     // كل المهام المنجزة لهذه المادة ضمن الفترة (كل الأنواع)
    val overdueCount: Int,
    val actualMin: Int,          // الوقت الفعلي المسجل (من سجل المؤقت عند توفره)
    val plannedMin: Int          // مجموع المدد المخططة لكل مهام المادة ضمن الفترة
) {
    val newPct: Int get() = if (newTotal == 0) 0 else 100 * newDone / newTotal
    val oldPct: Int get() = if (oldTotal == 0) 0 else 100 * oldDone / oldTotal
    val newRemaining: Int get() = newTotal - newDone
    val oldRemaining: Int get() = oldTotal - oldDone
}

/** مقارنة الإنجاز بين هذا الأسبوع والأسبوع السابق. hasLastWeekData=false يعني بيانات الأسبوع الماضي غير متوفرة فعليًا (لا تُعرض كرقم). */
data class WeekComparison(
    val thisWeekDone: Int, val lastWeekDone: Int,
    val thisWeekActualMin: Int, val lastWeekActualMin: Int,
    val hasLastWeekData: Boolean
) {
    val deltaDone: Int get() = thisWeekDone - lastWeekDone
}

data class DayStudyLoad(val date: String, val plannedMin: Int, val actualMin: Int)

data class AppAnalytics(
    val periodLabel: String,
    val subjectFilter: String?,
    val totalCompleted: Int,
    val overallPct: Int,
    val overdueCount: Int,
    val committedDays: Int,            // عدد أيام الالتزام بالخطة (إنجاز ≥70% من مهام اليوم، ولليوم المنتهي فقط)
    val actualMinToday: Int,
    val weeklyActualMin: Int,
    val weeklyPlannedMin: Int,
    val perSubject: List<SubjectAnalytics>,
    val weekComparison: WeekComparison,
    val weeklyChart: List<DayStudyLoad>,   // آخر 7 أيام: مخطط مخطط مقابل فعلي
    val hasAnyData: Boolean                 // false = لا توجد مهام ضمن الفترة/الفلتر المختار إطلاقًا
)

object StudyAnalytics {
    private const val COMMIT_THRESHOLD_PCT = 70

    private fun parseDate(s: String): LocalDate? = runCatching { LocalDate.parse(s) }.getOrNull()

    private fun periodRange(period: StatsPeriod, today: LocalDate): Pair<LocalDate?, LocalDate?> = when (period) {
        StatsPeriod.WEEK -> today.minusDays(6) to today     // آخر 7 أيام بما فيها اليوم
        StatsPeriod.MONTH -> today.withDayOfMonth(1) to today
        StatsPeriod.ALL -> null to null
    }

    /**
     * يحسب كل إحصائيات الشاشة دفعة واحدة. allTasks: كل مهام الجدول النشط (غير مفلترة).
     * subjectFilter: اسم مادة محدد أو null لكل المواد. period: نافذة الفترة الزمنية.
     */
    fun analyze(
        allTasks: List<UiTask>,
        subjectFilter: String?,
        period: StatsPeriod,
        today: LocalDate = Subjects.now().toLocalDate()
    ): AppAnalytics {
        val bySubject = allTasks.filter { subjectFilter == null || it.subject == subjectFilter }
        val (from, to) = periodRange(period, today)
        val scoped = bySubject.filter { t ->
            val d = parseDate(t.date) ?: return@filter false
            (from == null || !d.isBefore(from)) && (to == null || !d.isAfter(to))
        }

        val overdue = scoped.count { !it.done && (parseDate(it.date)?.isBefore(today) == true) }
        val completed = scoped.count { it.done }
        val overallPct = if (scoped.isEmpty()) 0 else 100 * completed / scoped.size

        // أيام الالتزام: من بين أيام الفترة التي انتهت فعلًا (تاريخها <= اليوم ولها مهام)، كم يومًا بلغ ≥70% إنجازًا.
        val finishedDays = scoped.filter { val d = parseDate(it.date); d != null && !d.isAfter(today) }.groupBy { it.date }
        val committedDays = finishedDays.count { (_, list) -> list.isNotEmpty() && 100 * list.count { t -> t.done } / list.size >= COMMIT_THRESHOLD_PCT }

        val subjects = bySubject.map { it.subject }.distinct().sorted()
        val perSubject = subjects.map { subj -> subjectAnalytics(subj, scoped.filter { it.subject == subj }, today) }

        val weekCmp = weekComparison(bySubject, today)

        val last7 = (0..6).map { today.minusDays(it.toLong()) }.reversed()
        val weeklyChart = last7.map { d ->
            val dayTasks = bySubject.filter { it.date == d.toString() }
            DayStudyLoad(
                date = d.toString(),
                plannedMin = dayTasks.sumOf { it.durationMin },
                actualMin = dayTasks.filter { it.done }.sumOf { it.actualMin ?: 0 }
            )
        }

        return AppAnalytics(
            periodLabel = when (period) { StatsPeriod.WEEK -> "آخر 7 أيام"; StatsPeriod.MONTH -> "هذا الشهر"; StatsPeriod.ALL -> "كل الفترة" },
            subjectFilter = subjectFilter,
            totalCompleted = completed,
            overallPct = overallPct,
            overdueCount = overdue,
            committedDays = committedDays,
            actualMinToday = bySubject.filter { it.date == today.toString() && it.done }.sumOf { it.actualMin ?: 0 },
            weeklyActualMin = weeklyChart.sumOf { it.actualMin },
            weeklyPlannedMin = weeklyChart.sumOf { it.plannedMin },
            perSubject = perSubject,
            weekComparison = weekCmp,
            weeklyChart = weeklyChart,
            hasAnyData = scoped.isNotEmpty()
        )
    }

    private fun subjectAnalytics(subject: String, tasks: List<UiTask>, today: LocalDate): SubjectAnalytics {
        val news = tasks.filter { it.type == TaskTypes.NEW }
        val olds = tasks.filter { it.type == TaskTypes.OLD }
        val overdue = tasks.count { !it.done && (parseDate(it.date)?.isBefore(today) == true) }
        return SubjectAnalytics(
            subject = subject,
            newTotal = news.size, newDone = news.count { it.done },
            oldTotal = olds.size, oldDone = olds.count { it.done },
            completedCount = tasks.count { it.done },
            overdueCount = overdue,
            actualMin = tasks.filter { it.done }.sumOf { it.actualMin ?: 0 },
            plannedMin = tasks.sumOf { it.durationMin }
        )
    }

    private fun weekComparison(tasks: List<UiTask>, today: LocalDate): WeekComparison {
        val thisStart = today.minusDays(6)
        val lastStart = thisStart.minusDays(7)
        val lastEnd = thisStart.minusDays(1)
        val thisWeek = tasks.filter { val d = parseDate(it.date); d != null && !d.isBefore(thisStart) && !d.isAfter(today) }
        val lastWeek = tasks.filter { val d = parseDate(it.date); d != null && !d.isBefore(lastStart) && !d.isAfter(lastEnd) }
        // بيانات الأسبوع الماضي "متوفرة" فقط إن كان للجدول مهام بتاريخ يسبق أو يساوي نهاية ذلك الأسبوع فعلًا،
        // وإلا فهذا يعني أن الجدول لم يبدأ بعد في ذلك التاريخ — لا نعرض 0% وكأنه إنجاز حقيقي.
        val hasData = tasks.any { val d = parseDate(it.date); d != null && !d.isAfter(lastEnd) }
        return WeekComparison(
            thisWeekDone = thisWeek.count { it.done },
            lastWeekDone = lastWeek.count { it.done },
            thisWeekActualMin = thisWeek.filter { it.done }.sumOf { it.actualMin ?: 0 },
            lastWeekActualMin = lastWeek.filter { it.done }.sumOf { it.actualMin ?: 0 },
            hasLastWeekData = hasData
        )
    }
}
