package com.rafiq6.study

import android.app.AlarmManager
import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.graphics.PixelFormat
import android.telecom.TelecomManager
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

/**
 * حارس التركيز النسخة المعززة:
 * - فحص كل ثانية بدل ثانيتين، وإعادة فورية للتطبيق المسموح بأي محاولة خروج.
 * - كشف مزدوج للتطبيق الأمامي (أحداث الاستخدام + آخر وقت استخدام) فلا ينخدع.
 * - START_STICKY + نبضة دقيقية (GuardHeartbeat) تعيد تشغيله إذا قتلته إدارة الطاقة (MIUI).
 */
class FocusGuardService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var lastFg: String? = null     // آخر تطبيق أمامي معروف (يُحتفظ به بين الفحوص)
    private var lastQuery = 0L
    private var overlayView: View? = null

    /** نافذة شفافة 1×1 تبقى ظاهرة: تُبقي للخدمة حق فتح الأنشطة من الخلفية (مطلوب في أندرويد 15). */
    private fun addOverlay() {
        if (overlayView != null || !overlayGranted(this)) return
        runCatching {
            val v = View(this)
            val lp = WindowManager.LayoutParams(1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT)
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(v, lp)
            overlayView = v
        }
    }
    private fun removeOverlay() {
        overlayView?.let { v -> runCatching { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) } }
        overlayView = null
    }

    private fun isExempt(pkg: String, allowed: List<String>): Boolean {
        if (pkg == packageName || pkg in allowed || pkg in SYSTEM_EXEMPT) return true
        val dialer = runCatching { (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage }.getOrNull()
        if (pkg == dialer) return true
        val ime = runCatching { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .enabledInputMethodList.map { it.packageName } }.getOrDefault(emptyList())
        return pkg in ime
    }

    companion object {
        const val CH = "focus_guard"
        private const val NID = 7103
        @Volatile var isRunning = false; private set

        fun start(c: Context) { runCatching { ContextCompat.startForegroundService(c, Intent(c, FocusGuardService::class.java)) } }
        fun stop(c: Context) { runCatching { c.stopService(Intent(c, FocusGuardService::class.java)); FocusGuardHeartbeat.stop(c) } }

        /** فحص صحيح وفعّال لإذن «بيانات الاستخدام» عبر AppOps — فوري ولا نتائج مضللة. */
        /** إذن «العرض فوق التطبيقات»: بدونه يمنع أندرويد 10+ الخدمة من فتح تطبيق من الخلفية فلا يرجعك الحارس. */
        fun overlayGranted(c: Context): Boolean = Settings.canDrawOverlays(c)

        private val SYSTEM_EXEMPT = setOf("com.android.systemui", "android",
            "com.google.android.permissioncontroller", "com.android.permissioncontroller")

        fun usageGranted(c: Context): Boolean {
            val appOps = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
            else @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
            return mode == AppOpsManager.MODE_ALLOWED
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); isRunning = true }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "حارس التركيز",
            NotificationManager.IMPORTANCE_LOW).apply { description = "يمنع الخروج من التطبيق المسموح أثناء جلسة التركيز" })
        val pi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE)
        startForeground(NID, NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setContentTitle("جلسة تركيز جارية 🔒")
            .setContentText("الحارس يرجعك للتطبيق فورًا — اضغط هنا للعودة إلى رفيق")
            .setContentIntent(pi).setOngoing(true).build())

        addOverlay()
        job?.cancel()
        job = scope.launch {
            var lastRelaunch = 0L
            while (true) {
                val s = FocusStore.state(this@FocusGuardService)
                val nowE = SystemClock.elapsedRealtime(); val nowW = System.currentTimeMillis()
                if (!s.running || s.sessionId.isEmpty() || FocusMath.isExpired(s, nowE, nowW)) {
                    FocusGuardHeartbeat.stop(this@FocusGuardService)
                    stopSelf(); return@launch
                }
                if (usageGranted(this@FocusGuardService)) {
                    val top = topPackage()
                    if (top != null && !isExempt(top, s.allowed) && nowE - lastRelaunch > 700) {
                        lastRelaunch = nowE
                        val target = s.allowed.firstOrNull()
                        if (target != null) FocusLockdown.launch(this@FocusGuardService, target, s.enforced)
                        else runCatching { startActivity(Intent(this@FocusGuardService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    }
                }
                delay(1000)
            }
        }
        return START_STICKY
    }

    /**
     * التطبيق الأمامي الآن. نقرأ الأحداث الجديدة فقط ونحتفظ بآخر تطبيق أمامي؛
     * (القديم كان يتجاهل أي حدث أقدم من 15 ثانية فيتوقف الحارس عن الرد إذا بقيت في تطبيق آخر).
     */
    private fun topPackage(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val from = if (lastQuery == 0L) now - 600_000 else lastQuery - 1_500
        runCatching {
            val events = usm.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                    e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) lastFg = e.packageName
            }
            lastQuery = now
        }
        return lastFg
    }

    override fun onDestroy() { job?.cancel(); removeOverlay(); isRunning = false; super.onDestroy() }
}

/** نبضة كل دقيقة أثناء الجلسة: تعيد تشغيل الحارس إذا قتلته إدارة طاقة الروم. */
object FocusGuardHeartbeat {
    private const val REQ = 7104
    private fun pi(c: Context) = PendingIntent.getBroadcast(c, REQ,
        Intent(c, GuardHeartbeatReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun arm(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        runCatching {
            val trigger = System.currentTimeMillis() + 60_000
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi(c))
            else am.setWindow(AlarmManager.RTC_WAKEUP, trigger, 30_000, pi(c))
        }
    }
    fun stop(c: Context) { runCatching { (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c)) } }
}

class GuardHeartbeatReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val go = goAsync()
        try { runBlocking {
            val s = FocusStore.state(c)
            val alive = s.running && s.sessionId.isNotEmpty() &&
                !FocusMath.isExpired(s, SystemClock.elapsedRealtime(), System.currentTimeMillis())
            if (!alive) { FocusGuardService.stop(c) }
            else {
                if (!FocusGuardService.isRunning) FocusGuardService.start(c)   // إحياء بعد القتل
                FocusGuardHeartbeat.arm(c)                                       // الجولة التالية
            }
        } } finally { go.finish() }
    }
}
