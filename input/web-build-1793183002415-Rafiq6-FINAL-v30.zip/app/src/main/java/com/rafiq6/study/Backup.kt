package com.rafiq6.study

import android.content.Context
import kotlinx.coroutines.flow.first
import java.io.File

object Backup {
    private suspend fun collect(c: Context): BackupData {
        val db = AppDb.get(c)
        val bank = db.bank()
        return BackupData(
            schedules = db.dao().schedules().first(),
            tasks = db.dao().allTasks().first(),
            progress = db.dao().allProgress().first(),
            activities = db.act().all2().first(),
            documents = bank.documentsOnce(), pageTexts = bank.pageTextsOnce(), questions = bank.questionsOnce(),
            attempts = bank.attemptsOnce(), answers = bank.answersOnce(),
            settings = Prefs.get(c),
            focusHistory = FocusHistory.export(c),
            reviewItems = db.reviewDao().allOnce()
        )
    }

    private suspend fun exportTo(c: Context, f: File): File {
        val json = BackupCodec.toJson(collect(c), System.currentTimeMillis())
        f.parentFile?.mkdirs(); f.writeText(json.toString(2)); return f
    }

    suspend fun export(c: Context): File = exportTo(c, File(c.cacheDir, "backups/rafiq6-full-backup.json"))

    /** نسخة أمان تلقائية من الحالة الحالية قبل أي استرجاع (في filesDir لا في الكاش). */
    suspend fun safetySnapshot(c: Context): File = exportTo(c, File(c.filesDir, "backups/pre-restore.json"))

    /** فحص كامل بلا أي كتابة. */
    fun preview(json: String): BackupParseResult = BackupCodec.parse(json)

    suspend fun currentSummary(c: Context): BackupSummary = BackupCodec.summarize(collect(c), null)

    /** يطبّق بيانات سبق فحصها: القاعدة في معاملة واحدة، ثم الإعدادات وسجل التركيز إن وُجدا في النسخة. */
    suspend fun restore(c: Context, d: BackupData) {
        AppDb.get(c).restoreDao().restoreAll(
            d.schedules, d.tasks, d.progress, d.activities,
            d.documents, d.pageTexts, d.questions, d.attempts, d.answers, d.reviewItems
        )
        d.settings?.let { Prefs.put(c, it) }
        d.focusHistory?.let { FocusHistory.restore(c, it) }
    }

    suspend fun import(c: Context, json: String): BackupParseResult {
        val r = BackupCodec.parse(json)
        if (!r.ok) throw IllegalArgumentException(r.errorText())
        restore(c, r.data!!)
        return r
    }
}
