package com.rafiq6.study

import android.app.Activity
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

data class WidgetTheme(val name: String, val bg: Int, val title: Int, val sub: Int)

object WidgetThemes {
    val all = listOf(
        WidgetTheme("أزرق", 0xFF1B5E8C.toInt(), Color.WHITE, 0xFFDCE9F5.toInt()),
        WidgetTheme("داكن", 0xFF11161D.toInt(), Color.WHITE, 0xFF9FB2C8.toInt()),
        WidgetTheme("أخضر", 0xFF1E5631.toInt(), Color.WHITE, 0xFFD6EBDD.toInt()),
        WidgetTheme("بنفسجي", 0xFF4A2B6B.toInt(), Color.WHITE, 0xFFE5D9F2.toInt()),
        WidgetTheme("عنبري", 0xFF8A5A00.toInt(), Color.WHITE, 0xFFF5E3C8.toInt()),
        WidgetTheme("أحمر", 0xFF7B241C.toInt(), Color.WHITE, 0xFFF5D5D0.toInt()),
        WidgetTheme("شفاف داكن", 0xCC11161D.toInt(), Color.WHITE, 0xFF9FB2C8.toInt()),
        WidgetTheme("شفاف فاتح", 0xE6F2F6FB.toInt(), 0xFF1A2733.toInt(), 0xFF45566B.toInt()),
    )
    private fun prefs(c: Context) = c.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE)
    fun get(c: Context, widgetId: Int): WidgetTheme = all.getOrElse(prefs(c).getInt("theme_$widgetId", 0)) { all[0] }
    fun set(c: Context, widgetId: Int, index: Int) { prefs(c).edit().putInt("theme_$widgetId", index).apply() }
    fun clear(c: Context, widgetId: Int) { prefs(c).edit().remove("theme_$widgetId").apply() }
}

data class WidgetSnapshot(val title: String, val time: String, val pct: Int,
                                  val rows: List<Triple<String, String, Boolean>>)

private fun loadSnapshot(c: Context): WidgetSnapshot = runBlocking {
    val dao = AppDb.get(c).dao()
    val schedule = dao.activeSchedule().first()
    val today = Subjects.now().toLocalDate().toString()
    val taskRows = if (schedule == null) emptyList() else dao.tasksForOnce(schedule.scheduleId).filter { it.date == today }
    val tasks = taskRows.map { t -> UiTask(t, dao.progressById(t.id)) }.sortedBy { it.startMin ?: 9999 }
    val nowMin = Subjects.now().hour * 60 + Subjects.now().minute
    val cur = tasks.firstOrNull { !it.done && it.startMin != null && nowMin >= it.startMin!! && (it.endMin == null || nowMin < it.endMin!!) }
    val nxt = tasks.firstOrNull { !it.done && it.startMin != null && it.startMin!! > nowMin }
    val shown = cur ?: nxt
    val pct = if (tasks.isEmpty()) 0 else 100 * tasks.count { it.done } / tasks.size
    val rows = tasks.take(4).map { Triple(it.title, it.startMin?.let { m -> Subjects.fmt12(m) } ?: "", it.done) }
    WidgetSnapshot(shown?.title ?: "لا مهام متبقية اليوم — رتاح!",
        shown?.let { "${Subjects.fmt12(it.startMin!!)} — ${it.durationMin} دقيقة" } ?: "", pct, rows)
}

private fun openPending(c: Context) = PendingIntent.getActivity(c, 0,
    Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

private fun applyTheme(v: RemoteViews, c: Context, widgetId: Int, titleId: Int, subIds: List<Int>) {
    val t = WidgetThemes.get(c, widgetId)
    v.setInt(R.id.wRoot, "setBackgroundColor", t.bg)
    v.setTextColor(titleId, t.title)
    for (id in subIds) v.setTextColor(id, t.sub)
}

abstract class BaseTasksWidget(protected val layout: Int) : AppWidgetProvider() {
    override fun onUpdate(c: Context, mgr: AppWidgetManager, ids: IntArray) {
        val snap = loadSnapshot(c)
        for (id in ids) mgr.updateAppWidget(id, build(c, id, snap))
    }
    override fun onDeleted(c: Context, ids: IntArray) {
        for (id in ids) WidgetThemes.clear(c, id)
    }
    protected abstract fun build(c: Context, widgetId: Int, snap: WidgetSnapshot): RemoteViews
}

class TasksWidget : BaseTasksWidget(R.layout.widget_layout) {
    override fun build(c: Context, widgetId: Int, snap: WidgetSnapshot): RemoteViews {
        val v = RemoteViews(c.packageName, layout)
        v.setTextViewText(R.id.wTitle, snap.title)
        v.setTextViewText(R.id.wTime, snap.time)
        v.setProgressBar(R.id.wProgress, 100, snap.pct, false)
        v.setOnClickPendingIntent(R.id.wOpen, openPending(c))
        applyTheme(v, c, widgetId, R.id.wTitle, listOf(R.id.wTime))
        return v
    }
}

class TasksWidgetCompact : BaseTasksWidget(R.layout.widget_layout_compact) {
    override fun build(c: Context, widgetId: Int, snap: WidgetSnapshot): RemoteViews {
        val v = RemoteViews(c.packageName, layout)
        v.setTextViewText(R.id.wTitle, snap.title)
        v.setProgressBar(R.id.wProgress, 100, snap.pct, false)
        v.setOnClickPendingIntent(R.id.wRoot, openPending(c))
        applyTheme(v, c, widgetId, R.id.wTitle, emptyList())
        return v
    }
}

class TasksWidgetList : BaseTasksWidget(R.layout.widget_layout_list) {
    override fun build(c: Context, widgetId: Int, snap: WidgetSnapshot): RemoteViews {
        val v = RemoteViews(c.packageName, layout)
        v.setTextViewText(R.id.wTitle, "مهام اليوم (${snap.rows.count { it.third }}/${snap.rows.size}) ✓")
        val rowIds = listOf(R.id.wRow0, R.id.wRow1, R.id.wRow2, R.id.wRow3)
        rowIds.forEachIndexed { i, id ->
            if (i < snap.rows.size) {
                val (title, time, done) = snap.rows[i]
                v.setTextViewText(id, "${if (done) "✅" else "⬜"} $title ${if (time.isNotEmpty()) "· $time" else ""}")
                v.setViewVisibility(id, View.VISIBLE)
            } else v.setViewVisibility(id, View.GONE)
        }
        v.setOnClickPendingIntent(R.id.wRoot, openPending(c))
        applyTheme(v, c, widgetId, R.id.wTitle, rowIds)
        return v
    }
}

data class WidgetRow(val title: String, val time: String, val dur: Int, val done: Boolean)

/** كل مهام اليوم للجدول النشط، مرتبة بالوقت (بلا وقت في الآخر). */
internal fun loadAllRows(c: Context): List<WidgetRow> = runBlocking {
    val dao = AppDb.get(c).dao()
    val schedule = dao.activeSchedule().first() ?: return@runBlocking emptyList()
    val today = Subjects.now().toLocalDate().toString()
    dao.tasksForOnce(schedule.scheduleId).filter { it.date == today }
        .map { t -> UiTask(t, dao.progressById(t.id)) }
        .sortedBy { it.startMin ?: 9999 }
        .map { WidgetRow(it.title, it.startMin?.let { m -> Subjects.fmt12(m) } ?: "", it.durationMin, it.done) }
}

/** ويدجت «مهام اليوم كاملة»: قائمة قابلة للتمرير بكل مهام اليوم. */
class TasksWidgetFull : BaseTasksWidget(R.layout.widget_layout_full) {
    override fun onUpdate(c: Context, mgr: AppWidgetManager, ids: IntArray) {
        super.onUpdate(c, mgr, ids)
        for (id in ids) mgr.notifyAppWidgetViewDataChanged(id, R.id.wList)
    }
    override fun build(c: Context, widgetId: Int, snap: WidgetSnapshot): RemoteViews {
        val rows = loadAllRows(c)
        val v = RemoteViews(c.packageName, layout)
        v.setTextViewText(R.id.wTitle, "مهام اليوم (${rows.count { it.done }}/${rows.size}) ✓")
        v.setProgressBar(R.id.wProgress, 100, snap.pct, false)
        val svc = Intent(c, TasksWidgetService::class.java)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
        svc.data = Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME))
        v.setRemoteAdapter(R.id.wList, svc)
        v.setEmptyView(R.id.wList, R.id.wEmpty)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (android.os.Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        v.setPendingIntentTemplate(R.id.wList, PendingIntent.getActivity(c, 1, Intent(c, MainActivity::class.java), flags))
        v.setOnClickPendingIntent(R.id.wTitle, openPending(c))
        applyTheme(v, c, widgetId, R.id.wTitle, listOf(R.id.wEmpty))
        return v
    }
}

class TasksWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory =
        Factory(applicationContext, intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID))

    private class Factory(val c: Context, val widgetId: Int) : RemoteViewsFactory {
        private var rows: List<WidgetRow> = emptyList()
        override fun onCreate() {}
        override fun onDataSetChanged() { rows = loadAllRows(c) }
        override fun onDestroy() { rows = emptyList() }
        override fun getCount() = rows.size
        override fun getViewAt(i: Int): RemoteViews {
            val v = RemoteViews(c.packageName, R.layout.widget_item)
            val r = rows.getOrNull(i) ?: return v
            val t = WidgetThemes.get(c, widgetId)
            val extra = buildString {
                if (r.time.isNotEmpty()) append(" · ${r.time}")
                if (r.dur > 0) append(" · ${r.dur} د")
            }
            v.setTextViewText(R.id.wItem, "${if (r.done) "✅" else "⬜"} ${r.title}$extra")
            v.setTextColor(R.id.wItem, if (r.done) t.sub else t.title)
            v.setOnClickFillInIntent(R.id.wItem, Intent())
            return v
        }
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun getItemId(i: Int) = i.toLong()
        override fun hasStableIds() = false
    }
}

object WidgetRefresher {
    private val providers = listOf(TasksWidget::class.java, TasksWidgetCompact::class.java, TasksWidgetList::class.java, TasksWidgetFull::class.java)
    fun refresh(c: Context) {
        val mgr = AppWidgetManager.getInstance(c)
        for (cls in providers) {
            val ids = mgr.getAppWidgetIds(ComponentName(c, cls))
            if (ids.isNotEmpty()) c.sendBroadcast(Intent(c, cls)
                .setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids))
        }
    }
    fun refreshOne(c: Context, widgetId: Int) {
        val mgr = AppWidgetManager.getInstance(c)
        for (cls in providers) if (widgetId in mgr.getAppWidgetIds(ComponentName(c, cls))) {
            c.sendBroadcast(Intent(c, cls).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, intArrayOf(widgetId)))
        }
    }
}

/** شاشة اختيار لون الويدجت تظهر عند إضافته إلى الشاشة الرئيسية. */
class WidgetConfigActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val widgetId = intent?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        setResult(RESULT_CANCELED)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad); setBackgroundColor(Color.WHITE)
        }
        root.addView(TextView(this).apply {
            text = "اختر لون الويدجت"; textSize = 18f; setTextColor(Color.BLACK)
            setPadding(0, 0, 0, pad)
        })
        WidgetThemes.all.forEachIndexed { i, t ->
            root.addView(TextView(this).apply {
                text = "   ${t.name}"
                textSize = 16f; setTextColor(t.title); gravity = Gravity.CENTER_VERTICAL
                val r = 16f * resources.displayMetrics.density
                background = GradientDrawable().apply {
                    setColor(t.bg); cornerRadius = r; setStroke(2, 0xFFB9C4CF.toInt())
                }
                val m = (8 * resources.displayMetrics.density).toInt()
                setPadding(pad, m, pad, m)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0, m / 2, 0, m / 2) }
                setOnClickListener {
                    WidgetThemes.set(this@WidgetConfigActivity, widgetId, i)
                    WidgetRefresher.refreshOne(this@WidgetConfigActivity, widgetId)
                    setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
                    finish()
                }
            })
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
