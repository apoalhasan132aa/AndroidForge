package com.rafiq6.study

import java.time.LocalDate

// ============================================================
// الميزة 5: المراجعة الذكية حسب النسيان (Spaced Repetition)
// منطق نقي: يحسب الفترة القادمة بين المراجعات بناءً على تقييم المستخدم
// (سهل/متوسط/صعب)، ويبني مهمة مراجعة جديدة (نوعها TaskTypes.REVIEW،
// منفصلة تمامًا عن المحاضرات والتراكمات) في أول يوم متاح يحترم الحد
// اليومي وأيام الراحة — دون أي تغيير على المحاضرة الأصلية أو عددها.
// ============================================================

enum class ReviewRating { EASY, MEDIUM, HARD }

object SpacedRepetitionEngine {
    /** الفترات الأولية الافتراضية بالأيام: غدًا، ثم بعد عدة أيام، ثم بعد أسبوع — قابلة للتعديل، وليست إلزامية لكل مادة. */
    val DEFAULT_INTERVALS = listOf(1, 4, 7)
    const val DEFAULT_DURATION_MIN = 20

    /** الفترة القادمة بالأيام بعد تقييم المستخدم، انطلاقًا من مرحلته الحالية. */
    fun nextIntervalDays(stage: Int, rating: ReviewRating, baseIntervals: List<Int> = DEFAULT_INTERVALS): Int {
        require(baseIntervals.isNotEmpty())
        val base = if (stage < baseIntervals.size) baseIntervals[stage]
            else baseIntervals.last() * (stage - baseIntervals.size + 2)
        return when (rating) {
            ReviewRating.EASY -> (base * 1.6).toInt().coerceAtLeast(base + 1)    // تقريب الفترة القادمة (تبعيد الموعد)
            ReviewRating.MEDIUM -> base
            ReviewRating.HARD -> (base / 2).coerceAtLeast(1)                     // تقريب الموعد (تقريب أكثر)
        }.coerceAtLeast(1)
    }

    /**
     * يبني مهمة المراجعة القادمة جاهزة للحفظ، أو null إن تعذّر إيجاد يوم مناسب ضمن الأفق الزمني.
     * fromDate: التاريخ الذي يُحسب منه الفارق (تاريخ آخر مراجعة أو تاريخ الدراسة الأصلي عند أول مراجعة).
     */
    fun scheduleNext(
        item: ReviewItemEntity,
        rating: ReviewRating,
        fromDate: LocalDate,
        allTasks: List<UiTask>,
        settings: Settings,
        weekConstraints: WeekPlanSnapshot? = null,
        horizonDays: Int = 30,
        baseIntervals: List<Int> = DEFAULT_INTERVALS,
        durationMin: Int = DEFAULT_DURATION_MIN
    ): TaskEntity? {
        val gap = nextIntervalDays(item.stage, rating, baseIntervals)
        val earliest = fromDate.plusDays(gap.toLong())
        val targets = (0 until horizonDays).map { earliest.plusDays(it.toLong()) }
            .filter { d -> weekConstraints == null || weekConstraints.isUsable(ScheduleParser.weekday(d), item.subject, TaskTypes.REVIEW) }

        for (target in targets) {
            val slot = findSlot(allTasks, target, settings, durationMin) ?: continue
            return buildTask(item, target, slot, durationMin)
        }
        return null
    }

    /**
     * إعادة توزيع مراجعات متأخرة (فات موعدها ولم تُسجَّل نتيجتها) بالتوازن بدون إغراق يوم واحد —
     * نفس قواعد الميزة 1 بالحرف الواحد، لتبقى الميزتان متكاملتين بدل منطقين منفصلين لإعادة التوزيع.
     */
    fun rebalanceOverdueReviews(
        allTasks: List<UiTask>, today: LocalDate, settings: Settings,
        weekConstraints: WeekPlanSnapshot? = null, horizonDays: Int = 14
    ): AdaptivePlan {
        val reviewTasks = allTasks.filter { it.type == TaskTypes.REVIEW }
        return AdaptiveScheduleEngine.plan(reviewTasks, today, settings, weekConstraints, horizonDays)
    }

    private fun buildTask(item: ReviewItemEntity, date: LocalDate, start: Int, durationMin: Int): TaskEntity {
        val sourceId = "review-${item.id}-s${item.stage + 1}"
        return TaskEntity(
            id = "${item.scheduleId}::$sourceId", scheduleId = item.scheduleId, sourceId = sourceId,
            date = date.toString(), dayName = ScheduleParser.weekday(date), subject = item.subject,
            type = TaskTypes.REVIEW,
            title = "مراجعة: ${item.title}" + (item.lectureNo?.let { " (محاضرة $it)" } ?: ""),
            lectureNo = item.lectureNo, durationMin = durationMin, startMin = start, endMin = start + durationMin,
            flexible = true, fixed = false, notify = true, note = item.notes, reviewItemId = item.id
        )
    }

    private fun findSlot(allTasks: List<UiTask>, target: LocalDate, settings: Settings, durationMin: Int): Int? {
        val date = target.toString()
        val dayLoad = allTasks.filter { it.date == date }.sumOf { it.durationMin }
        if (dayLoad + durationMin > settings.dailyGoalMin) return null
        val busy = allTasks.map { it.task }.filter { it.date == date }.mapNotNull { t ->
            val s = t.startMin ?: return@mapNotNull null; val e = t.endMin ?: s + t.durationMin; s..e
        }
        val windows = mutableListOf<Pair<Int, Int>>()
        if (settings.schoolStart > settings.wakeMin + durationMin) windows += settings.wakeMin to settings.schoolStart
        if (settings.sleepMin > settings.schoolEnd + durationMin) windows += settings.schoolEnd to settings.sleepMin
        for ((from, to) in windows) {
            var cursor = from
            while (cursor + durationMin <= to) {
                val clash = busy.any { cursor < it.last + settings.breakMin && cursor + durationMin > it.first }
                if (!clash) return cursor
                cursor += 15
            }
        }
        return null
    }
}
