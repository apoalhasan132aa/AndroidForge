package com.rafiq6.study

import java.time.LocalDate

// ============================================================
// الميزة 4: وضع الطوارئ (Emergency Reschedule)
// يتعامل مع يوم واحد تعذّرت فيه الدراسة (كليًا أو جزئيًا من وقت معيّن)،
// مع خيار: إعادة توزيع مهام ذلك اليوم فقط، أو ضم كل المهام المتأخرة الأخرى
// معه في خطة واحدة. يسمح أيضًا بتعديل الحد اليومي مؤقتًا للأيام القادمة
// ضمن هذه العملية فقط — دون تغيير إعدادات المستخدم الدائمة.
//
// يعيد استخدام AdaptiveMove/AdaptiveUnplaced/AdaptiveDayLoad من الميزة 1
// (AdaptiveSchedule.kt) حتى تبقى بنية البيانات وشاشات المعاينة موحّدة
// بين الميزتين بدل أدوات منفصلة لا تتكامل.
// ============================================================

enum class EmergencyScope {
    OUTING_ONLY,                 // أعد توزيع مهام يوم الطوارئ فقط
    OUTING_PLUS_ALL_OVERDUE      // + كل المهام المتأخرة الأخرى في خطة واحدة
}

data class EmergencyPlan(
    val outingDate: LocalDate,
    val isFullDay: Boolean,
    val partialFromMin: Int?,
    val disruptedCount: Int,        // عدد مهام يوم الطوارئ المتأثرة فعليًا (بعد اعتبار الجزئي إن وُجد)
    val moves: List<AdaptiveMove>,
    val unplaced: List<AdaptiveUnplaced>,
    val dayLoads: List<AdaptiveDayLoad>,
    val warnings: List<String>
) {
    val movedCount: Int get() = moves.size
    val hasChanges: Boolean get() = moves.isNotEmpty()
    val isFullyExecutable: Boolean get() = unplaced.isEmpty()
    val affectedDates: List<String> get() = (moves.map { it.toDate } + moves.map { it.task.date }).distinct().sorted()
}

object EmergencyReplanEngine {

    /**
     * يبني خطة الطوارئ. لا يكتب في قاعدة البيانات.
     * tempDailyLimitForUpcomingDays: null = لا تغيير (استخدم settings.dailyGoalMin كما هو)؛
     *   أي قيمة أخرى تُستخدم فقط داخل هذه العملية لحساب أماكن الأيام القادمة، ولا تُحفظ كإعداد دائم.
     */
    fun plan(
        allTasks: List<UiTask>,
        outing: LocalDate,
        isFullDay: Boolean,
        partialFromMin: Int?,
        scope: EmergencyScope,
        today: LocalDate,
        settings: Settings,
        tempDailyLimitForUpcomingDays: Int? = null,
        weekConstraints: WeekPlanSnapshot? = null,
        horizonDays: Int = 21
    ): EmergencyPlan {
        val outingStr = outing.toString()
        val dayTasks = allTasks.filter { it.date == outingStr && !it.done && !it.fixed }
        val disrupted = if (isFullDay) dayTasks
            else dayTasks.filter { (it.startMin ?: Int.MAX_VALUE) >= (partialFromMin ?: 0) }

        val otherOverdue = if (scope == EmergencyScope.OUTING_PLUS_ALL_OVERDUE)
            AdaptiveScheduleEngine.findOverdue(allTasks, today).filter { it.date != outingStr && !it.fixed }
        else emptyList()

        val toMove = (disrupted + otherOverdue).distinctBy { it.id }
            .sortedWith(compareBy({ priorityRank(it.type) }, { it.date }, { it.startMin ?: 9999 }))

        val warnings = mutableListOf<String>()
        val effectiveSettings = if (tempDailyLimitForUpcomingDays != null && tempDailyLimitForUpcomingDays > 0)
            settings.copy(dailyGoalMin = tempDailyLimitForUpcomingDays) else settings
        if (tempDailyLimitForUpcomingDays != null && tempDailyLimitForUpcomingDays > 0)
            warnings += "تم استخدام حد يومي مؤقت (${tempDailyLimitForUpcomingDays} دقيقة) لهذه العملية فقط — إعداداتك الدائمة لم تتغير."
        if (toMove.isEmpty())
            warnings += "لا توجد مهام تحتاج إعادة توزيع ضمن هذا الاختيار."

        val placements = mutableMapOf<String, TaskEntity>()
        val unplaced = mutableListOf<AdaptiveUnplaced>()
        for (uiTask in toMove) {
            val placed = placeTask(uiTask.task, allTasks, placements, outing, today, horizonDays, effectiveSettings, weekConstraints)
            if (placed != null) placements[uiTask.id] = placed
            else unplaced += AdaptiveUnplaced(uiTask, "لا يتسع أي يوم ضمن ${horizonDays} يومًا القادمة ضمن القيود الحالية.")
        }
        if (unplaced.isNotEmpty())
            warnings += "الخطة غير قابلة للتنفيذ بالكامل ضمن الفترة الحالية: تعذّر توزيع ${unplaced.size} مهمة — جرّب تمديد الفترة أو رفع الحد اليومي المؤقت."

        val moves = toMove.filter { it.id in placements }.map { uiTask ->
            val p = placements.getValue(uiTask.id)
            AdaptiveMove(uiTask, p.date, p.startMin ?: 0, p.endMin ?: (p.startMin ?: 0) + p.durationMin)
        }
        val affected = (moves.map { it.toDate } + moves.map { it.task.date }).distinct().sorted()
        val dayLoads = affected.map { date ->
            val base = allTasks.filter { it.task.id !in placements.keys && it.date == date }.sumOf { it.durationMin }
            val movedIn = placements.values.filter { it.date == date }.sumOf { it.durationMin }
            val limit = if (date == outingStr) settings.dailyGoalMin else effectiveSettings.dailyGoalMin
            AdaptiveDayLoad(date, base + movedIn, limit)
        }

        return EmergencyPlan(outing, isFullDay, partialFromMin, disrupted.size, moves, unplaced, dayLoads, warnings.distinct())
    }

    private fun priorityRank(type: String): Int = when {
        TaskTypes.isAssessment(type) -> 0
        type == TaskTypes.HOMEWORK -> 1
        type == TaskTypes.NEW -> 2
        type == TaskTypes.REVIEW -> 3
        else -> 4
    }

    // ملاحظة مبسّطة ومقصودة: حتى في يوم جزئي، لا نعيد حزم الجزء المتاح (قبل partialFromMin) من نفس اليوم،
    // بل ننقل المهام المتأثرة إلى الأيام القادمة فقط — أبسط وأكثر أمانًا من حساب فجوات دقيقة داخل نفس اليوم،
    // وما زال يحترم كل القيود المطلوبة.
    private fun placeTask(
        candidate: TaskEntity,
        allTasks: List<UiTask>,
        placements: Map<String, TaskEntity>,
        outing: LocalDate,
        today: LocalDate,
        horizonDays: Int,
        settings: Settings,
        weekConstraints: WeekPlanSnapshot?
    ): TaskEntity? {
        val start = maxOf(outing, today).plusDays(1)
        val targets = (0 until horizonDays).map { start.plusDays(it.toLong()) }
            .filter { d ->
                val dayName = ScheduleParser.weekday(d)
                weekConstraints == null || weekConstraints.isUsable(dayName, candidate.subject, candidate.type)
            }
            .sortedBy { d -> dayLoad(d.toString(), allTasks, placements) }

        for (target in targets) {
            val slot = findSlot(candidate, allTasks, placements, target, settings) ?: continue
            return candidate.copy(
                date = target.toString(), startMin = slot, endMin = slot + candidate.durationMin,
                originalDate = candidate.originalDate ?: candidate.date,
                originalStartMin = candidate.originalStartMin ?: candidate.startMin,
                originalEndMin = candidate.originalEndMin ?: candidate.endMin,
                rescheduleReason = "وضع الطوارئ: تعذّرت الدراسة يوم ${outing}"
            )
        }
        return null
    }

    private fun dayLoad(date: String, allTasks: List<UiTask>, placements: Map<String, TaskEntity>): Int {
        val base = allTasks.filter { it.task.id !in placements.keys && it.date == date }.sumOf { it.durationMin }
        val moved = placements.values.filter { it.date == date }.sumOf { it.durationMin }
        return base + moved
    }

    private fun findSlot(
        candidate: TaskEntity, allTasks: List<UiTask>, placements: Map<String, TaskEntity>,
        target: LocalDate, settings: Settings
    ): Int? {
        val date = target.toString()
        if (dayLoad(date, allTasks, placements) + candidate.durationMin > settings.dailyGoalMin) return null
        val busyTasks = allTasks.map { it.task }.filter { it.date == date && it.id != candidate.id && it.id !in placements.keys } +
            placements.values.filter { it.date == date && it.id != candidate.id }
        val busy = busyTasks.mapNotNull { t -> val s = t.startMin ?: return@mapNotNull null; val e = t.endMin ?: s + t.durationMin; s..e }
        val windows = mutableListOf<Pair<Int, Int>>()
        if (settings.schoolStart > settings.wakeMin + candidate.durationMin) windows += settings.wakeMin to settings.schoolStart
        if (settings.sleepMin > settings.schoolEnd + candidate.durationMin) windows += settings.schoolEnd to settings.sleepMin
        for ((from, to) in windows) {
            var cursor = from.coerceAtLeast(if (TaskTypes.isAssessment(candidate.type)) 19 * 60 else from)
            val limit = to.coerceAtMost(settings.sleepMin)
            while (cursor + candidate.durationMin <= limit) {
                val clash = busy.any { cursor < it.last + settings.breakMin && cursor + candidate.durationMin > it.first }
                if (!clash) return cursor
                cursor += 15
            }
        }
        return null
    }
}
