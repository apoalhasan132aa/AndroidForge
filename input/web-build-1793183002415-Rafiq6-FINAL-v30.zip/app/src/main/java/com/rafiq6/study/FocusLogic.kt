package com.rafiq6.study

// منطق جلسة التركيز — نقي 100% (بدون أي استيراد من Android) حتى يكون قابلًا للاختبار على JVM.

data class FocusState(
    val sessionId: String = "",
    val title: String = "",
    val planMin: Int = 0,
    val startElapsedMs: Long = 0L,   // SystemClock.elapsedRealtime() عند البدء
    val endElapsedMs: Long = 0L,     // نهاية الجلسة بنظام elapsedRealtime
    val startWallMs: Long = 0L,      // System.currentTimeMillis() عند البدء
    val endWallMs: Long = 0L,         // نهاية الجلسة بالساعة الجدارية (احتياط لإعادة التشغيل)
    val running: Boolean = false,
    val allowed: List<String> = emptyList(),   // packageName للتطبيقات المسموحة (0–2)
    val enforced: Boolean = false,             // true فقط إذا نجح تفعيل Lock Task فعلًا
    val taskId: String? = null                 // معرّف المهمة المحددة من الجدول (UiTask.id)، إن اختارها المستخدم
)

/** نتيجة نهاية جلسة تركيز: الحالة الأخيرة + الوقت الفعلي المُقاس (وليس المخطط)، لعرضه وربطه بالمهمة. */
data class FocusResult(val state: FocusState, val actualMin: Int)

object FocusActual {
    /** الوقت الفعلي المنقضي منذ بداية الجلسة وحتى الآن، بالدقائق، محصورًا بين 0 والمدة المخططة. */
    fun elapsedMinutes(s: FocusState, nowWall: Long): Int {
        if (s.startWallMs <= 0) return 0
        val ms = (nowWall - s.startWallMs).coerceAtLeast(0)
        return (ms / 60_000L).toInt().coerceIn(0, s.planMin.coerceAtLeast(0))
    }
}

/** اختيار التطبيقات المسموحة: حتى تطبيقين، بمعرّف الحزمة، بلا تكرار. */
object FocusSelection {
    const val MAX_APPS = 2

    fun toggle(current: List<String>, pkg: String): List<String> = when {
        pkg.isBlank() -> current
        pkg in current -> current - pkg
        current.size >= MAX_APPS -> current          // ممتلئ: لا نستبدل بصمت
        else -> current + pkg
    }

    fun encode(list: List<String>): String = list.distinct().take(MAX_APPS).joinToString("\n")
    fun decode(raw: String?): List<String> =
        (raw ?: "").lines().map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(MAX_APPS)

    /** يفصل المحفوظ إلى صالح (ما زال مثبتًا وقابلًا للتشغيل) ومفقود (أُزيل/عُطّل بعد الحفظ). */
    fun sanitize(saved: List<String>, launchable: Set<String>): Pair<List<String>, List<String>> =
        saved.partition { it in launchable }

    /** حزم Lock Task: رفيق أولًا ثم المختارة ثم تطبيق الاتصال (للطوارئ) إن وُجد. */
    fun lockTaskPackages(own: String, allowed: List<String>, dialer: String?): List<String> =
        (listOf(own) + allowed + listOfNotNull(dialer)).distinct()
}

/** الآلية التي ستُستخدم فعليًا — تُحدَّد من إمكانات الجهاز، لا من رغبة المستخدم. */
enum class FocusMode { LOCK_TASK_ALLOWLIST, SCREEN_PIN_SELF, TIMER_ONLY }

object FocusPolicy {
    fun decide(isDeviceOwner: Boolean, pinEnabled: Boolean): FocusMode = when {
        isDeviceOwner -> FocusMode.LOCK_TASK_ALLOWLIST
        pinEnabled -> FocusMode.SCREEN_PIN_SELF
        else -> FocusMode.TIMER_ONLY
    }
    /** التطبيق المختار يُفتح مباشرة عند البدء في كل الأوضاع (دون شاشة وسيطة). */
    fun opensAllowedApps(mode: FocusMode) = true
    /** تثبيت رفيق نفسه لا يكون إلا إن لم يُختر تطبيق؛ وإلا حُبست في رفيق بدل التطبيق المختار. */
    fun pinsSelf(mode: FocusMode, hasAllowed: Boolean) = mode == FocusMode.SCREEN_PIN_SELF && !hasAllowed
}

object FocusMath {
    fun remainingMs(s: FocusState, nowElapsed: Long, nowWall: Long): Long {
        if (!s.running || s.sessionId.isEmpty()) return 0
        // بعد إعادة تشغيل الجهاز تعود elapsedRealtime إلى قرب الصفر؛ نكشف ذلك
        // (nowElapsed أصغر من بداية الجلسة المخزنة) ونعود إلى الساعة الجدارية.
        val monotonicValid = s.startElapsedMs > 0 && nowElapsed >= s.startElapsedMs
        val base = if (monotonicValid) s.endElapsedMs - nowElapsed else s.endWallMs - nowWall
        return base.coerceAtLeast(0)
    }

    fun isExpired(s: FocusState, nowElapsed: Long, nowWall: Long): Boolean =
        remainingMs(s, nowElapsed, nowWall) <= 0

    fun progressPct(s: FocusState, nowElapsed: Long, nowWall: Long): Int {
        if (s.planMin <= 0) return 0
        val total = s.planMin * 60_000L
        val rem = remainingMs(s, nowElapsed, nowWall).coerceAtMost(total)
        return (100L * (total - rem) / total).toInt()
    }

    fun fmtClock(ms: Long): String {
        val sec = ms.coerceAtLeast(0) / 1000
        return "%d:%02d".format(sec / 60, sec % 60)
    }
}

object FocusPhrases {
    // 50 عبارة تحفيزية متنوعة لطالب السادس العلمي — محترمة، بلا إهانة أو ذنب مرضي.
    val all: List<String> = listOf(
        "كل دقيقة تدرسها اليوم تقرّبك من هدفك.",
        "لا تجعل لحظة ملل تسرق تعبك.",
        "مستقبلك يستحق أن تكمل هذه المحاضرة.",
        "ارجع للمحاضرة، أنت بدأت حتى تنجح.",
        "التركيز الآن راحة بعدين.",
        "خطوة صغيرة كل يوم تصنع فرقًا كبيرًا.",
        "أنت أقوى من أي مشتّت.",
        "المحاولة الصادقة أهم من النتيجة السريعة.",
        "ذاكرتك تشتغل، أكمل وسترى النتيجة.",
        "طريق القبول يبدأ من هنا.",
        "خمس دقائق تركيز أفضل من ساعة تشتت.",
        "اليوم تبني نسختك الغد.",
        "لا تبيع وقتك بثمن الملل.",
        "كل محاضرة تكملها نقطة إضافية لصالحك.",
        "النجاح يحب المثابرين.",
        "أنت لست متعبًا، أنت على بُعد محاضرة من الإنجاز.",
        "ركّز على المحاضرة، ودع الباقي ينتظر.",
        "عقلك واضح الآن، استغل هذا الوضوح.",
        "التفوق قرار تتخذه في لحظات مثل هذه.",
        "أكمل ما بدأت، فالمكملون هم المتفوقون.",
        "دقيقة تركيز الآن تعادل عشرات الدقائق لاحقًا.",
        "هدفك أوضح من أي إغراء.",
        "أجّل المتعة ساعة، ولا تؤجل نجاحك سنة.",
        "أنت تستحق أن ترى نفسك في المنصة.",
        "الدراسة الآن استثمار وليست كلفة.",
        "كل سؤال بالوزاري له إجابة في محاضرتك.",
        "الثبات على الجدول هو السر الحقيقي.",
        "لا تخرج الآن، أنت في منتصف الطريق.",
        "التركيز مهارة، وأنت تتدرب عليها الآن.",
        "فكّر بفرحة عائلتك يوم النتائج.",
        "المشتّتات ستبقى موجودة، أما وقتك فلن يعود.",
        "صفحة واحدة الآن أسهل من مئة صفحة لاحقًا.",
        "أنت تبني عادة النجاح.",
        "الهدوء والتركيز سلاحك في السادس.",
        "كل ختم تكمله يقربك من الختم الأخير.",
        "لا تترك المحاضرة ناقصة، أكملها بشجاعة.",
        "عقلك الآن في أفضل حالاته، لا تضيّع اللحظة.",
        "النجاح مجموع لحظات مثل هذه اللحظة.",
        "خذ نفسًا عميقًا وعد إلى محاضرتك.",
        "أنت تملك الإرادة، فقط استمر.",
        "الدراسة قد تكون صعبة، لكن الندم أصعب.",
        "ركّز على خطوة واحدة: المحاضرة الحالية فقط.",
        "ساعة تركيز الآن تساوي يومًا كاملًا من التسويف.",
        "أحلامك أكبر من أي إشعار.",
        "أنت قادر على أكثر مما تتصور، أثبت ذلك الآن.",
        "أكمل المحاضرة وستحترم نفسك أكثر.",
        "كل المتفوقين بدأوا بجلسة مثل جلستك هذه.",
        "لا تدع اليوم يمر دون إنجاز.",
        "العودة إلى المحاضرة الآن قرار سيفرحك غدًا.",
        "رفيقك في السادس يؤمن بك، فثق بنفسك وأكمل."
    )

    // عبارة عشوائية مع تجنّب تكرار العبارة السابقة مباشرةً قدر الإمكان.
    fun randomExcept(last: String?): String {
        val pool = if (last != null && all.size > 1) all.filter { it != last } else all
        return pool.random()
    }
}
