package com.rafiq6.study

import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit

// ===== نموذج مسودة الجدول السنوي — منطق نقي 100% (قابل للاختبار على JVM) =====

object WizardConst {
    val DEFAULT_SUBJECTS: List<String> = listOf("الفيزياء", "الكيمياء", "الرياضيات", "الأحياء", "العربي", "الإنكليزي")
    val DAYS: List<String> = listOf("السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة")
    fun dayOfWeekName(d: DayOfWeek): String = when (d) {
        DayOfWeek.SATURDAY -> "السبت"; DayOfWeek.SUNDAY -> "الأحد"
        DayOfWeek.MONDAY -> "الاثنين"; DayOfWeek.TUESDAY -> "الثلاثاء"
        DayOfWeek.WEDNESDAY -> "الأربعاء"; DayOfWeek.THURSDAY -> "الخميس"
        DayOfWeek.FRIDAY -> "الجمعة"
    }
}

/**
 * حالة المسودة. القيم كلها من إدخال الطالب — لا توجد قيم افتراضية مخفية.
 * backlogs: مادة → عدد مؤكد (0 يعني «ما عندي تراكم»). غياب المادة من الخريطة = لم يؤكد العدد بعد.
 * weekPlan: يوم → مجموعة المواد المسموحة فيه.
 */
data class WizardDraft(
    val mode: String = "new",
    val subjects: List<String> = emptyList(),
    val backlogs: Map<String, Int> = emptyMap(),
    val weekPlan: Map<String, Set<String>> = emptyMap(),
    val restDays: Set<String> = emptySet(),
    val startDate: String = "",
    val endDate: String = "",
    val dailyStudyMin: Int = 240,
    val schoolDays: Set<String> = emptySet(),
    val oldOnly: Boolean = true,
    val newWeekly: Map<String, Int> = emptyMap(),
    val hasNewScheduleReady: Boolean = false,
    val finalGoal: String = ""
) {
    fun totalBacklog(): Int = subjects.sumOf { backlogs[it] ?: 0 }
    fun missingBacklogs(): List<String> = subjects.filter { !backlogs.containsKey(it) }
    fun daysFor(subject: String): List<String> =
        WizardConst.DAYS.filter { subject in (weekPlan[it] ?: emptySet()) }
    fun undistributed(): List<String> = subjects.filter { daysFor(it).isEmpty() }

    fun validateDates(): String? {
        if (startDate.isBlank() || endDate.isBlank()) return null
        return try {
            val s = LocalDate.parse(startDate); val e = LocalDate.parse(endDate)
            when {
                e < s -> "تاريخ النهاية يسبق تاريخ البداية."
                ChronoUnit.DAYS.between(s, e) > 370 -> "النطاق يتجاوز سنة كاملة — هل هذا مقصود؟"
                else -> null
            }
        } catch (e: Exception) { "التواريخ يجب أن تكون بصيغة YYYY-MM-DD." }
    }

    fun daysCount(): Long? = try {
        if (startDate.isBlank() || endDate.isBlank()) null
        else ChronoUnit.DAYS.between(LocalDate.parse(startDate), LocalDate.parse(endDate)) + 1
    } catch (e: Exception) { null }

    fun readyForSummary(): List<String> {
        val problems = mutableListOf<String>()
        if (subjects.isEmpty()) problems += "اختر مادة واحدة على الأقل."
        missingBacklogs().forEach { problems += "حدد عدد تراكم مادة $it (أو أكّد أنها صفر)." }
        validateDates()?.let { problems += it }
        if (subjects.isNotEmpty() && weekPlan.isEmpty()) problems += "وزّع المواد على أيام الأسبوع."
        return problems
    }
}

// ===== عمليات خطة الأسبوع (دالات نقية) =====

object WeekOps {
    fun toggle(d: WizardDraft, day: String, subject: String): WizardDraft {
        if (day in d.restDays) return d
        val cur = d.weekPlan[day] ?: emptySet()
        val next = if (subject in cur) cur - subject else cur + subject
        return d.copy(weekPlan = d.weekPlan + (day to next))
    }
    fun setAll(d: WizardDraft, day: String): WizardDraft {
        if (day in d.restDays) return d
        return d.copy(weekPlan = d.weekPlan + (day to d.subjects.toSet()))
    }
    fun clearDay(d: WizardDraft, day: String): WizardDraft =
        d.copy(weekPlan = d.weekPlan + (day to emptySet()))
    fun copyDay(d: WizardDraft, from: String, targets: Collection<String>): WizardDraft {
        val src = d.weekPlan[from] ?: emptySet()
        var plan = d.weekPlan
        targets.filter { it != from && it !in d.restDays }.forEach { plan = plan + (it to src) }
        return d.copy(weekPlan = plan)
    }
    fun setRest(d: WizardDraft, day: String, rest: Boolean): WizardDraft =
        if (rest) d.copy(restDays = d.restDays + day, weekPlan = d.weekPlan + (day to emptySet()))
        else d.copy(restDays = d.restDays - day)
    fun addSubject(d: WizardDraft, subject: String): WizardDraft =
        if (subject.isBlank() || subject in d.subjects) d else d.copy(subjects = d.subjects + subject.trim())
    fun removeSubject(d: WizardDraft, subject: String): WizardDraft =
        d.copy(
            subjects = d.subjects - subject,
            backlogs = d.backlogs - subject,
            newWeekly = d.newWeekly - subject,
            weekPlan = d.weekPlan.mapValues { (_, v) -> v - subject }
        )
}

// ===== ترميز المسودة (JSON) =====

object WizardDraftCodec {
    fun toJson(d: WizardDraft): JSONObject = JSONObject().apply {
        put("mode", d.mode)
        put("subjects", JSONArray().apply { d.subjects.forEach { put(it) } })
        put("backlogs", JSONObject().apply { d.backlogs.forEach { (k, v) -> put(k, v) } })
        put("weekPlan", JSONObject().apply { d.weekPlan.forEach { (k, v) ->
            put(k, JSONArray().apply { v.forEach { put(it) } }) } })
        put("restDays", JSONArray().apply { d.restDays.forEach { put(it) } })
        put("startDate", d.startDate); put("endDate", d.endDate)
        put("dailyStudyMin", d.dailyStudyMin)
        put("schoolDays", JSONArray().apply { d.schoolDays.forEach { put(it) } })
        put("oldOnly", d.oldOnly)
        put("newWeekly", JSONObject().apply { d.newWeekly.forEach { (k, v) -> put(k, v) } })
        put("hasNewScheduleReady", d.hasNewScheduleReady)
        put("finalGoal", d.finalGoal)
    }

    private fun jsonToList(a: JSONArray?): List<String> =
        if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }
    private fun jsonToSet(a: JSONArray?): Set<String> = jsonToList(a).toSet()

    fun fromJson(o: JSONObject): WizardDraft {
        val backlogs = mutableMapOf<String, Int>()
        o.optJSONObject("backlogs")?.let { bj -> bj.keys().forEach { k -> backlogs[k] = bj.getInt(k) } }
        val weekPlan = mutableMapOf<String, Set<String>>()
        o.optJSONObject("weekPlan")?.let { pj -> pj.keys().forEach { k -> weekPlan[k] = jsonToSet(pj.getJSONArray(k)) } }
        val newWeekly = mutableMapOf<String, Int>()
        o.optJSONObject("newWeekly")?.let { nj -> nj.keys().forEach { k -> newWeekly[k] = nj.getInt(k) } }
        return WizardDraft(
            mode = o.optString("mode", "new"),
            subjects = jsonToList(o.optJSONArray("subjects")),
            backlogs = backlogs, weekPlan = weekPlan,
            restDays = jsonToSet(o.optJSONArray("restDays")),
            startDate = o.optString("startDate"), endDate = o.optString("endDate"),
            dailyStudyMin = o.optInt("dailyStudyMin", 240),
            schoolDays = jsonToSet(o.optJSONArray("schoolDays")),
            oldOnly = o.optBoolean("oldOnly", true), newWeekly = newWeekly,
            hasNewScheduleReady = o.optBoolean("hasNewScheduleReady", false),
            finalGoal = o.optString("finalGoal")
        )
    }
}

// ===== بنّاء البرومبت — يعكس اختيارات الطالب حرفيًا =====

object WizardPromptBuilder {
    fun build(d: WizardDraft): String = buildString {
        appendLine("أنت منظّم جداول دراسية لطالب السادس العلمي. أنشئ ملف JSON واحدًا وفق صيغة rafiq_schedule_v1.")
        appendLine("ممنوع اختراع محاضرات أو أرقام أو أسماء غير موجودة في بيانات الطالب أدناه.")
        appendLine()
        appendLine("=== بيانات الطالب (مصدرها الأساسي) ===")
        appendLine("نوع العملية: ${if (d.mode == "replan") "إعادة تنظيم جدول موجود مع الإبقاء على المنجز" else "جدول سنوي جديد"}")
        d.subjects.forEach { s ->
            val cnt = d.backlogs[s]
            val days = d.daysFor(s).joinToString("، ").ifBlank { "غير موزعة" }
            appendLine("- $s: تراكم ${cnt ?: "غير محدد"} — الأيام المسموحة: $days")
        }
        appendLine("مجموع التراكمات الكلي: ${d.totalBacklog()} محاضرة")
        if (d.restDays.isNotEmpty()) appendLine("أيام الراحة (ممنوع جدولة أي مهمة دراسية فيها): ${d.restDays.sortedBy { WizardConst.DAYS.indexOf(it) }.joinToString("، ")}")
        appendLine("تاريخ بداية الجدول: ${d.startDate.ifBlank { "؟" }} — تاريخ النهاية: ${d.endDate.ifBlank { "؟" }}" +
            (d.daysCount()?.let { " (المتاح $it يومًا)" } ?: ""))
        appendLine("الحد الأقصى للدراسة يوميًا: ${d.dailyStudyMin / 60} ساعات")
        if (d.schoolDays.isNotEmpty()) appendLine("أيام الدوام المدرسي: ${d.schoolDays.joinToString("، ")}")
        if (d.oldOnly) appendLine("المطلوب: توزيع التراكمات فقط — لا تنشئ أي محاضرة جديدة.")
        else {
            appendLine("المطلوب: توزيع التراكمات + المحاضرات الجديدة.")
            if (d.newWeekly.isNotEmpty()) {
                appendLine("المحاضرات الجديدة المتوقعة أسبوعيًا:")
                d.newWeekly.forEach { (s, n) -> appendLine("- $s: $n محاضرات أسبوعيًا") }
            }
            if (d.hasNewScheduleReady) appendLine("لدى الطالب جدول محاضرات جديدة جاهز — وزّع الجديد وفق أيامها إن ذُكرت، وإلا فوفق الأيام المتاحة.")
        }
        if (d.finalGoal.isNotBlank()) appendLine("هدف مهم: ${d.finalGoal}")
        appendLine()
        appendLine("=== قواعد إلزامية ===")
        appendLine("1. وزّع جميع محاضرات التراكمات (${d.totalBacklog()}) دون فقدان أي محاضرة؛ اجعل العنوان: «تراكم $ — {المادة}» مع ترقيم متسلسل.")
        appendLine("2. جدولة مهام المادة مسموحة فقط في أيامها المذكورة أعلاه؛ استثناءً: مراجعة عامة أو امتحان شامل يجوز توزيعه في يوم آخر مع ذكر ذلك في الملاحظات.")
        appendLine("3. ممنوع جدولة أي مهمة دراسية في أيام الراحة.")
        appendLine("4. لا تتجاوز الحد اليومي (${d.dailyStudyMin} دقيقة)؛ إذا تعذّر التوزيع ضمن الوقت المتاح فاذكر ذلك بوضوح في مصفوفة issues ولا تختصر التراكمات صمتًا.")
        appendLine("5. كل مهمة: تاريخ + مادة + نوع + عنوان + مدة > 0. الأنواع: oldLecture (تراكم)، newLecture (جديدة)، review، homework، dailyExam، cumulativeExam، quiz، commitment.")
        appendLine("6. تحقق أن مجموع المحاضرات لكل مادة يساوي عدد تراكماتها تمامًا.")
        appendLine("7. التواريخ بصيغة YYYY-MM-DD وضمن نطاق الجدول.")
        appendLine("8. أخرج JSON فقط — بلا مقدمات ولا Markdown ولا نص خارج JSON.")
        appendLine("9. إذا كان الملف كبيرًا قسّمه وفق بروتوكول الأجزاء أدناه.")
        appendLine()
        appendLine("=== مخطط الإخراج ===")
        appendLine("""{"format":"rafiq_schedule","formatVersion":1,"metadata":{"scheduleName":"..."},"startDate":"YYYY-MM-DD","endDate":"YYYY-MM-DD","days":[{"date":"YYYY-MM-DD","tasks":[{"id":"فريد","subject":"المادة","type":"oldLecture","title":"...","lectureNo":1,"durationMin":45,"start":"HH:MM","end":"HH:MM","note":"..."}]}]}""")
        appendLine()
        appendLine("=== بروتوكول الأجزاء ===")
        appendLine("""{"format":"rafiq_part","partIndex":1,"totalParts":3,"payload":{"metadata":{...},"startDate":"...","endDate":"...","days":[...أيام كاملة بلا تقطيع...]}}""")
    }
}

// ===== تجميع الأجزاء (كل جزء JSON مستقل يحمل أيامًا كاملة) =====

object PartAssembler {
    data class Assembly(val text: String?, val errors: List<String>)

    fun assemble(parts: List<String>): Assembly {
        if (parts.isEmpty()) return Assembly(null, listOf("لا توجد أجزاء."))
        val metas = mutableListOf<Triple<Int, Int, JSONObject>>()
        val errors = mutableListOf<String>()
        parts.forEachIndexed { i, raw ->
            try {
                val o = JSONObject(raw.trim())
                if (o.optString("format") != "rafiq_part") { errors += "الجزء ${i + 1} ليس جزءًا (format=rafiq_part)."; return@forEachIndexed }
                val payload = o.optJSONObject("payload") ?: run { errors += "الجزء ${i + 1} يفتقد payload."; return@forEachIndexed }
                if (!payload.has("days")) { errors += "الجزء ${i + 1} يفتقد payload.days."; return@forEachIndexed }
                metas += Triple(o.getInt("partIndex"), o.getInt("totalParts"), payload)
            } catch (e: Exception) { errors += "الجزء ${i + 1} ليس JSON صالحًا." }
        }
        if (errors.isNotEmpty()) return Assembly(null, errors)
        val total = metas.first().second
        if (metas.any { it.second != total }) return Assembly(null, listOf("عدد الأجزاء الكلي غير متطابق."))
        if (metas.size != total) return Assembly(null, listOf("الأجزاء المستلمة ${metas.size} من أصل $total."))
        val sorted = metas.sortedBy { it.first }
        if (sorted.map { it.first } != (1..total).toList()) return Assembly(null, listOf("أرقام الأجزاء غير متسلسلة: ${sorted.map { it.first }}"))
        val first = sorted.first().third
        val days = JSONArray(); val seen = mutableSetOf<String>()
        sorted.forEach { (_, _, payload) ->
            val arr = payload.getJSONArray("days")
            for (j in 0 until arr.length()) {
                val day = arr.getJSONObject(j); val dd = day.optString("date")
                if (dd.isNotBlank() && !seen.add(dd)) errors += "تاريخ مكرر بين الأجزاء: $dd"
                days.put(day)
            }
        }
        if (errors.isNotEmpty()) return Assembly(null, errors.distinct())
        return Assembly(JSONObject().apply {
            put("format", "rafiq_schedule"); put("formatVersion", 1)
            put("metadata", first.optJSONObject("metadata") ?: JSONObject())
            if (first.has("startDate")) put("startDate", first.getString("startDate"))
            if (first.has("endDate")) put("endDate", first.getString("endDate"))
            put("days", days)
        }.toString(), emptyList())
    }
}

// ===== التحقق والمعاينة =====

data class PlanStats(
    val dayCount: Int, val taskCount: Int, val totalMin: Int,
    val perSubject: Map<String, Int>, val highLoadDays: List<Pair<String, Int>>,
    val oldLectures: Int, val newLectures: Int, val warnings: List<String>
)

object WizardVerify {
    fun stats(file: ScheduleFile, d: WizardDraft): PlanStats {
        val perSubject = mutableMapOf<String, Int>()
        var total = 0; var oldL = 0; var newL = 0
        val daily = mutableMapOf<String, Int>()
        file.days.forEach { day ->
            var dayMin = 0
            day.tasks.forEach { t ->
                perSubject[t.subject] = (perSubject[t.subject] ?: 0) + 1
                total += t.durationMin; dayMin += t.durationMin
                if (t.type == TaskTypes.OLD) oldL++
                if (t.type == TaskTypes.NEW) newL++
            }
            daily[day.date.toString()] = dayMin
        }
        val warnings = mutableListOf<String>()
        val high = daily.filter { it.value > d.dailyStudyMin }.toList().sortedByDescending { it.second }
        high.forEach { (dd, m) -> warnings += "يوم $dd يتجاوز الحد اليومي (${m / 60}س ${m % 60}د > ${d.dailyStudyMin / 60}س)." }
        // مطابقة أعداد التراكمات المتوقعة فعليًا (حساب داخلي، لا من أرقام النموذج)
        val actualOld = mutableMapOf<String, Int>()
        file.days.forEach { day -> day.tasks.filter { it.type == TaskTypes.OLD }.forEach { t ->
            actualOld[t.subject] = (actualOld[t.subject] ?: 0) + 1 } }
        d.backlogs.forEach { (s, n) ->
            val act = actualOld[s] ?: 0
            if (act != n) warnings += "تراكمات $s: الموزعة $act ≠ المطلوبة $n."
        }
        val start = file.startDate; val end = file.endDate
        if (start != null && end != null) {
            val days = ChronoUnit.DAYS.between(start, end) + 1
            if (days < file.days.size) warnings += "عدد الأيام (${file.days.size}) أكبر من نطاق التواريخ ($days)."
        }
        return PlanStats(file.days.size, file.taskCount(), total,
            perSubject.toList().sortedByDescending { it.second }.toMap(), high, oldL, newL, warnings.distinct())
    }

    /** تحقق مطابقة الملف لخطة الطالب: الأيام المسموحة، الراحة، النطاق، المدد، المعرّفات. */
    fun compliance(file: ScheduleFile, d: WizardDraft): List<String> {
        val errors = mutableListOf<String>()
        val ids = mutableSetOf<String>()
        val start = file.startDate; val end = file.endDate
        file.days.forEach { day ->
            val dayName = WizardConst.dayOfWeekName(day.date.dayOfWeek)
            if (start != null && end != null && (day.date < start || day.date > end))
                errors += "يوم ${day.date} خارج نطاق الجدول."
            if (dayName in d.restDays)
                day.tasks.forEach { errors += "مهمة «${it.title}» (${it.subject}) مجدولة في يوم راحة ($dayName ${day.date})." }
            day.tasks.forEach { t ->
                if (!ids.add(t.id)) errors += "معرّف مكرر: ${t.id}."
                if (t.durationMin <= 0) errors += "مدة غير صالحة (${t.durationMin}) في «${t.title}»."
                if (d.subjects.isNotEmpty() && t.subject !in d.subjects)
                    errors += "مادة غير معروفة في المسودة: «${t.subject}» (مهمة ${t.id})."
                if (t.type == TaskTypes.OLD || t.type == TaskTypes.NEW) {
                    val allowed = d.weekPlan[dayName] ?: emptySet()
                    if (allowed.isNotEmpty() && t.subject !in allowed)
                        errors += "«${t.title}» (${t.subject}) مجدولة يوم $dayName وهو ليس من أيامها المسموحة."
                }
            }
        }
        return errors.distinct()
    }
}
