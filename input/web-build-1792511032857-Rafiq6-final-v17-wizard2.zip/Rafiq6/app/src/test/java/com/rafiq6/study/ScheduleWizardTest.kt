package com.rafiq6.study

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class ScheduleWizardTest {

    // ===== اختبار A: المواد =====
    @Test fun subjectsAddRemoveAndCustom() {
        var d = WizardDraft()
        d = WeekOps.addSubject(d, "الفيزياء")
        d = WeekOps.addSubject(d, "الكيمياء")
        d = WeekOps.addSubject(d, "الفرنسي")
        assertEquals(listOf("الفيزياء", "الكيمياء", "الفرنسي"), d.subjects)
        // إضافة مكررة لا تغير شيئًا
        val before = d
        d = WeekOps.addSubject(d, "الفيزياء")
        assertEquals(before, d)
        // إزالة مادة تنظف تراكماتها وتوزيعها
        d = d.copy(backlogs = d.backlogs + ("الفرنسي" to 3),
            weekPlan = d.weekPlan + ("السبت" to setOf("الفرنسي")))
        d = WeekOps.removeSubject(d, "الفرنسي")
        assertFalse(d.subjects.contains("الفرنسي"))
        assertFalse(d.backlogs.containsKey("الفرنسي"))
        assertTrue((d.weekPlan["السبت"] ?: emptySet()).isEmpty())
        // جدول المسودة منفصل — لا يمس الجدول الفعّال (لا يوجد تعديل على Room هنا)
    }

    // ===== اختبار B: التراكمات والمجموع =====
    @Test fun backlogTotalsReactToChanges() {
        var d = WizardDraft(subjects = listOf("الفيزياء", "الكيمياء", "الرياضيات", "الأحياء"))
        d = d.copy(backlogs = mapOf("الفيزياء" to 90, "الكيمياء" to 50, "الرياضيات" to 0, "الأحياء" to 25))
        assertEquals(165, d.totalBacklog())
        d = d.copy(backlogs = d.backlogs + ("الفيزياء" to 80))
        assertEquals(155, d.totalBacklog())
        // صفر مؤكد يختلف عن غير المؤكد
        assertTrue(d.missingBacklogs().isEmpty())
        val d2 = d.copy(backlogs = d.backlogs - "الكيمياء")
        assertEquals(listOf("الكيمياء"), d2.missingBacklogs())
        assertEquals(105, d2.totalBacklog()) // لا يُحتسب غير المؤكد
    }

    // ===== اختبار C: توزيع الأسبوع والراحة والاستمرارية =====
    @Test fun weekPlanToggleRestAndCopyDay() {
        var d = WizardDraft(subjects = listOf("الفيزياء", "الكيمياء", "الرياضيات"))
        d = WeekOps.toggle(d, "السبت", "الفيزياء")
        d = WeekOps.toggle(d, "الأربعاء", "الفيزياء")
        d = WeekOps.toggle(d, "الأحد", "الكيمياء")
        d = WeekOps.toggle(d, "الخميس", "الكيمياء")
        assertEquals(listOf("السبت", "الأربعاء"), d.daysFor("الفيزياء"))
        assertEquals(listOf("الأحد", "الخميس"), d.daysFor("الكيمياء"))
        assertEquals(listOf("الرياضيات"), d.undistributed())
        // إلغاء اختيار ينعكس فورًا
        d = WeekOps.toggle(d, "السبت", "الفيزياء")
        assertEquals(listOf("الأربعاء"), d.daysFor("الفيزياء"))
        // الراحة تمنع الإضافة وتفرغ اليوم
        d = WeekOps.setRest(d, "الجمعة", true)
        d = WeekOps.toggle(d, "الجمعة", "الرياضيات")
        assertTrue("الجمعة" in d.restDays)
        assertTrue(d.daysFor("الرياضيات").isEmpty())
        d = WeekOps.setRest(d, "الجمعة", false)
        d = WeekOps.toggle(d, "الجمعة", "الرياضيات")
        assertEquals(listOf("الجمعة"), d.daysFor("الرياضيات"))
        // نسخ يوم إلى آخر
        d = WeekOps.copyDay(d, "الأربعاء", listOf("الاثنين", "الثلاثاء"))
        assertEquals(listOf("الأربعاء", "الاثنين", "الثلاثاء"), d.daysFor("الفيزياء"))
        // تحديد الكل / إلغاء الكل
        d = WeekOps.setAll(d, "السبت")
        assertEquals(setOf("الفيزياء", "الكيمياء", "الرياضيات"), d.weekPlan["السبت"])
        d = WeekOps.clearDay(d, "السبت")
        assertTrue(d.weekPlan["السبت"]!!.isEmpty())
    }

    // ===== اختبار D: البرومبت يعكس التعديلات حرفيًا =====
    @Test fun promptReflectsDraftChanges() {
        var d = WizardDraft(
            subjects = listOf("الفيزياء", "الكيمياء"),
            backlogs = mapOf("الفيزياء" to 90, "الكيمياء" to 50),
            weekPlan = mapOf("السبت" to setOf("الفيزياء"), "الأربعاء" to setOf("الفيزياء"),
                "الأحد" to setOf("الكيمياء"), "الخميس" to setOf("الكيمياء")),
            startDate = "2026-01-01", endDate = "2026-06-01", dailyStudyMin = 300)
        var p = WizardPromptBuilder.build(d)
        assertTrue(p.contains("الفيزياء: تراكم 90"))
        assertTrue(p.contains("الأيام المسموحة: السبت، الأربعاء"))
        assertTrue(p.contains("2026-01-01"))
        assertTrue(p.contains("rafiq_schedule"))
        // تغيير التوزيع يغير البرومبت
        d = WeekOps.toggle(d, "الأربعاء", "الفيزياء")
        d = WeekOps.toggle(d, "الاثنين", "الفيزياء")
        d = WeekOps.toggle(d, "الخميس", "الفيزياء")
        p = WizardPromptBuilder.build(d)
        assertFalse(p.contains("الأيام المسموحة: السبت، الأربعاء"))
        assertTrue(p.contains("الأيام المسموحة: السبت، الاثنين، الخميس"))
    }

    // ===== اختبار E: الملف — صالح/باطل/ناقص/مكرر/تواريخ/خارج الخطة =====
    private fun validFileJson(): String {
        fun t(id: String, date: String, subj: String, type: String, title: String, min: Int) =
            """{"id":"$id","subject":"$subj","type":"$type","title":"$title","durationMin":$min}"""
        return """{"format":"rafiq_schedule","formatVersion":1,"startDate":"2026-01-03","endDate":"2026-01-10",
            "days":[
              {"date":"2026-01-03","tasks":[${t("a1","2026-01-03","الفيزياء","oldLecture","تراكم 1",90)}]},
              {"date":"2026-01-07","tasks":[${t("a2","2026-01-07","الفيزياء","oldLecture","تراكم 2",90)}]}
            ]}"""
    }

    @Test fun fileValidPassesAllChecks() {
        val d = WizardDraft(
            subjects = listOf("الفيزياء"), backlogs = mapOf("الفيزياء" to 2),
            weekPlan = mapOf("السبت" to setOf("الفيزياء"), "الأربعاء" to setOf("الفيزياء")),
            startDate = "2026-01-03", endDate = "2026-01-10", dailyStudyMin = 360)
        val r = ScheduleParser.parse(validFileJson())
        assertTrue(r.errors.toString(), r.ok)
        assertTrue(WizardVerify.compliance(r.file!!, d).isEmpty())
        val st = WizardVerify.stats(r.file!!, d)
        assertEquals(2, st.oldLectures)
        assertEquals(180, st.totalMin)
        assertTrue(st.warnings.isEmpty()) // 2 تراكمات = المطلوب تمامًا
    }

    @Test fun fileRejectsDuplicatesBadDatesAndOffPlan() {
        val dup = """{"format":"rafiq_schedule","formatVersion":1,"startDate":"2026-01-03","endDate":"2026-01-03",
            "days":[{"date":"2026-01-03","tasks":[
              {"id":"x","subject":"الفيزياء","type":"oldLecture","title":"أ","durationMin":60},
              {"id":"x","subject":"الفيزياء","type":"oldLecture","title":"ب","durationMin":60}]}]}"""
        val r1 = ScheduleParser.parse(dup)
        assertFalse(r1.ok) // المحرك نفسه يرفض المكرر

        val badDate = """{"format":"rafiq_schedule","formatVersion":1,"startDate":"2026-01-03","endDate":"2026-01-03",
            "days":[{"date":"2026-02-30","tasks":[{"id":"y","subject":"الفيزياء","type":"oldLecture","title":"أ","durationMin":60}]}]}"""
        assertFalse(ScheduleParser.parse(badDate).ok)

        // مهمة خارج الأيام المسموحة للمادة
        val offPlan = """{"format":"rafiq_schedule","formatVersion":1,"startDate":"2026-01-04","endDate":"2026-01-04",
            "days":[{"date":"2026-01-04","tasks":[{"id":"z","subject":"الفيزياء","type":"oldLecture","title":"أ","durationMin":60}]}]}"""
        val d = WizardDraft(subjects = listOf("الفيزياء"),
            weekPlan = mapOf("السبت" to setOf("الفيزياء"))) // 2026-01-04 يوم أحد
        val r3 = ScheduleParser.parse(offPlan)
        assertTrue(r3.ok)
        assertTrue(WizardVerify.compliance(r3.file!!, d).any { it.contains("غير مسموحة") })

        // مهمة في يوم راحة
        val restViol = """{"format":"rafiq_schedule","formatVersion":1,"startDate":"2026-01-03","endDate":"2026-01-03",
            "days":[{"date":"2026-01-03","tasks":[{"id":"w","subject":"الفيزياء","type":"review","title":"مراجعة","durationMin":30}]}]}"""
        val d2 = WizardDraft(subjects = listOf("الفيزياء"), restDays = setOf("السبت"))
        val r4 = ScheduleParser.parse(restViol)
        assertTrue(WizardVerify.compliance(r4.file!!, d2).any { it.contains("راحة") })
    }

    // ===== اختبار F: تجميع الأجزاء =====
    @Test fun partAssemblyRoundTrip() {
        fun part(i: Int, t: Int, vararg dates: String) = JSONObject().apply {
            put("format", "rafiq_part"); put("partIndex", i); put("totalParts", t)
            put("payload", JSONObject().apply {
                put("metadata", JSONObject().put("scheduleName", "تجريبي"))
                put("days", org.json.JSONArray().apply { dates.forEach { dd ->
                    put(JSONObject().put("date", dd).put("tasks", org.json.JSONArray())) } })
            })
        }.toString()
        val asm = PartAssembler.assemble(listOf(part(2, 2, "2026-01-02"), part(1, 2, "2026-01-01")))
        assertTrue(asm.errors.isEmpty())
        val root = JSONObject(asm.text)
        assertEquals("rafiq_schedule", root.getString("format"))
        assertEquals(2, root.getJSONArray("days").length())
        assertTrue(PartAssembler.assemble(listOf(part(1, 2, "2026-01-01"))).errors.isNotEmpty())
        assertTrue(PartAssembler.assemble(listOf(part(1, 2, "2026-01-01"), part(2, 2, "2026-01-01"))).errors.isNotEmpty())
    }

    // ===== ترميز المسودة =====
    @Test fun draftCodecRoundTrip() {
        var d = WizardDraft(mode = "replan", subjects = listOf("الفيزياء", "الكيمياء"),
            backlogs = mapOf("الفيزياء" to 90, "الكيمياء" to 0),
            weekPlan = mapOf("السبت" to setOf("الفيزياء")),
            restDays = setOf("الجمعة"), startDate = "2026-01-01", endDate = "2026-06-01",
            dailyStudyMin = 300, schoolDays = setOf("السبت", "الأحد"),
            oldOnly = false, newWeekly = mapOf("الفيزياء" to 2), hasNewScheduleReady = true)
        d = WeekOps.toggle(d, "الأربعاء", "الفيزياء")
        val back = WizardDraftCodec.fromJson(WizardDraftCodec.toJson(d))
        assertEquals(d, back)
        assertEquals(90, back.totalBacklog())
        assertEquals(listOf("السبت", "الأربعاء"), back.daysFor("الفيزياء"))
    }

    @Test fun draftReadyChecks() {
        var d = WizardDraft(subjects = listOf("الفيزياء"))
        assertTrue(d.readyForSummary().isNotEmpty())
        d = d.copy(backlogs = mapOf("الفيزياء" to 5),
            startDate = "2026-01-01", endDate = "2026-01-02",
            weekPlan = mapOf("السبت" to setOf("الفيزياء")))
        assertTrue(d.readyForSummary().isEmpty())
        assertNotNull(d.copy(endDate = "2025-12-01").validateDates())
    }
}
