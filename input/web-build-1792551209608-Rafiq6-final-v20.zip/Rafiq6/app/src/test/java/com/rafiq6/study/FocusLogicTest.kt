package com.rafiq6.study

import org.junit.Assert.*
import org.junit.Test

class FocusLogicTest {
    private fun state(plan: Int = 25, startE: Long = 1000) =
        FocusState("id1", "فيزياء", plan, startE, startE + plan * 60_000L,
            1_700_000_000_000L, 1_700_000_000_000L + plan * 60_000L, true)

    @Test fun phrasesAreExactly50AndUnique() {
        assertEquals(50, FocusPhrases.all.size)
        assertEquals(50, FocusPhrases.all.toSet().size)
        assertTrue(FocusPhrases.all.all { it.isNotBlank() })
    }

    @Test fun randomNeverRepeatsLastImmediately() {
        val last = FocusPhrases.all[0]
        repeat(300) { assertNotEquals(last, FocusPhrases.randomExcept(last)) }
    }

    @Test fun remainingCountsDownWithMonotonicClock() {
        val s = state()
        assertEquals(25 * 60_000L, FocusMath.remainingMs(s, 1000, 1_700_000_000_000L))
        assertEquals(10 * 60_000L, FocusMath.remainingMs(s, 1000 + 15 * 60_000L, 0))
        assertTrue(FocusMath.isExpired(s, 1000 + 25 * 60_000L, 0))
    }

    @Test fun fallsBackToWallClockAfterReboot() {
        // بعد إعادة التشغيل: nowElapsed أصغر من startElapsed → نستخدم الساعة الجدارية.
        val s = state(startE = 500_000)
        assertEquals(20 * 60_000L, FocusMath.remainingMs(s, 1000, 1_700_000_000_000L + 5 * 60_000L))
    }

    @Test fun progressGrowsTo100() {
        val s = state(plan = 30)
        assertEquals(0, FocusMath.progressPct(s, 1000, 0))
        assertEquals(50, FocusMath.progressPct(s, 1000 + 15 * 60_000L, 0))
        assertEquals(100, FocusMath.progressPct(s, 1000 + 30 * 60_000L, 0))
    }

    @Test fun notRunningMeansNoRemaining() {
        val s = state().copy(running = false)
        assertEquals(0, FocusMath.remainingMs(s, 1000, 0))
        val empty = state().copy(sessionId = "")
        assertFalse(empty.running || FocusMath.remainingMs(empty, 1000, 0) != 0L)
    }

    @Test fun clockFormat() {
        assertEquals("25:00", FocusMath.fmtClock(25 * 60_000L))
        assertEquals("0:59", FocusMath.fmtClock(59_000L))
        assertEquals("0:00", FocusMath.fmtClock(-5))
    }
}
