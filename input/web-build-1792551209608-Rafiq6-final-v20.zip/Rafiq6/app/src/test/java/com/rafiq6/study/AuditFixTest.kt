package com.rafiq6.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PdfAuditGuardTest {
    @Test fun `pdf signature is necessary but larger limits remain explicit`() {
        assertTrue(PdfValidator.isPdf("%PDF-1.7\n".toByteArray()))
        assertFalse(PdfValidator.isPdf("PDF-1.7".toByteArray()))
        assertEquals(500, PdfImportService.MAX_PAGES)
        assertEquals(50L * 1024L * 1024L, PdfImportService.MAX_FILE_BYTES)
    }

    @Test fun `document metadata round trip preserves source identity`() {
        val doc = PdfDocumentEntity("d", "content://x", "ملف.pdf", 20, true, "تحذير")
        val decoded = BankJsonCodec.document(BankJsonCodec.document(doc))
        assertEquals(doc, decoded)
        val page = PdfPageTextEntity("d", 7, "نص الصفحة")
        assertEquals(page, BankJsonCodec.page(BankJsonCodec.page(page)))
    }
}

class QuizAttemptAuditTest {
    private fun answer(id: String, q: String) = AttemptAnswerEntity(id, "a", q, "إجابة", false, 10L, 0, 0, "2026-10-19")
    private fun question(id: String, text: String = "س $id") = QuestionEntity(id, "d", "ملف", 1, "مادة", "موضوع", text)

    @Test fun `duplicate answer is rejected by policy`() {
        val answers = listOf(answer("1", "q1"), answer("2", "q2"))
        assertEquals("هذا السؤال مسجل في المحاولة الحالية بالفعل.", QuizAttemptPolicy.duplicateMessage(answers, "q1"))
        assertNull(QuizAttemptPolicy.duplicateMessage(answers, "q3"))
    }

    @Test fun `resume reconstruction keeps answered first and never duplicates remaining`() {
        val all = listOf(question("q1"), question("q2"), question("q3"), question("q4"))
        val answeredInOrder = listOf(all[1], all[0])
        val reconstructed = QuizAttemptReconstruction.remainingOrder(answeredInOrder, all)
        assertEquals(listOf("q2", "q1", "q3", "q4"), reconstructed.map { it.id })
        assertEquals(4, reconstructed.distinctBy { it.id }.size)
    }

    @Test fun `resume reconstruction does not lose questions when source list changed`() {
        val all = listOf(question("q1"), question("q2"), question("q4"))
        val answered = listOf(question("q2"))
        val reconstructed = QuizAttemptReconstruction.remainingOrder(answered, all)
        assertEquals(listOf("q2", "q1", "q4"), reconstructed.map { it.id })
    }
}

class ReviewAuditTest {
    @Test fun `completed review does not become due merely by passing date`() {
        val q = QuestionEntity("q", "d", "ملف", 1, "مادة", "موضوع", "س", reviewStage = ReviewScheduler.MAX_STAGE, nextReviewAt = null, lastResult = "صحيح")
        val today = "2020-01-01"
        assertFalse(q.nextReviewAt != null && q.nextReviewAt <= today)
    }

    @Test fun `question review state is not changed by viewing source`() {
        val q = QuestionEntity("q", "d", "ملف", 4, "مادة", "موضوع", "س", reviewStage = 2, nextReviewAt = "2026-11-01")
        val opened = q.copy()
        assertEquals(q, opened)
    }
}
