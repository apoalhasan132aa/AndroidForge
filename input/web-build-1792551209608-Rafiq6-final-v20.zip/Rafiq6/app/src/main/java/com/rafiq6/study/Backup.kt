package com.rafiq6.study

import android.content.Context
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object Backup {
    suspend fun export(c: Context): File {
        val schedules = AppDb.get(c).dao().schedules().first()
        val allTasks = AppDb.get(c).dao().allTasks().first()
        val allProgress = AppDb.get(c).dao().allProgress().first()
        val activities = AppDb.get(c).act().all2().first()
        val bank = AppDb.get(c).bank()
        val documents = bank.documentsOnce(); val pageTexts = bank.pageTextsOnce(); val questions = bank.questionsOnce()
        val attempts = bank.attemptsOnce(); val quizAnswers = bank.answersOnce()
        val root = JSONObject().apply {
            put("format", "rafiq_full_backup"); put("formatVersion", 1)
            put("createdAt", System.currentTimeMillis())
            put("schedules", JSONArray().apply { schedules.forEach { put(JsonCodec.scheduleToJson(it)) } })
            put("tasks", JSONArray().apply { allTasks.forEach { put(JsonCodec.taskToJson(it)) } })
            put("progress", JSONArray().apply { allProgress.forEach { put(JsonCodec.progressToJson(it)) } })
            put("activities", JSONArray().apply { activities.forEach { put(activityToJson(it)) } })
            put("pdfDocuments", JSONArray().apply { documents.forEach { put(BankJsonCodec.document(it)) } })
            put("pdfPageTexts", JSONArray().apply { pageTexts.forEach { put(BankJsonCodec.page(it)) } })
            put("questions", JSONArray().apply { questions.forEach { put(BankJsonCodec.question(it)) } })
            put("quizAttempts", JSONArray().apply { attempts.forEach { put(BankJsonCodec.attempt(it)) } })
            put("attemptAnswers", JSONArray().apply { quizAnswers.forEach { put(BankJsonCodec.answer(it)) } })
        }
        val f = File(c.cacheDir, "backups/rafiq6-full-backup.json"); f.parentFile?.mkdirs()
        f.writeText(root.toString(2)); return f
    }

    suspend fun import(c: Context, json: String) {
        val root = JSONObject(json)
        if (root.optString("format") != "rafiq_full_backup" || root.optInt("formatVersion") != 1)
            throw IllegalArgumentException("ملف النسخة الاحتياطية غير صالح أو إصدار الصيغة غير مدعوم.")
        val schedules = root.getJSONArray("schedules").let { a -> (0 until a.length()).map { JsonCodec.scheduleFromJson(a.getJSONObject(it)) } }
        val tasks = root.getJSONArray("tasks").let { a -> (0 until a.length()).map { JsonCodec.taskFromJson(a.getJSONObject(it)) } }
        val progress = root.getJSONArray("progress").let { a -> (0 until a.length()).map { JsonCodec.progressFromJson(a.getJSONObject(it)) } }
        val activities = root.optJSONArray("activities")?.let { a -> (0 until a.length()).map { activityFromJson(a.getJSONObject(it)) } } ?: emptyList()
        if (schedules.isEmpty()) throw IllegalArgumentException("النسخة الاحتياطية لا تحتوي أي جدول.")
        val arr = { name: String -> root.optJSONArray(name) }
        val documents = arr("pdfDocuments")?.let { a -> (0 until a.length()).map { BankJsonCodec.document(a.getJSONObject(it)) } } ?: emptyList()
        val pageTexts = arr("pdfPageTexts")?.let { a -> (0 until a.length()).map { BankJsonCodec.page(a.getJSONObject(it)) } } ?: emptyList()
        val questions = arr("questions")?.let { a -> (0 until a.length()).map { BankJsonCodec.question(a.getJSONObject(it)) } } ?: emptyList()
        val attempts = arr("quizAttempts")?.let { a -> (0 until a.length()).map { BankJsonCodec.attempt(a.getJSONObject(it)) } } ?: emptyList()
        val quizAnswers = arr("attemptAnswers")?.let { a -> (0 until a.length()).map { BankJsonCodec.answer(a.getJSONObject(it)) } } ?: emptyList()
        AppDb.get(c).restoreDao().restoreAll(
            schedules, tasks, progress, activities,
            documents, pageTexts, questions, attempts, quizAnswers
        )
    }

    private fun activityToJson(a: ActivityEntity): JSONObject = JSONObject().apply {
        put("id", a.id); put("date", a.date); put("kind", a.kind); put("title", a.title)
        put("durationMin", a.durationMin)
        a.startMin?.let { put("startMin", it) } ?: put("startMin", JSONObject.NULL)
        put("done", a.done)
        a.postponedFrom?.let { put("postponedFrom", it) } ?: put("postponedFrom", JSONObject.NULL)
    }

    private fun activityFromJson(o: JSONObject): ActivityEntity = ActivityEntity(
        id = o.getString("id"), date = o.getString("date"), kind = o.getString("kind"),
        title = o.getString("title"), durationMin = o.getInt("durationMin"),
        startMin = if (o.isNull("startMin")) null else o.getInt("startMin"),
        done = o.optBoolean("done"),
        postponedFrom = if (o.isNull("postponedFrom")) null else o.optString("postponedFrom")
    )
}
