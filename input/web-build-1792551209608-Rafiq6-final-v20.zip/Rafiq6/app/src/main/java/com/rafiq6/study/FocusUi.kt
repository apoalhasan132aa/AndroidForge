package com.rafiq6.study

import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable fun FocusHubScreen(vm: MainVm, tasks: List<UiTask>) {
    val f by vm.focus.collectAsState()
    var done by remember { mutableStateOf<FocusState?>(null) }
    var showApps by remember { mutableStateOf(false) }
    val totals by vm.focusTotals.collectAsState()
    val d = done
    when {
        showApps -> FocusAppsScreen(onPicked = { showApps = false }, onClose = { showApps = false })
        d != null -> FocusDoneScreen(d, totals) { done = null }
        f.running -> FocusSessionScreen(vm) { finished -> done = finished }
        else -> FocusSetupScreen(vm, tasks) { showApps = true }
    }
}

@Composable private fun permStatus(ctx: Context): Triple<Boolean, Boolean, Boolean> {
    val notif = Build.VERSION.SDK_INT < 33 ||
        ctx.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val dnd = nm.isNotificationPolicyAccessGranted
    val exact = Build.VERSION.SDK_INT < 31 ||
        (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
    return Triple(notif, dnd, exact)
}

@Composable fun FocusSetupScreen(vm: MainVm, tasks: List<UiTask>, onOpenApps: () -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by vm.settings.collectAsState()
    val focus by vm.focus.collectAsState()
    val today = Subjects.now().toLocalDate().toString()
    val todays = tasks.filter { it.date == today && !it.done }.sortedBy { it.startMin ?: 9999 }
    var sel by remember { mutableStateOf<UiTask?>(null) }
    var freeTitle by remember { mutableStateOf("") }
    var dur by remember { mutableStateOf(25) }
    var custom by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    var companionPkg by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { companionPkg = FocusAppsStore.companionOf(ctx) }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        LaunchedEffect(Unit) { companionPkg = FocusAppsStore.companionOf(ctx) }
        Text("وضع التركيز الإجباري", style = MaterialTheme.typography.headlineSmall)
        Text("جلسة محاضرة بمؤقت، مع تثبيت الشاشة (إن فعّلته) وتقليل المشتّتات. لا يجمع التطبيق أي بيانات استخدام.")

        if (focus.running) Card(Modifier.fillMaxWidth()) {
            Text("⚠ توجد جلسة نشطة حاليًا. أنهِها أولًا من شاشة الجلسة.", Modifier.padding(12.dp),
                color = MaterialTheme.colorScheme.error) }

        Text("1) اختر المحاضرة من جدول اليوم (أو اكتب مهمة حرة):", style = MaterialTheme.typography.titleSmall)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = sel == null, onClick = { sel = null })
                    Text("مهمة حرة")
                }
                OutlinedTextField(value = freeTitle, onValueChange = { freeTitle = it },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = sel == null, label = { Text("اسم المهمة (مثال: حل مسائل الفيزياء)") })
                todays.take(8).forEach { t ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = sel?.id == t.id, onClick = { sel = t; freeTitle = "" })
                        Text("${t.title} · ${t.durationMin} د", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                if (todays.isEmpty()) Text("لا مهام متبقية اليوم — استخدم مهمة حرة.", style = MaterialTheme.typography.bodySmall)
            }
        }

        Text("2) مدة الجلسة:", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(15, 25, 30, 45, 60, 90).forEach { m ->
                FilterChip(selected = dur == m && !custom, onClick = { dur = m; custom = false }, label = { Text("$m") })
            }
            FilterChip(selected = custom, onClick = { custom = true }, label = { Text("مخصص") })
        }
        if (custom) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("$dur دقيقة"); Slider(value = dur.toFloat(), onValueChange = { dur = it.toInt() },
                valueRange = 5f..180f, modifier = Modifier.fillMaxWidth())
        }

        Text("3) ملخص قبل البدء:", style = MaterialTheme.typography.titleSmall)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("المحاضرة: ${sel?.title ?: freeTitle.ifBlank { "جلسة تركيز" }}", style = MaterialTheme.typography.titleMedium)
            val endMin = (Subjects.now().hour * 60 + Subjects.now().minute + dur) % (24 * 60)
            Text("المدة: $dur دقيقة · تنتهي تقريبًا الساعة ${Subjects.fmt12(endMin)}")
        } }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = settings.focusPin, onCheckedChange = { v -> scope.launch { vm.saveSettings(settings.copy(focusPin = v)) } })
            Text("تثبيت الشاشة أثناء الجلسة (Screen Pinning — بموافقتك من النظام)")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = settings.focusDnd, onCheckedChange = { v -> scope.launch { vm.saveSettings(settings.copy(focusDnd = v)) } })
            Text("كتم إشعارات التطبيقات الأخرى أثناء الجلسة (عدم الإزعاج — اختياري)")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("تأخير زر الإنهاء: ${settings.focusExitDelaySec} ثوانٍ")
            Slider(value = settings.focusExitDelaySec.toFloat(),
                onValueChange = { v -> scope.launch { vm.saveSettings(settings.copy(focusExitDelaySec = v.toInt())) } },
                valueRange = 5f..30f, modifier = Modifier.weight(1f).padding(start = 8.dp))
        }

        Text("وضع الجلسة:", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = companionPkg == null, onClick = {
                scope.launch { FocusAppsStore.setCompanion(ctx, null) }; companionPkg = null
            }, label = { Text("رفيق فقط") })
            FilterChip(selected = companionPkg != null, onClick = { onOpenApps() },
                label = { Text(if (companionPkg != null) "رفيق + ${FocusAppsStore.labelOf(ctx, companionPkg!!)}" else "رفيق + تطبيق آخر") })
            FilterChip(selected = false, onClick = { onOpenApps() }, label = { Text("تعديل التطبيقات المسموحة") })
        }
        Text("ملاحظة صادقة: Android لا يسمح لتطبيق عادي بمنع التنقل الفعلي بين تطبيق محدد. التطبيق المرافق محفوظ في ملخص الجلسة، وتثبيت الشاشة (من إعدادات النظام) يقيّدك داخل التطبيق المثبّت حاليًا — فعّله من «الصلاحيات» إن أردت.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

        val title = sel?.title ?: freeTitle.ifBlank { "جلسة تركيز" }
        Button(onClick = { scope.launch { vm.startFocus(title, dur) } },
            enabled = !focus.running && dur >= 5, modifier = Modifier.fillMaxWidth()) {
            Text("ابدأ جلسة التركيز ▶")
        }
        OutlinedButton(onClick = { showHelp = true }, modifier = Modifier.fillMaxWidth()) { Text("الصلاحيات المطلوبة وكيف تفعّلها") }

        if (showHelp) FocusHelpDialog(ctx) { showHelp = false }
    }
}

@Composable private fun FocusHelpDialog(ctx: Context, onClose: () -> Unit) {
    val (notif, dnd, exact) = permStatus(ctx)
    AlertDialog(onDismissRequest = onClose,
        title = { Text("الصلاحيات وسببها") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("• الإشعارات: ${if (notif) "✓ ممنوحة" else "غير ممنوحة — نستخدمها فقط لتنبيهك عند انتهاء الجلسة. اضغط السماح عند الطلب أو من إعدادات التطبيق."}")
            Text("• عدم الإزعاج (اختياري): ${if (dnd) "✓ ممنوحة" else "غير ممنوحة — نستخدمها لتقليل إشعارات التطبيقات الأخرى أثناء الجلسة فقط، دون حظر المكالمات والمنبهات."}")
            TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }) { Text("فتح إعدادات عدم الإزعاج") }
            Text("• المنبهات الدقيقة: ${if (exact) "✓ ممنوحة" else "غير ممنوحة — نستخدمها احتياطًا لإنهاء الجلسة في وقتها حتى لو كان التطبيق مغلقًا."}")
            TextButton(onClick = { if (Build.VERSION.SDK_INT >= 31) ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)) }) { Text("فتح إعدادات المنبهات") }
            Text("• تثبيت الشاشة: لا يحتاج صلاحية. فعّله من إعدادات الأمان، ويطلب النظام موافقتك عند أول جلسة، ويمكنك فك التثبيت في أي وقت بالإيماءة المعتادة.")
            Text("ملاحظة أمان: التطبيق لا يجمع أسماء التطبيقات التي تفتحها ولا يستطيع إغلاق تطبيقات أخرى بالقوة — هذا مقصود ووفق قيود أندرويد.", style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { TextButton(onClick = onClose) { Text("فهمت") } })
}

@Composable fun FocusSessionScreen(vm: MainVm, onFinished: (FocusState) -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val settings by vm.settings.collectAsState()
    val s by vm.focus.collectAsState()
    var nowE by remember { mutableStateOf(SystemClock.elapsedRealtime()) }
    var nowW by remember { mutableStateOf(System.currentTimeMillis()) }
    var phase by remember { mutableStateOf(0) } // 0 نشطة · 1 تأكيد أول · 2 تأكيد ثانٍ + عداد
    var lastPhrase by remember { mutableStateOf<String?>(null) }
    var phrase by remember { mutableStateOf<String?>(null) }
    var exitLeft by remember { mutableStateOf(settings.focusExitDelaySec) }
    var pinFailed by remember { mutableStateOf(false) }
    var companionPkg by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { companionPkg = FocusAppsStore.companionOf(ctx) }
    var prevFilter by remember { mutableStateOf(-1) }
    var ended by remember { mutableStateOf(false) }

    var showLockHelp by remember { mutableStateOf(false) }
    // فتح التطبيق المرافق المختار + تثبيت الشاشة + كتم الإشعارات الاختياري
    LaunchedEffect(Unit) {
        companionPkg?.let { pkg ->
            runCatching {
                activity?.packageManager?.getLaunchIntentForPackage(pkg)
                    ?.let { activity?.startActivity(it) }
            }
        }
        if (settings.focusPin) try { activity?.startLockTask() }
            catch (e: SecurityException) { pinFailed = true; showLockHelp = true }
            catch (e: Exception) { pinFailed = true; showLockHelp = true }
        if (settings.focusDnd) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted) {
                prevFilter = nm.currentInterruptionFilter
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
            }
        }
    }

    LaunchedEffect(phase) {
        if (phase == 2) {
            phrase = FocusPhrases.randomExcept(lastPhrase); lastPhrase = phrase
            exitLeft = settings.focusExitDelaySec
            while (exitLeft > 0) { delay(1000); exitLeft-- }
        }
    }

    val endSession = { natural: Boolean ->
        if (!ended) {
            ended = true
            runCatching { activity?.stopLockTask() }
            if (prevFilter != -1) runCatching {
                (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                    .setInterruptionFilter(prevFilter) }
            val finished = s
            vm.endFocus(natural)
            onFinished(finished)
        }
    }

    BackHandler { if (phase == 0) phase = 1 }

    LaunchedEffect(Unit) {
        while (true) {
            nowE = SystemClock.elapsedRealtime(); nowW = System.currentTimeMillis()
            val cur = vm.focus.value
            if (!ended && cur.running && FocusMath.isExpired(cur, nowE, nowW)) endSession(true)
            delay(500)
        }
    }

    Column(Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("جلسة تركيز — ${s.title}", style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (pinFailed) Text("لم يُفعّل تثبيت الشاشة. فعّله من إعدادات الأمان › تثبيت الشاشة ثم أعد الجلسة.",
            color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        Text(FocusMath.fmtClock(FocusMath.remainingMs(s, nowE, nowW)), style = MaterialTheme.typography.displayLarge)
        LinearProgressIndicator(progress = { FocusMath.progressPct(s, nowE, nowW) / 100f }, modifier = Modifier.fillMaxWidth())
        Text("المتبقي من ${s.planMin} دقيقة", style = MaterialTheme.typography.bodyMedium)
        Text("التطبيقات المسموحة: رفيق" + (companionPkg?.let { " • ${FocusAppsStore.labelOf(ctx, it)}" } ?: ""),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(onClick = { phase = 1 }) { Text("إنهاء الجلسة") }
    }

    if (phase == 1) AlertDialog(onDismissRequest = { phase = 0 },
        title = { Text("إنهاء المحاضرة؟") },
        text = { Text("هل أنت متأكد أنك تريد إنهاء المحاضرة؟ ما تبقّى لن يُحتسب.") },
        confirmButton = { TextButton(onClick = { phase = 2 }) { Text("نعم، أكمل الخروج") } },
        dismissButton = { TextButton(onClick = { phase = 0 }) { Text("أرجع للمحاضرة") } })

    if (showLockHelp) AlertDialog(onDismissRequest = { showLockHelp = false },
        title = { Text("تثبيت الشاشة غير مفعّل") },
        text = { Text("رفيق لا يستطيع فرض قفل نظامي كامل على جهاز شخصي عادي. للحصول على إجباري حقيقي:" +
            "\n\n١) فعّل «تثبيت التطبيقات» من إعدادات الأمان، وسيطلب النظام موافقتك عند أول جلسة — يبقى التطبيق مثبتًا حتى تلغي أنت." +
            "\n٢) لقفل كامل بلا إلغاء: يجب ضبط الجهاز كـ Device Owner (إعداد مخصص للأجهزة المُدارة) — غير متاح للهاتف الشخصي دون إعادة ضبط وموافقة." +
            "\n\nلا نستطيع وبصدق منع زر الرجوع أو الطوارئ على كل جهاز.") },
        confirmButton = { TextButton(onClick = {
            showLockHelp = false
            runCatching { ctx.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }
        }) { Text("فتح إعدادات الأمان") } },
        dismissButton = { TextButton(onClick = { showLockHelp = false }) { Text("فهمت") } })

    if (phase == 2) AlertDialog(onDismissRequest = { phase = 0 },
        title = { Text("لحظة واحدة…") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(phrase ?: "", style = MaterialTheme.typography.titleMedium)
            if (exitLeft > 0) Text("يمكنك الإنهاء بعد $exitLeft ثانية", style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { TextButton(onClick = { phase = 0 }) { Text("أرجع للمحاضرة") } },
        dismissButton = { TextButton(enabled = exitLeft == 0, onClick = { endSession(false) }) { Text("إنهاء فعلًا") } })
}

@Composable fun FocusDoneScreen(s: FocusState, totals: Pair<Long, Long>?, onClose: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("🎉", style = MaterialTheme.typography.displayLarge)
        Text("أنجزت جلسة تركيز!", style = MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("المحاضرة: ${s.title}", style = MaterialTheme.typography.titleMedium)
            Text("المدة المخططة: ${s.planMin} دقيقة")
            totals?.let { Text("إجمالي جلسات التركيز: ${it.first} جلسة · ${it.second / 60}س ${it.second % 60}د", style = MaterialTheme.typography.bodySmall) }
        } }
        Text(FocusPhrases.randomExcept(null), style = MaterialTheme.typography.bodyMedium)
        Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("رجوع") }
    }
}
