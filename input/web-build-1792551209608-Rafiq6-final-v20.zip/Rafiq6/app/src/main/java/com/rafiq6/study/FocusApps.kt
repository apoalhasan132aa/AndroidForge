package com.rafiq6.study

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.first

data class LaunchableApp(val pkg: String, val label: String, val icon: Drawable?, val launchable: Boolean = true)

object FocusAppsStore {
    private val KEY = stringPreferencesKey("focus_companion")
    suspend fun companionOf(c: Context): String? = c.focusDs.data.first()[KEY]
    suspend fun setCompanion(c: Context, pkg: String?) {
        c.focusDs.edit { if (pkg == null) it.remove(KEY) else it[KEY] = pkg }
    }
    fun labelOf(c: Context, pkg: String): String = runCatching {
        c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)
}

/**
 * قائمة اتحاد التطبيقات المرئية:
 * 1) التطبيقات المثبتة التي تسمح قواعد package visibility (عبر <queries>) برؤيتها.
 * 2) التطبيقات ذات نشاط MAIN/LAUNCHER (تظهر دائمًا حتى بدون queries).
 * لا نستبعد أي تطبيق لمجرد غياب نشاط مشغّل — نعرض كل ما يكشفه النظام.
 */
fun queryLaunchableApps(c: Context): List<LaunchableApp> {
    val pm = c.packageManager
    val pkgs = mutableSetOf<String>()

    // أ) التطبيقات المرئية عبر قواعد الرؤية
    runCatching {
        val apps = if (android.os.Build.VERSION.SDK_INT >= 33)
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        else @Suppress("DEPRECATION") pm.getInstalledApplications(0)
        apps.forEach { pkgs.add(it.packageName) }
    }

    // ب) أنشطة المشغّل (تُرى دائمًا)
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val infos = if (android.os.Build.VERSION.SDK_INT >= 33)
        pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
    else @Suppress("DEPRECATION") pm.queryIntentActivities(intent, 0)
    infos.forEach { pkgs.add(it.activityInfo.packageName) }

    return pkgs.mapNotNull { pkg ->
        runCatching {
            val appInfo = pm.getApplicationInfo(pkg, 0)
            LaunchableApp(
                pkg = pkg,
                label = pm.getApplicationLabel(appInfo).toString(),
                icon = runCatching { pm.getApplicationIcon(appInfo) }.getOrNull(),
                launchable = pm.getLaunchIntentForPackage(pkg) != null
            )
        }.getOrNull()
    }
        .filter { it.pkg != c.packageName }   // رفيق محدد كأساسي تلقائيًا
        .sortedWith(compareByDescending<LaunchableApp> { it.launchable }.thenBy { it.label })
}
