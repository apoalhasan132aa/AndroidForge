package com.rafiq6.study

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeParseException

// ---------- نموذج ملف الجدول المستقل rafiq_schedule_v1 ----------

data class ScheduleMeta(
    val name: String = "جدول بدون اسم",
    val studentAlias: String? = null,
    val stage: String? = null,
    val country: String? = null,
    val timeZone: String = "Asia/Baghdad"
)

data class ScheduleTaskIn(
    val id: String,
    val subject: String,
    val type: String,
    val title: String,
    val lectureNo: Int? = null,
    val durationMin: Int,
    val startMin: Int? = null,
    val endMin: Int? = null,
    val flexible: Boolean = false,
    val fixed: Boolean = false,
    val notify: Boolean = true,
    val note: String? = null
)

data class ScheduleDayIn(
    val date: LocalDate,
    val weekday: String?,
    val tasks: List<ScheduleTaskIn>
)

data class ScheduleFile(
    val meta: ScheduleMeta,
    val startDate: LocalDate?,
    val endDate: LocalDate?,
    val days: List<ScheduleDayIn>
) {
    fun taskCount(): Int = days.sumOf { it.tasks.size }
}

data class ValidationIssue(val path: String, val message: String)

data class ScheduleParseResult(
    val file: ScheduleFile?,
    val errors: List<ValidationIssue>,
    val warnings: List<ValidationIssue>
) {
    val ok: Boolean get() = file != null && errors.isEmpty()
    fun errorText(): String = errors.joinToString("\n") { "• ${it.path}: ${it.message}" }
    fun warningText(): String = warnings.joinToString("\n") { "• ${it.path}: ${it.message}" }
}

object ScheduleParser {
    private val arabicWeekdays = listOf("الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد")

    fun weekday(d: LocalDate): String = arabicWeekdays[d.dayOfWeek.value - 1]

    fun parse(text: String): ScheduleParseResult {
        val errors = mutableListOf<ValidationIssue>()
        val warnings = mutableListOf<ValidationIssue>()
        val root: JSONObject = try { JSONObject(text) } catch (e: Exception) {
            return ScheduleParseResult(null, listOf(ValidationIssue("json", "الملف ليس JSON صالحًا: ${e.message ?: "خطأ في القراءة"}")), emptyList())
        }

        return when {
            root.optString("format") == "rafiq_schedule" -> parseV1(root, errors, warnings)
            root.has("version") && root.optInt("version") == 2 -> parseLegacy(root, errors, warnings)
            else -> {
                errors += ValidationIssue("format", "صيغة غير مدعومة. المطلوب format=rafiq_schedule وformatVersion=1، أو version=2 للملفات القديمة.")
                ScheduleParseResult(null, errors, warnings)
            }
        }
    }

    private fun parseV1(root: JSONObject, errors: MutableList<ValidationIssue>, warnings: MutableList<ValidationIssue>): ScheduleParseResult {
        if (root.optInt("formatVersion") != 1) {
            errors += ValidationIssue("formatVersion", "إصدار الصيغة غير مدعوم؛ المتوفر حاليًا: 1.")
            return ScheduleParseResult(null, errors, warnings)
        }
        val metaObj = root.optJSONObject("metadata") ?: JSONObject()
        val meta = ScheduleMeta(
            name = metaObj.optString("scheduleName").ifBlank { "جدول مستورد" },
            studentAlias = metaObj.optNullableString("studentAlias"),
            stage = metaObj.optNullableString("stage"),
            country = metaObj.optNullableString("country"),
            timeZone = metaObj.optString("timeZone", "Asia/Baghdad").ifBlank { "Asia/Baghdad" }
        )
        val start = root.optNullableDate("startDate", "startDate", errors)
        val end = root.optNullableDate("endDate", "endDate", errors)
        if (start != null && end != null && end < start)
            errors += ValidationIssue("endDate", "تاريخ النهاية يسبق تاريخ البداية.")

        val daysArr = root.optJSONArray("days")
        if (daysArr == null) {
            errors += ValidationIssue("days", "الحقول الأساسية ناقصة: days.")
            return ScheduleParseResult(null, errors, warnings)
        }
        val days = mutableListOf<ScheduleDayIn>()
        val seen = mutableSetOf<String>()
        for (i in 0 until daysArr.length()) {
            val dObj = daysArr.optJSONObject(i) ?: continue
            val path = "days[$i]"
            val date = dObj.optDate("date", "$path.date", errors) ?: continue
            if (start != null && date < start) errors += ValidationIssue("$path.date", "التاريخ قبل بداية الجدول.")
            if (end != null && date > end) errors += ValidationIssue("$path.date", "التاريخ بعد نهاية الجدول.")
            val expectedWeekday = weekday(date)
            val importedWeekday = dObj.optNullableString("weekday")
            if (!importedWeekday.isNullOrBlank() && importedWeekday != expectedWeekday)
                warnings += ValidationIssue("$path.weekday", "اسم اليوم المكتوب ($importedWeekday) لا يطابق التاريخ ($expectedWeekday).")

            val tasks = mutableListOf<ScheduleTaskIn>()
            val taskArr = dObj.optJSONArray("tasks") ?: JSONArray()
            for (j in 0 until taskArr.length()) {
                val tObj = taskArr.optJSONObject(j) ?: continue
                val t = parseV1Task(tObj, "$path.tasks[$j]", errors) ?: continue
                if (!seen.add(t.id)) errors += ValidationIssue("$path.tasks[$j].id", "المعرّف ${t.id} مكرر داخل الجدول.")
                tasks += t
            }
            val constraintArr = dObj.optJSONArray("constraints") ?: JSONArray()
            for (j in 0 until constraintArr.length()) {
                val cObj = constraintArr.optJSONObject(j) ?: continue
                val c = parseV1Task(cObj, "$path.constraints[$j]", errors)?.let {
                    it.copy(
                        id = "constraint-" + it.id,
                        type = TaskTypes.COMMITMENT,
                        subject = "التزام",
                        flexible = false,
                        fixed = true,
                        notify = false
                    )
                } ?: continue
                if (!seen.add(c.id)) errors += ValidationIssue("$path.constraints[$j].id", "معرّف القيد ${c.id} مكرر.")
                tasks += c
            }
            validateDay(date, tasks, path, errors, warnings)
            days += ScheduleDayIn(date, importedWeekday ?: expectedWeekday, tasks)
        }
        if (days.isEmpty()) errors += ValidationIssue("days", "لا توجد أيام صالحة داخل الجدول.")
        return finish(ScheduleFile(meta, start, end, days), errors, warnings)
    }

    private fun parseV1Task(o: JSONObject, path: String, errors: MutableList<ValidationIssue>): ScheduleTaskIn? {
        val id = o.optString("id").trim()
        val subject = o.optString("subject").trim()
        val type = normalizeType(o.optString("type").trim())
        val title = o.optString("title").trim()
        if (id.isBlank()) errors += ValidationIssue("$path.id", "المعرّف مطلوب.")
        if (subject.isBlank()) errors += ValidationIssue("$path.subject", "اسم المادة مطلوب.")
        if (title.isBlank()) errors += ValidationIssue("$path.title", "عنوان المهمة مطلوب.")
        val duration = o.optInt("durationMin", -1)
        if (duration <= 0) errors += ValidationIssue("$path.durationMin", "المدة يجب أن تكون أكبر من صفر.")
        val start = o.optNullableTime("start", "$path.start", errors)
        val end = o.optNullableTime("end", "$path.end", errors)
        if ((start == null) != (end == null)) errors += ValidationIssue(path, "يجب توفير وقت البداية والنهاية معًا أو تركهما غير محددين.")
        return ScheduleTaskIn(
            id = id, subject = subject, type = type, title = title,
            lectureNo = if (o.isNull("lectureNo")) null else o.optInt("lectureNo"),
            durationMin = duration, startMin = start, endMin = end,
            flexible = o.optBoolean("flexible", false),
            fixed = o.optBoolean("fixed", false),
            notify = o.optBoolean("notify", true),
            note = o.optNullableString("note")
        )
    }

    private fun parseLegacy(root: JSONObject, errors: MutableList<ValidationIssue>, warnings: MutableList<ValidationIssue>): ScheduleParseResult {
        val daysArr = root.optJSONArray("days")
        if (daysArr == null) {
            errors += ValidationIssue("days", "الملف القديم لا يحتوي days.")
            return ScheduleParseResult(null, errors, warnings)
        }
        val days = mutableListOf<ScheduleDayIn>()
        val seen = mutableSetOf<String>()
        for (i in 0 until daysArr.length()) {
            val dObj = daysArr.optJSONObject(i) ?: continue
            val path = "days[$i]"
            val date = dObj.optDate("date", "$path.date", errors) ?: continue
            val wd = dObj.optString("wd", weekday(date))
            val arr = dObj.optJSONArray("tasks") ?: JSONArray()
            val tasks = mutableListOf<ScheduleTaskIn>()
            for (j in 0 until arr.length()) {
                val o = arr.optJSONObject(j) ?: continue
                val id = o.optString("id").trim()
                val subject = o.optString("s").trim()
                val title = o.optString("t").trim()
                if (id.isBlank() || !seen.add(id)) errors += ValidationIssue("$path.tasks[$j].id", "معرّف مفقود أو مكرر: $id")
                if (subject.isBlank()) errors += ValidationIssue("$path.tasks[$j].s", "اسم المادة مفقود.")
                if (title.isBlank()) errors += ValidationIssue("$path.tasks[$j].t", "عنوان المهمة مفقود.")
                val dur = o.optInt("dur", -1)
                if (dur <= 0) errors += ValidationIssue("$path.tasks[$j].dur", "المدة غير صالحة.")
                val st = o.optNullableTime("st", "$path.tasks[$j].st", errors)
                val en = o.optNullableTime("en", "$path.tasks[$j].en", errors)
                if ((st == null) != (en == null)) errors += ValidationIssue("$path.tasks[$j]", "وقت البداية والنهاية يجب أن يكونا معًا أو غير محددين.")
                tasks += ScheduleTaskIn(
                    id = id, subject = subject, type = normalizeType(o.optString("ty")),
                    title = title,
                    lectureNo = if (o.isNull("lec")) null else o.optInt("lec"),
                    durationMin = dur, startMin = st, endMin = en,
                    flexible = o.optBoolean("flex", false), fixed = false,
                    notify = true, note = o.optNullableString("note")
                )
            }
            validateDay(date, tasks, path, errors, warnings)
            days += ScheduleDayIn(date, wd, tasks)
        }
        val start = days.firstOrNull()?.date; val end = days.lastOrNull()?.date
        val meta = ScheduleMeta(name = root.optString("source").ifBlank { "جدول رفيق الحالي" })
        return finish(ScheduleFile(meta, start, end, days), errors, warnings)
    }

    private fun validateDay(date: LocalDate, tasks: List<ScheduleTaskIn>, path: String, errors: MutableList<ValidationIssue>, warnings: MutableList<ValidationIssue>) {
        for ((idx, t) in tasks.withIndex()) {
            val p = "$path.tasks[$idx]"
            if (t.startMin != null && t.endMin != null) {
                if (t.endMin <= t.startMin) errors += ValidationIssue(p, "وقت النهاية يجب أن يكون بعد البداية.")
                if (t.durationMin != t.endMin!! - t.startMin!!)
                    warnings += ValidationIssue(p, "المدة المكتوبة لا تساوي الفارق بين البداية والنهاية؛ سيتم استخدام المدة المكتوبة.")
                if (TaskTypes.isAssessment(t.type) && t.startMin!! < 19 * 60)
                    errors += ValidationIssue(p, "الامتحان/الاختبار يبدأ قبل 7:00 مساءً.")
            }
        }
        val timed = tasks.filter { it.startMin != null && it.endMin != null }.sortedBy { it.startMin }
        for (a in 0 until timed.size) for (b in a + 1 until timed.size) {
            val x = timed[a]; val y = timed[b]
            if (x.startMin!! < y.endMin!! && y.startMin!! < x.endMin!!)
                errors += ValidationIssue(path, "تداخل بين «${x.title}» و«${y.title}» يوم ${date}.")
        }
    }

    private fun finish(file: ScheduleFile, errors: List<ValidationIssue>, warnings: List<ValidationIssue>): ScheduleParseResult =
        if (errors.isEmpty()) ScheduleParseResult(file, emptyList(), warnings) else ScheduleParseResult(null, errors, warnings)

    fun toEntities(scheduleId: String, file: ScheduleFile): List<TaskEntity> =
        file.days.flatMap { day ->
            day.tasks.map { t ->
                val qualified = "$scheduleId::${t.id}"
                TaskEntity(
                    id = qualified, scheduleId = scheduleId, sourceId = t.id,
                    date = day.date.toString(), dayName = day.weekday ?: weekday(day.date),
                    subject = t.subject, type = t.type, title = t.title, lectureNo = t.lectureNo,
                    durationMin = t.durationMin, startMin = t.startMin, endMin = t.endMin,
                    flexible = t.flexible, fixed = t.fixed, notify = t.notify, note = t.note,
                    originalDate = day.date.toString(), originalStartMin = t.startMin, originalEndMin = t.endMin
                )
            }
        }

    fun toJson(schedule: ScheduleEntity, tasks: List<TaskEntity>): JSONObject {
        val byDate = tasks.groupBy { it.date }.toSortedMap()
        val days = JSONArray()
        byDate.forEach { (date, list) ->
            val d = LocalDate.parse(date)
            val arr = JSONArray()
            list.sortedBy { it.startMin ?: 9999 }.forEach { t ->
                arr.put(JSONObject().apply {
                    put("id", t.sourceId); put("subject", t.subject); put("type", t.type)
                    put("title", t.title); put("durationMin", t.durationMin)
                    t.lectureNo?.let { put("lectureNo", it) }
                    t.startMin?.let { put("start", Subjects.fromMin(it)) }
                    t.endMin?.let { put("end", Subjects.fromMin(it)) }
                    put("flexible", t.flexible); put("fixed", t.fixed); put("notify", t.notify)
                    t.note?.let { put("note", it) }
                })
            }
            days.put(JSONObject().apply {
                put("date", date); put("weekday", weekday(d)); put("tasks", arr)
            })
        }
        val meta = JSONObject().apply {
            put("scheduleName", schedule.name)
            schedule.studentAlias?.let { put("studentAlias", it) }
            schedule.stage?.let { put("stage", it) }
            schedule.country?.let { put("country", it) }
            put("timeZone", schedule.timeZone)
        }
        return JSONObject().apply {
            put("format", "rafiq_schedule"); put("formatVersion", 1)
            put("metadata", meta)
            schedule.startDate?.let { put("startDate", it) }
            schedule.endDate?.let { put("endDate", it) }
            put("days", days)
        }
    }

    private fun normalizeType(raw: String): String = when (raw.trim()) {
        "newLecture", "محاضرة جديدة" -> TaskTypes.NEW
        "oldLecture", "تراكم قديم", "محاضرة قديمة" -> TaskTypes.OLD
        "dailyExam", "امتحان يومي" -> TaskTypes.DAILY_EXAM
        "cumulativeExam", "امتحان تراكمي" -> TaskTypes.CUMULATIVE_EXAM
        "quiz", "اختبار" -> TaskTypes.QUIZ
        "homework", "واجب" -> TaskTypes.HOMEWORK
        "review", "مراجعة" -> TaskTypes.REVIEW
        "personalActivity", "نشاط شخصي" -> TaskTypes.PERSONAL
        "commitment", "التزام ثابت" -> TaskTypes.COMMITMENT
        "compensation", "تعويض" -> TaskTypes.COMPENSATION
        "امتحان" -> TaskTypes.EXAM
        else -> raw.ifBlank { "مهمة" }
    }

    private fun JSONObject.optNullableString(key: String): String? =
        if (isNull(key)) null else optString(key, "").ifBlank { null }

    private fun JSONObject.optNullableDate(key: String, path: String, errors: MutableList<ValidationIssue>): LocalDate? =
        if (!has(key) || isNull(key)) null else optDate(key, path, errors)

    private fun JSONObject.optDate(key: String, path: String, errors: MutableList<ValidationIssue>): LocalDate? {
        val value = optString(key).trim()
        return try { LocalDate.parse(value) } catch (e: DateTimeParseException) {
            errors += ValidationIssue(path, "التاريخ يجب أن يكون بصيغة YYYY-MM-DD.")
            null
        }
    }

    private fun JSONObject.optNullableTime(key: String, path: String, errors: MutableList<ValidationIssue>): Int? =
        if (!has(key) || isNull(key)) null else optTime(key, path, errors)

    private fun JSONObject.optTime(key: String, path: String, errors: MutableList<ValidationIssue>): Int? {
        val value = optString(key).trim()
        val m = Regex("""^([01]?\d|2[0-3]):([0-5]\d)$""").matchEntire(value)
        if (m == null) {
            errors += ValidationIssue(path, "الوقت يجب أن يكون بصيغة HH:MM بالنظام 24 ساعة.")
            return null
        }
        return m.groupValues[1].toInt() * 60 + m.groupValues[2].toInt()
    }
}

// ---------- قاعدة تتابع الامتحانات ----------

object ExamSequencer {
    /** يعيد أوقات بداية الامتحانات بالتتابع من 7:00 مساءً وفق ترتيب المصدر. */
    fun sequentialStarts(durationsMin: List<Int>): List<Int> {
        var cursor = 19 * 60
        return durationsMin.map { d ->
            require(d > 0) { "مدة الامتحان يجب أن تكون أكبر من صفر" }
            val start = cursor; cursor += d; start
        }
    }

    fun hasOverlap(starts: List<Int>, durations: List<Int>): Boolean {
        val ends = starts.zip(durations) { s, d -> s + d }
        for (i in starts.indices) for (j in i + 1 until starts.size)
            if (starts[i] < ends[j] && starts[j] < ends[i]) return true
        return false
    }
}

// ---------- محرك إعادة الجدولة عند الطلعة ----------

data class ReschedulePlan(
    val outingDate: LocalDate,
    val moved: List<UiTask>,
    val protectedTasks: List<UiTask>,
    val unplaced: List<UiTask>,
    val warnings: List<String>
) {
    val hasChanges: Boolean get() = moved.isNotEmpty()
    val hasUnplaced: Boolean get() = unplaced.isNotEmpty()
}

object RescheduleEngine {
    fun plan(allTasks: List<UiTask>, outing: LocalDate, settings: Settings): ReschedulePlan {
        val dayTasks = allTasks.filter { it.date == outing.toString() }.sortedBy { it.startMin ?: 9999 }
        val candidates = dayTasks.filter { !it.done && !it.fixed && (it.flexible || it.startMin == null) }
        val protectedTasks = dayTasks.filter { it !in candidates }
        val warnings = mutableListOf<String>()
        if (dayTasks.isEmpty()) warnings += "لا توجد مهام في يوم الطلعة."
        if (candidates.isEmpty() && dayTasks.isNotEmpty()) warnings += "لا توجد مهام مرنة غير منجزة لإعادة توزيعها."

        val moved = mutableListOf<UiTask>()
        val unplaced = mutableListOf<UiTask>()
        val placements = mutableMapOf<String, TaskEntity>()

        for (task in candidates) {
            val placed = placeTask(task.task, allTasks, placements, outing, settings)
            if (placed != null) {
                placements[task.id] = placed
                moved += task.copy(task = placed)
            } else unplaced += task
        }
        if (unplaced.isNotEmpty()) warnings += "تعذر إيجاد وقت مناسب لـ ${unplaced.size} مهام ضمن حد التأجيل."
        return ReschedulePlan(outing, moved, protectedTasks, unplaced, warnings.distinct())
    }

    private fun placeTask(
        candidate: TaskEntity,
        allTasks: List<UiTask>,
        placements: Map<String, TaskEntity>,
        outing: LocalDate,
        settings: Settings
    ): TaskEntity? {
        for (offset in 1..settings.maxPostponeDays.coerceAtLeast(1)) {
            val target = outing.plusDays(offset.toLong())
            if (target < LocalDate.parse(candidate.date)) continue
            val slot = findSlot(candidate, allTasks, placements, target, settings) ?: continue
            return candidate.copy(
                date = target.toString(),
                dayName = ScheduleParser.weekday(target),
                startMin = slot,
                endMin = slot + candidate.durationMin,
                originalDate = candidate.originalDate ?: candidate.date,
                originalStartMin = candidate.originalStartMin ?: candidate.startMin,
                originalEndMin = candidate.originalEndMin ?: candidate.endMin,
                rescheduleReason = "إعادة جدولة بسبب طلعة يوم ${outing}"
            )
        }
        return null
    }

    private fun findSlot(
        candidate: TaskEntity,
        allTasks: List<UiTask>,
        placements: Map<String, TaskEntity>,
        target: LocalDate,
        settings: Settings
    ): Int? {
        val date = target.toString()
        val busyTasks = allTasks.map { it.task }.filter {
            it.date == date && it.id != candidate.id && !placements.containsKey(it.id)
        } + placements.values.filter { it.date == date }
        val busy = busyTasks.mapNotNull { t ->
            val s = t.startMin ?: return@mapNotNull null
            val e = t.endMin ?: s + t.durationMin
            s..e
        }
        val movedDurations = busyTasks.filter { it.id in placements.keys }.sumOf { it.durationMin }
        val baseDurations = busyTasks.filter { it.id !in placements.keys }.sumOf { it.durationMin }
        val dailyLoad = baseDurations + movedDurations + candidate.durationMin
        if (dailyLoad > settings.dailyGoalMin) return null

        val windows = mutableListOf<Pair<Int, Int>>()
        if (settings.schoolStart > settings.wakeMin + candidate.durationMin)
            windows += settings.wakeMin to settings.schoolStart
        if (settings.sleepMin > settings.schoolEnd + candidate.durationMin)
            windows += settings.schoolEnd to settings.sleepMin

        for ((from, to) in windows) {
            var cursor = from.coerceAtLeast(if (TaskTypes.isAssessment(candidate.type)) 19 * 60 else from)
            val limit = to.coerceAtMost(settings.sleepMin)
            while (cursor + candidate.durationMin <= limit) {
                val clash = busy.any { cursor < it.last + settings.breakMin && cursor + candidate.durationMin > it.first }
                if (!clash) return cursor
                cursor += 15
            }
        }
        return null
    }
}

// ---------- إحصاءات نقية قابلة للاختبار ----------

data class StudyStats(
    val total: Int,
    val done: Int,
    val actualMin: Int,
    val perSubject: Map<String, Int>,
    val streak: Int,
    val bestDay: String?
)

object StatsCalculator {
    fun calculate(tasks: List<UiTask>): StudyStats {
        val done = tasks.filter { it.done }
        val byDay = tasks.groupBy { it.date }
        val best = byDay.maxByOrNull { e -> e.value.count { it.done } }
        var streak = 0
        val today = Subjects.now().toLocalDate().toString()
        for ((d, list) in byDay.toSortedMap().toList().asReversed()) {
            val pct = if (list.isEmpty()) 0 else 100 * list.count { it.done } / list.size
            if (pct >= 70) streak++ else if (d <= today) break
        }
        return StudyStats(
            total = tasks.size,
            done = done.size,
            actualMin = done.sumOf { it.actualMin ?: 0 },
            perSubject = done.groupBy { it.subject }.mapValues { it.value.size },
            streak = streak,
            bestDay = best?.key
        )
    }
}
