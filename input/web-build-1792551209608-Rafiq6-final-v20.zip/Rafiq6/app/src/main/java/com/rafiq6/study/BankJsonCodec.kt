package com.rafiq6.study

import org.json.JSONObject

object BankJsonCodec {
    fun document(d: PdfDocumentEntity) = JSONObject().apply {
        put("id", d.id); put("uri", d.uri); put("displayName", d.displayName)
        put("pageCount", d.pageCount); put("textAvailable", d.textAvailable)
        d.importWarning?.let { put("importWarning", it) } ?: put("importWarning", JSONObject.NULL)
        put("importedAt", d.importedAt)
    }
    fun document(o: JSONObject) = PdfDocumentEntity(
        id = o.getString("id"), uri = o.getString("uri"), displayName = o.getString("displayName"),
        pageCount = o.getInt("pageCount"), textAvailable = o.optBoolean("textAvailable"),
        importWarning = if (o.isNull("importWarning")) null else o.optString("importWarning"),
        importedAt = o.optLong("importedAt", System.currentTimeMillis())
    )

    fun page(p: PdfPageTextEntity) = JSONObject().apply {
        put("documentId", p.documentId); put("pageNumber", p.pageNumber); put("text", p.text)
    }
    fun page(o: JSONObject) = PdfPageTextEntity(o.getString("documentId"), o.getInt("pageNumber"), o.getString("text"))

    fun question(q: QuestionEntity) = JSONObject().apply {
        put("id", q.id); put("documentId", q.documentId); put("documentName", q.documentName)
        put("pageNumber", q.pageNumber); put("subject", q.subject); put("topic", q.topic)
        put("question", q.question)
        q.correctAnswer?.let { put("correctAnswer", it) } ?: put("correctAnswer", JSONObject.NULL)
        put("errorCount", q.errorCount); put("reviewStage", q.reviewStage)
        q.nextReviewAt?.let { put("nextReviewAt", it) } ?: put("nextReviewAt", JSONObject.NULL)
        q.lastResult?.let { put("lastResult", it) } ?: put("lastResult", JSONObject.NULL)
        put("createdAt", q.createdAt); put("updatedAt", q.updatedAt)
    }
    fun question(o: JSONObject) = QuestionEntity(
        id = o.getString("id"), documentId = o.getString("documentId"), documentName = o.getString("documentName"),
        pageNumber = o.getInt("pageNumber"), subject = o.getString("subject"), topic = o.getString("topic"),
        question = o.getString("question"),
        correctAnswer = if (o.isNull("correctAnswer")) null else o.optString("correctAnswer"),
        errorCount = o.optInt("errorCount"), reviewStage = o.optInt("reviewStage"),
        nextReviewAt = if (o.isNull("nextReviewAt")) null else o.optString("nextReviewAt"),
        lastResult = if (o.isNull("lastResult")) null else o.optString("lastResult"),
        createdAt = o.optLong("createdAt", System.currentTimeMillis()), updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
    )

    fun attempt(a: QuizAttemptEntity) = JSONObject().apply {
        put("id", a.id); put("subject", a.subject ?: JSONObject.NULL); put("topic", a.topic ?: JSONObject.NULL)
        put("total", a.total); put("answered", a.answered); put("correct", a.correct); put("status", a.status)
        put("startedAt", a.startedAt); put("finishedAt", a.finishedAt ?: JSONObject.NULL)
    }
    fun attempt(o: JSONObject) = QuizAttemptEntity(
        id = o.getString("id"),
        subject = if (o.isNull("subject")) null else o.optString("subject"),
        topic = if (o.isNull("topic")) null else o.optString("topic"),
        total = o.getInt("total"), answered = o.optInt("answered"), correct = o.optInt("correct"),
        status = o.optString("status", QuizStatus.DONE), startedAt = o.optLong("startedAt", System.currentTimeMillis()),
        finishedAt = if (o.isNull("finishedAt")) null else o.optLong("finishedAt")
    )

    fun answer(a: AttemptAnswerEntity) = JSONObject().apply {
        put("id", a.id); put("attemptId", a.attemptId); put("questionId", a.questionId)
        put("userAnswer", a.userAnswer); put("isCorrect", a.isCorrect); put("answeredAt", a.answeredAt)
        put("previousStage", a.previousStage); put("nextStage", a.nextStage)
        a.nextReviewAt?.let { put("nextReviewAt", it) } ?: put("nextReviewAt", JSONObject.NULL)
    }
    fun answer(o: JSONObject) = AttemptAnswerEntity(
        id = o.getString("id"), attemptId = o.getString("attemptId"), questionId = o.getString("questionId"),
        userAnswer = o.getString("userAnswer"), isCorrect = o.optBoolean("isCorrect"),
        answeredAt = o.optLong("answeredAt", System.currentTimeMillis()), previousStage = o.optInt("previousStage"),
        nextStage = o.optInt("nextStage"), nextReviewAt = if (o.isNull("nextReviewAt")) null else o.optString("nextReviewAt")
    )
}
