package com.rafiq6.study

import org.json.JSONObject

object JsonCodec {
    fun taskToJson(t: TaskEntity): JSONObject = JSONObject().apply {
        put("id", t.id); put("scheduleId", t.scheduleId); put("sourceId", t.sourceId)
        put("date", t.date); put("dayName", t.dayName); put("subject", t.subject)
        put("type", t.type); put("title", t.title)
        t.lectureNo?.let { put("lectureNo", it) } ?: put("lectureNo", JSONObject.NULL)
        put("durationMin", t.durationMin)
        t.startMin?.let { put("startMin", it) } ?: put("startMin", JSONObject.NULL)
        t.endMin?.let { put("endMin", it) } ?: put("endMin", JSONObject.NULL)
        put("flexible", t.flexible); put("fixed", t.fixed); put("notify", t.notify)
        t.note?.let { put("note", it) } ?: put("note", JSONObject.NULL)
        t.originalDate?.let { put("originalDate", it) } ?: put("originalDate", JSONObject.NULL)
        t.originalStartMin?.let { put("originalStartMin", it) } ?: put("originalStartMin", JSONObject.NULL)
        t.originalEndMin?.let { put("originalEndMin", it) } ?: put("originalEndMin", JSONObject.NULL)
        t.rescheduleReason?.let { put("rescheduleReason", it) } ?: put("rescheduleReason", JSONObject.NULL)
        put("remindBeforeMin", t.remindBeforeMin)
    }

    fun taskFromJson(o: JSONObject): TaskEntity = TaskEntity(
        id = o.getString("id"), scheduleId = o.getString("scheduleId"), sourceId = o.getString("sourceId"),
        date = o.getString("date"), dayName = o.getString("dayName"), subject = o.getString("subject"),
        type = o.getString("type"), title = o.getString("title"),
        lectureNo = if (o.isNull("lectureNo")) null else o.getInt("lectureNo"),
        durationMin = o.getInt("durationMin"),
        startMin = if (o.isNull("startMin")) null else o.getInt("startMin"),
        endMin = if (o.isNull("endMin")) null else o.getInt("endMin"),
        flexible = o.optBoolean("flexible"), fixed = o.optBoolean("fixed"), notify = o.optBoolean("notify", true),
        note = if (o.isNull("note")) null else o.optString("note"),
        originalDate = if (o.isNull("originalDate")) null else o.optString("originalDate"),
        originalStartMin = if (o.isNull("originalStartMin")) null else o.optInt("originalStartMin"),
        originalEndMin = if (o.isNull("originalEndMin")) null else o.optInt("originalEndMin"),
        rescheduleReason = if (o.isNull("rescheduleReason")) null else o.optString("rescheduleReason"),
        remindBeforeMin = o.optInt("remindBeforeMin", 15)
    )

    fun progressToJson(p: ProgressEntity): JSONObject = JSONObject().apply {
        put("taskId", p.taskId); put("done", p.done)
        p.doneAt?.let { put("doneAt", it) } ?: put("doneAt", JSONObject.NULL)
        p.actualMin?.let { put("actualMin", it) } ?: put("actualMin", JSONObject.NULL)
    }

    fun progressFromJson(o: JSONObject): ProgressEntity = ProgressEntity(
        taskId = o.getString("taskId"), done = o.optBoolean("done"),
        doneAt = if (o.isNull("doneAt")) null else o.optLong("doneAt"),
        actualMin = if (o.isNull("actualMin")) null else o.optInt("actualMin")
    )

    fun scheduleToJson(s: ScheduleEntity): JSONObject = JSONObject().apply {
        put("scheduleId", s.scheduleId); put("name", s.name)
        s.studentAlias?.let { put("studentAlias", it) } ?: put("studentAlias", JSONObject.NULL)
        s.stage?.let { put("stage", it) } ?: put("stage", JSONObject.NULL)
        s.country?.let { put("country", it) } ?: put("country", JSONObject.NULL)
        put("timeZone", s.timeZone)
        s.startDate?.let { put("startDate", it) } ?: put("startDate", JSONObject.NULL)
        s.endDate?.let { put("endDate", it) } ?: put("endDate", JSONObject.NULL)
        put("importedAt", s.importedAt); put("active", s.active)
    }

    fun scheduleFromJson(o: JSONObject): ScheduleEntity = ScheduleEntity(
        scheduleId = o.getString("scheduleId"), name = o.getString("name"),
        studentAlias = if (o.isNull("studentAlias")) null else o.optString("studentAlias"),
        stage = if (o.isNull("stage")) null else o.optString("stage"),
        country = if (o.isNull("country")) null else o.optString("country"),
        timeZone = o.optString("timeZone", "Asia/Baghdad"),
        startDate = if (o.isNull("startDate")) null else o.optString("startDate"),
        endDate = if (o.isNull("endDate")) null else o.optString("endDate"),
        importedAt = o.optLong("importedAt", System.currentTimeMillis()),
        active = o.optBoolean("active")
    )
}
