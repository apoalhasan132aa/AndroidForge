package com.rafiq6.study

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

/**
 * اختبارات الخوارزمية المتوازنة (الخطوة 3 = newLectureDays، الحد اليومي صارم، توزيع عادل).
 */
class BalancedScheduleTest {

    private fun dayName(date: LocalDate) = WizardConst.dayOfWeekName(date.dayOfWeek)

    private fun tasksOf(p: GeneratedPlan) = p.file!!.days.flatMap { day -> day.tasks.map { day.date to it } }

    // 1) محاضرات جديدة في أيام الخطوة 3 فقط
    @Test fun t01_newLecturesOnlyOnChosenDays() {
        val d = WizardDraft(
            subjects = listOf("الفيزياء"), backlogs = mapOf("الفيزياء" to 0),
            startDate = "2026-01-03", endDate = "2026-01-16", dailyStudyMin = 300,
            oldOnly = false, lectureDur = 75,
            newLectureDays = mapOf("الفيزياء" to setOf("الأحد", "الثلاثاء", "الخميس")))
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString() + p.missingInputs, p.ok)
        val news = tasksOf(p).filter { it.second.type == TaskTypes.NEW }
        assertEquals(6, news.size) // يومان × 3 أيام نشر
        val allowed = setOf("الأحد", "الثلاثاء", "الخميس")
        assertTrue(news.all { dayName(it.first) in allowed })
        assertTrue(WizardVerify.compliance(p.file!!, d).isEmpty())
    }

    // 2) يوم فيه محاضرات جديدة وتراكمات معًا ضمن الحد
    @Test fun t02_mixedDayRespectsDailyLimit() {
        val subs = listOf("الفيزياء", "الكيمياء", "الأحياء")
        val d = WizardDraft(
            subjects = subs, backlogs = subs.associateWith { 0 },
            startDate = "2026-01-03", endDate = "2026-01-16", dailyStudyMin = 420,
            oldOnly = false, lectureDur = 75,
            newLectureDays = subs.associateWith { setOf("الأحد") })
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString(), p.ok)
        val sunday = p.file!!.days.filter { dayName(it.date) == "الأحد" }
        assertEquals(2, sunday.size) // أحدان في الفترة (4 و11 يناير)
        // 3 مواد × 75 = 225 محجوزة يوم الأحد
        assertTrue(sunday.all { day -> day.tasks.sumOf { it.durationMin } == 225 })
        assertTrue(p.file!!.days.all { day -> day.tasks.sumOf { it.durationMin } <= 420 })
    }

    // 3) لا تُضاف محاضرة تراكم جزئية إذا لم تتسع كاملة
    @Test fun t03_noPartialBacklogLecture() {
        val d = WizardDraft(
            subjects = listOf("الفيزياء"), backlogs = mapOf("الفيزياء" to 10),
            firstOldNo = mapOf("الفيزياء" to 5),
            weekPlan = mapOf("الأحد" to setOf("الفيزياء")),
            startDate = "2026-01-03", endDate = "2026-01-16", dailyStudyMin = 200,
            oldOnly = false, lectureDur = 75, autoExtend = false,
            newLectureDays = mapOf("الفيزياء" to setOf("الأحد")))
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString() + p.missingInputs, p.ok)
        assertTrue(tasksOf(p).all { it.second.durationMin == 75 }) // لا مدد مقطوعة
        // كل يوم: إما 75 (جديد فقط) أو 150 (جديد + تراكم) — المتبقي 50 أقل من 75 فلا يُملأ
        assertTrue(p.file!!.days.all { day ->
            val t = day.tasks.sumOf { it.durationMin }; t == 75 || t == 150 })
        assertEquals(2, p.summary!!.oldCount)     // أحدان × تراكم واحد
        assertEquals(8, p.summary!!.leftoverOld)  // 10 − 2
    }

    // 4) توازن تراكمات مادتين عبر أيامهما
    @Test fun t04_twoSubjectsBalancedAcrossDays() {
        val d = WizardDraft(
            subjects = listOf("الفيزياء", "الكيمياء"),
            backlogs = mapOf("الفيزياء" to 6, "الكيمياء" to 6),
            firstOldNo = mapOf("الفيزياء" to 1, "الكيمياء" to 1),
            weekPlan = mapOf("الأحد" to setOf("الفيزياء"), "الأربعاء" to setOf("الفيزياء"),
                "الاثنين" to setOf("الكيمياء"), "الثلاثاء" to setOf("الكيمياء")),
            startDate = "2026-01-03", endDate = "2026-01-16", dailyStudyMin = 480,
            oldOnly = false, lectureDur = 75, autoExtend = false)
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString(), p.ok)
        val byDay = tasksOf(p).filter { it.second.type == TaskTypes.OLD }
            .groupingBy { dayName(it.first) }.eachCount()
        assertEquals(4, byDay.size)
        assertTrue(byDay.values.all { it == 3 })      // 3 لكل يوم أسبوعي — توازن تام
        // على مستوى التواريخ: فرق الحمولة ≤ محاضرة واحدة
        val byDate = tasksOf(p).filter { it.second.type == TaskTypes.OLD }
            .groupingBy { it.first }.eachCount()
        assertTrue(byDate.values.maxOrNull()!! - byDate.values.minOrNull()!! <= 1)
    }

    // 5) مادة بلا تراكمات لا تولّد لها مهام قديمة
    @Test fun t05_zeroBacklogSubjectHasNoOldTasks() {
        val d = WizardDraft(
            subjects = listOf("الفيزياء", "الكيمياء"),
            backlogs = mapOf("الفيزياء" to 0, "الكيمياء" to 3),
            firstOldNo = mapOf("الكيمياء" to 1),
            startDate = "2026-01-03", endDate = "2026-01-16", dailyStudyMin = 240,
            oldOnly = true, lectureDur = 45, autoExtend = false)
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString(), p.ok)
        assertTrue(tasksOf(p).none { it.second.type == TaskTypes.OLD && it.second.subject == "الفيزياء" })
        assertEquals(3, p.summary!!.oldCount)
    }

    // 6) تراكمات بلا أيام مسموحة: يُبلَّغ ولا يُخترع توزيع
    @Test fun t06_backlogWithoutAllowedDaysIsReported() {
        val d = WizardDraft(
            subjects = listOf("الفيزياء"), backlogs = mapOf("الفيزياء" to 3),
            firstOldNo = mapOf("الفيزياء" to 1),
            weekPlan = mapOf("السبت" to setOf("الكيمياء")), // الفيزياء غائبة تمامًا
            startDate = "2026-01-03", endDate = "2026-01-16", dailyStudyMin = 240,
            oldOnly = true, lectureDur = 45)
        val p = ScheduleGenerator.generate(d)
        assertNull(p.json)
        assertTrue(p.missingInputs.any { it.contains("الفيزياء") })
        // المخصص أيضًا يصرّح بالمشكلة
        val r = PlanAllocator.allocate(d)!!
        assertTrue(r.notes.any { it.contains("غير موزعة") })
    }

    // 7) فترة لا تكفي: المتبقي معلن + التمديد يُكمل عند تفعيله
    @Test fun t07_insufficientPeriodReportsLeftoversAndExtends() {
        val base = WizardDraft(
            subjects = listOf("الفيزياء"), backlogs = mapOf("الفيزياء" to 10),
            firstOldNo = mapOf("الفيزياء" to 5),
            weekPlan = mapOf("الأحد" to setOf("الفيزياء")),
            startDate = "2026-01-03", endDate = "2026-01-16", dailyStudyMin = 240,
            oldOnly = false, lectureDur = 75,
            newLectureDays = mapOf("الفيزياء" to setOf("الأحد")))
        val noExt = ScheduleGenerator.generate(base.copy(autoExtend = false))
        assertTrue(noExt.errors.toString(), noExt.ok)
        assertEquals(6, noExt.summary!!.leftoverOld)   // سعتا أحدين فقط (2 لكل يوم)
        assertTrue(noExt.warnings.any { it.contains("عجز") })
        val ext = ScheduleGenerator.generate(base.copy(autoExtend = true))
        assertTrue(ext.errors.toString(), ext.ok)
        assertEquals(0, ext.summary!!.leftoverOld)
        assertTrue(ext.summary!!.extraDays > 0)
    }

    // 8) يوم راحة: لا مهام فيه، والجديد المنشور فيه ينتقل معلنًا
    @Test fun t08_restDayHasNoTasksAndCarryIsVisible() {
        val d = WizardDraft(
            subjects = listOf("الفيزياء"), backlogs = mapOf("الفيزياء" to 0),
            restDays = setOf("الأحد"),
            startDate = "2026-01-03", endDate = "2026-01-16", dailyStudyMin = 300,
            oldOnly = false, lectureDur = 75,
            newLectureDays = mapOf("الفيزياء" to setOf("الأحد")))
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString(), p.missingInputs, p.ok)
        assertTrue(p.file!!.days.none { dayName(it.date) == "الأحد" })
        val carried = tasksOf(p).filter { it.second.type == TaskTypes.NEW }
        assertTrue(carried.all { dayName(it.first) == "الاثنين" })
        assertTrue(carried.all { it.second.note!!.contains("نُقلت لأول يوم دراسة") })
        // التحقق يقبل المنقول ولا يرفضه
        assertTrue(WizardVerify.compliance(p.file!!, d).isEmpty())
    }

    // 9) مهام بمدد مختلفة (جديد 75 + امتحان 60) تُحسب ضمن الحد
    @Test fun t09_mixedDurationsCountedWithinLimit() {
        val d = WizardDraft(
            subjects = listOf("الفيزياء"), backlogs = mapOf("الفيزياء" to 0),
            exams = listOf(ExamEntry(id = "e1", day = "الأحد", kind = "daily",
                subjects = listOf("الفيزياء"), time = "19:00", durationMin = 60)),
            startDate = "2026-01-03", endDate = "2026-01-16", dailyStudyMin = 200,
            oldOnly = false, lectureDur = 75,
            newLectureDays = mapOf("الفيزياء" to setOf("الأحد")))
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString(), p.ok)
        val sundays = p.file!!.days.filter { dayName(it.date) == "الأحد" }
        assertTrue(sundays.all { day -> day.tasks.sumOf { it.durationMin } == 135 }) // 75+60
        assertEquals(2, p.summary!!.examCount)
        assertTrue(p.file!!.days.all { day -> day.tasks.sumOf { it.durationMin } <= 200 })
    }

    // 10) يوم يصل بالضبط إلى الحد: يُقبل
    @Test fun t10_exactlyAtLimitAccepted() {
        val d = WizardDraft(
            subjects = listOf("الفيزياء"), backlogs = mapOf("الفيزياء" to 1),
            firstOldNo = mapOf("الفيزياء" to 3),
            weekPlan = mapOf("الأحد" to setOf("الفيزياء")),
            startDate = "2026-01-03", endDate = "2026-01-09", dailyStudyMin = 150,
            oldOnly = false, lectureDur = 75, autoExtend = false,
            newLectureDays = mapOf("الفيزياء" to setOf("الأحد")))
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString() + p.missingInputs, p.ok)
        val sunday = p.file!!.days.first { dayName(it.date) == "الأحد" }
        assertEquals(150, sunday.tasks.sumOf { it.durationMin })
    }

    // 11) تجاوز الحد بدقيقة واحدة: يُرفض (في المولّد وفي compliance)
    @Test fun t11_oneMinuteOverLimitRejected() {
        // أ) الجديد وحده يتجاوز الحد → المولّد يرفض الجدول كله
        val d = WizardDraft(
            subjects = listOf("الفيزياء", "الكيمياء"),
            backlogs = mapOf("الفيزياء" to 0, "الكيمياء" to 0),
            startDate = "2026-01-03", endDate = "2026-01-09", dailyStudyMin = 100,
            oldOnly = false, lectureDur = 75,
            newLectureDays = mapOf("الفيزياء" to setOf("الأحد"), "الكيمياء" to setOf("الأحد")))
        val p = ScheduleGenerator.generate(d)
        assertFalse(p.ok)
        assertNull(p.json)
        assertTrue(p.errors.any { it.contains("تتجاوز الحد اليومي") })
        // ب) ملف مستورد فيه يوم 421 دقيقة مع حد 420 → compliance يرفض
        val over = """{"format":"rafiq_schedule","formatVersion":1,"startDate":"2026-01-03","endDate":"2026-01-03",
            "days":[{"date":"2026-01-03","tasks":[
              {"id":"a","subject":"الفيزياء","type":"oldLecture","title":"تراكم 1","durationMin":211},
              {"id":"b","subject":"الفيزياء","type":"oldLecture","title":"تراكم 2","durationMin":210}]}]}"""
        val dd = WizardDraft(subjects = listOf("الفيزياء"), dailyStudyMin = 420)
        val r = ScheduleParser.parse(over)
        assertTrue(r.ok)
        assertTrue(WizardVerify.compliance(r.file!!, dd).any { it.contains("يتجاوز الحد اليومي") })
        // ج) 420 بالضبط مقبولة في compliance
        val exact = over.replace("211", "210")
        val r2 = ScheduleParser.parse(exact)
        assertTrue(WizardVerify.compliance(r2.file!!, dd).none { it.contains("يتجاوز") })
    }

    // 12) ملخص الخطوة 5 (PlanAllocator) يطابق الجدول المولّد
    @Test fun t12_summaryMatchesGeneratedSchedule() {
        val d = WizardDraft(
            subjects = listOf("الفيزياء", "الكيمياء"),
            backlogs = mapOf("الفيزياء" to 10, "الكيمياء" to 6),
            firstOldNo = mapOf("الفيزياء" to 5, "الكيمياء" to 1),
            startDate = "2026-01-03", endDate = "2026-01-16", dailyStudyMin = 240,
            oldOnly = false, lectureDur = 45,
            newLectureDays = mapOf("الفيزياء" to setOf("الأحد", "الأربعاء"), "الكيمياء" to setOf("الاثنين")))
        val r = PlanAllocator.allocate(d)!!
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString(), p.ok)
        assertEquals(r.totalNewMin, p.summary!!.newMin)
        assertEquals(r.totalOldFittedMin, p.summary!!.oldMin)
        assertEquals(r.totalOldLeftover, p.summary!!.leftoverOld)
        assertEquals(r.subjects.sumOf { it.expectedNew }, p.summary!!.newCount)
        assertTrue(r.subjects.all { sa ->
            val gs = p.summary!!.perSubject.first { it.subject == sa.subject }
            sa.oldCount == gs.oldPlaced + gs.oldLeftover && sa.oldLeftover == gs.oldLeftover })
        assertTrue(r.days.all { it.newMin + it.examMin + it.oldMin <= d.dailyStudyMin })
    }

    // 13) الاستيراد بالمحلل الحالي: لا فقد ولا تغيير أرقام
    @Test fun t13_importRoundTripPreservesTasksAndNumbers() {
        val d = WizardDraft(
            subjects = listOf("الفيزياء", "الكيمياء"),
            backlogs = mapOf("الفيزياء" to 10, "الكيمياء" to 6),
            firstOldNo = mapOf("الفيزياء" to 5, "الكيمياء" to 1),
            firstNewNo = mapOf("الفيزياء" to 20),
            startDate = "2026-01-03", endDate = "2026-01-16", dailyStudyMin = 240,
            oldOnly = false, lectureDur = 45,
            newLectureDays = mapOf("الفيزياء" to setOf("الأحد", "الأربعاء"), "الكيمياء" to setOf("الاثنين")))
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString(), p.ok)
        val re = ScheduleParser.parse(p.json!!)
        assertTrue(re.errors.toString(), re.ok)
        val orig = tasksOf(p).map { it.second }
        val back = re.file!!.days.flatMap { it.tasks }
        assertEquals(orig.size, back.size)
        assertEquals(orig.map { it.id }.toSet(), back.map { it.id }.toSet())
        assertEquals((5..14).toList(),
            back.filter { it.subject == "الفيزياء" && it.type == TaskTypes.OLD }.mapNotNull { it.lectureNo }.sorted())
        assertEquals((20..23).toList(),
            back.filter { it.subject == "الفيزياء" && it.type == TaskTypes.NEW }.mapNotNull { it.lectureNo }.sorted())
        val ents = ScheduleParser.toEntities("t", re.file!!)
        assertEquals(back.size, ents.size)
    }

    // 14) إعادة التوليد: حتمي، بلا تكرار ولا مضاعفة
    @Test fun t14_regenerationIsDeterministicWithoutDuplicates() {
        val d = WizardDraft(
            subjects = listOf("الفيزياء", "الكيمياء"),
            backlogs = mapOf("الفيزياء" to 10, "الكيمياء" to 6),
            firstOldNo = mapOf("الفيزياء" to 5, "الكيمياء" to 1),
            startDate = "2026-01-03", endDate = "2026-01-16", dailyStudyMin = 240,
            oldOnly = false, lectureDur = 45,
            newLectureDays = mapOf("الفيزياء" to setOf("الأحد", "الأربعاء"), "الكيمياء" to setOf("الاثنين")))
        val p1 = ScheduleGenerator.generate(d)
        val p2 = ScheduleGenerator.generate(d)
        assertTrue(p1.errors.toString(), p1.ok)
        assertEquals(p1.json, p2.json) // حتمي بالكامل
        val ids = tasksOf(p1).map { it.second.id }
        assertEquals(ids.size, ids.toSet().size) // لا تكرار
        assertEquals(16, p1.summary!!.oldCount)
        assertEquals(16, p2.summary!!.oldCount) // لا مضاعفة في العدد
    }
}
