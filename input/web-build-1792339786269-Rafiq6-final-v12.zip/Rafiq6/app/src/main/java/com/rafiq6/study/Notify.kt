package com.rafiq6.study

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

object Notify {
    const val CH = "tasks"
    fun ensureChannel(c: Context) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "تذكيرات المهام",
            NotificationManager.IMPORTANCE_HIGH).apply { description = "تنبيهات قبل وأثناء وبعد كل مهمة" })
    }
    fun notify(c: Context, id: Int, title: String, body: String, taskId: String?) {
        ensureChannel(c)
        val pi = PendingIntent.getActivity(c, id,
            Intent(c, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                if (taskId != null) putExtra("taskId", taskId)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setContentTitle(title).setContentText(body).setContentIntent(pi)
            .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, n)
    }
}

object AlarmScheduler {
    private const val REQ = 7000
    private fun pi(c: Context, taskId: String, kind: Int): PendingIntent =
        PendingIntent.getBroadcast(c, REQ + taskId.hashCode() * 4 + kind,
            Intent(c, AlarmReceiver::class.java).apply { putExtra("taskId", taskId); putExtra("kind", kind) },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun cancel(c: Context, t: TaskEntity) { val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (k in 0..2) am.cancel(pi(c, t.id, k)) }
    fun schedule(c: Context, t: UiTask) {
        if (t.done || !t.notify || t.startMin == null) { cancel(c, t.task); return }
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        fun set(triggerMs: Long, kind: Int) {
            try { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMs, pi(c, t.id, kind)) }
            catch (se: SecurityException) { am.setWindow(AlarmManager.RTC_WAKEUP, triggerMs, 60_000, pi(c, t.id, kind)) }
        }
        val today = Subjects.now().toLocalDate().toString()
        if (t.date < today) return
        val base = java.time.LocalDate.parse(t.date).atStartOfDay(Subjects.BAGHDAD)
            .plusMinutes(t.startMin!!.toLong()).toInstant().toEpochMilli()
        if (base - t.remindBeforeMin * 60_000 > System.currentTimeMillis()) set(base - t.remindBeforeMin * 60_000, 0)
        if (base > System.currentTimeMillis()) set(base, 1)
        if (t.endMin != null) { val end = base + (t.endMin!! - t.startMin!!) * 60_000L
            if (end + 15 * 60_000 > System.currentTimeMillis()) set(end + 15 * 60_000, 2) }
    }
    private const val MAX_TASKS = 60
    fun scheduleUpcoming(c: Context, tasks: List<UiTask>) {
        val now = Subjects.now(); val today = now.toLocalDate().toString()
        val nowMin = now.hour * 60 + now.minute
        tasks.asSequence()
            .filter { task ->
                val start = task.startMin
                !task.done && task.notify && start != null &&
                    (task.date > today || (task.date == today && (task.endMin ?: (start + task.durationMin)) + 15 > nowMin))
            }
            .sortedWith(compareBy({ it.date }, { it.startMin }))
            .take(MAX_TASKS)
            .forEach { schedule(c, it) }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) { val go = goAsync()
        try { runBlocking {
            val task = AppDb.get(c).dao().byId(intent.getStringExtra("taskId") ?: "")
            val progress = task?.let { AppDb.get(c).dao().progressById(it.id) }
            val t = task?.let { UiTask(it, progress) }
            if (t != null && !t.done) {
                val body = when (intent.getIntExtra("kind", 1)) {
                    0 -> "بعد ${t.remindBeforeMin} دقيقة تبدأ: ${t.title}. جهّز مكان الدراسة."
                    2 -> "باقي عندك «${t.title}» غير مكتملة. تريد تبدأ هسه؟"
                    else -> "هسه صار وقت ${t.title} — مدتها ${t.durationMin} دقيقة. يلا نبدأ!" }
                Notify.notify(c, t.id.hashCode(), "رفيق السادس", body, t.id)
            }
            val scheduleId = task?.scheduleId ?: AppDb.get(c).dao().activeSchedule().first()?.scheduleId
            val tasks = if (scheduleId == null) emptyList() else AppDb.get(c).dao().tasksForOnce(scheduleId)
            val progresses = tasks.mapNotNull { AppDb.get(c).dao().progressById(it.id) }
            AlarmScheduler.scheduleUpcoming(c, tasks.map { taskEntity ->
                UiTask(taskEntity, progresses.firstOrNull { p -> p.taskId == taskEntity.id })
            })
        } } finally { go.finish() } }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) runBlocking {
            val scheduleId = AppDb.get(c).dao().activeSchedule().first()?.scheduleId ?: return@runBlocking
            val tasks = AppDb.get(c).dao().tasksForOnce(scheduleId)
            val progresses = tasks.mapNotNull { AppDb.get(c).dao().progressById(it.id) }
            AlarmScheduler.scheduleUpcoming(c, tasks.map { t -> UiTask(t, progresses.firstOrNull { it.taskId == t.id }) })
        } }
}
