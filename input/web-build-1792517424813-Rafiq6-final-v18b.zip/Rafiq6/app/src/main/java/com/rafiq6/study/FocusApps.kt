package com.rafiq6.study

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.first

data class LaunchableApp(val pkg: String, val label: String, val icon: Drawable?)

object FocusAppsStore {
    private val KEY = stringPreferencesKey("focus_companion")
    suspend fun companionOf(c: Context): String? = c.focusDs.data.first()[KEY]
    suspend fun setCompanion(c: Context, pkg: String?) {
        c.focusDs.edit { if (pkg == null) it.remove(KEY) else it[KEY] = pkg }
    }
    fun labelOf(c: Context, pkg: String): String = runCatching {
        c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)
}

fun queryLaunchableApps(c: Context): List<LaunchableApp> {
    val pm = c.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val infos = if (android.os.Build.VERSION.SDK_INT >= 33)
        pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
    else @Suppress("DEPRECATION") pm.queryIntentActivities(intent, 0)
    return infos.map { ri ->
        LaunchableApp(ri.activityInfo.packageName, ri.loadLabel(pm).toString(),
            runCatching { ri.loadIcon(pm) }.getOrNull())
    }.distinctBy { it.pkg }.sortedBy { it.label }
}
