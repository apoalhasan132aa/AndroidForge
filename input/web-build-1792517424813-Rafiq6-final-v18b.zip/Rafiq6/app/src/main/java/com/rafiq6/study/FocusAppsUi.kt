package com.rafiq6.study

import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

fun Drawable.toBitmapCompat(size: Int): android.graphics.Bitmap {
    val bmp = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bmp)
    setBounds(0, 0, size, size)
    draw(canvas)
    return bmp
}

// شاشة اختيار تطبيقات جلسة التركيز
@Composable fun FocusAppsScreen(onPicked: (String) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf<List<LaunchableApp>>(emptyList()) }
    var q by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        apps = queryLaunchableApps(ctx)
        saved = FocusAppsStore.companionOf(ctx)
    }

    fun Drawable.bmp() = runCatching { this.toBitmapCompat(48).asImageBitmap() }.getOrNull()

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("تطبيقات جلسة التركيز", style = MaterialTheme.typography.headlineSmall)
        Text("رفيق محدد تلقائيًا كتطبيق أساسي. اختر تطبيقًا مرافقًا واحدًا (محاضرات / PDF / ملاحظات) للتنقل بينهما أثناء الجلسة.")
        OutlinedTextField(value = q, onValueChange = { q = it }, modifier = Modifier.fillMaxWidth(),
            label = { Text("بحث عن تطبيق بالاسم…") })
        saved?.let { Text("المختار حاليًا: ${FocusAppsStore.labelOf(ctx, it)}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            apps.filter { q.isBlank() || it.label.contains(q.trim()) }.forEach { app ->
                val selected = app.pkg == saved
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        app.icon?.bmp()?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.size(36.dp)) }
                        Text(app.label, Modifier.weight(1f).padding(horizontal = 8.dp),
                            style = MaterialTheme.typography.titleSmall)
                        if (selected) Button(onClick = {
                            scope.launch { FocusAppsStore.setCompanion(ctx, null); saved = null }
                        }) { Text("إزالة") }
                        else Button(onClick = {
                            scope.launch { FocusAppsStore.setCompanion(ctx, app.pkg) }
                            saved = app.pkg; onPicked(app.pkg)
                        }) { Text("اختيار") }
                    }
                }
            }
        }
        OutlinedButton(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("رجوع") }
    }
}
