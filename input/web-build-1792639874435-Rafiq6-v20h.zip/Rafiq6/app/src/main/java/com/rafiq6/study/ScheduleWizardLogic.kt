package com.rafiq6.study

import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit

// ===== نموذج مسودة الجدول السنوي — منطق نقي 100% (قابل للاختبار على JVM) =====

object WizardConst {
    val DEFAULT_SUBJECTS: List<String> = listOf("الفيزياء", "الكيمياء", "الرياضيات", "الأحياء", "العربي", "الإنكليزي")
    val DAYS: List<String> = listOf("السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة")
    fun dayOfWeekName(d: DayOfWeek): String = when (d) {
        DayOfWeek.SATURDAY -> "السبت"; DayOfWeek.SUNDAY -> "الأحد"
        DayOfWeek.MONDAY -> "الاثنين"; DayOfWeek.TUESDAY -> "الثلاثاء"
        DayOfWeek.WEDNESDAY -> "الأربعاء"; DayOfWeek.THURSDAY -> "الخميس"
        DayOfWeek.FRIDAY -> "الجمعة"
    }
}

/** اختبار يومي أو تراكمي داخل يوم الأسبوع. كل اختبار بمهمة مستقلة بعد الاستيراد. */
data class ExamEntry(
    val id: String = java.util.UUID.randomUUID().toString(),
    val day: String,                       // "السبت"…
    val kind: String,                      // "daily" | "cumulative"
    val subjects: List<String>,            // مادة واحدة أو أكثر
    val title: String = "",
    val time: String = "",                 // "HH:MM" أو ""
    val durationMin: Int? = null,          // null = غير محددة (لا نفترض قيمة)
    val notes: String = ""
)

/**
 * حالة المسودة. القيم كلها من إدخال الطالب — لا توجد قيم افتراضية مخفية.
 * backlogs: مادة → عدد مؤكد (0 يعني «ما عندي تراكم»). غياب المادة من الخريطة = لم يؤكد العدد بعد.
 * weekPlan: يوم → مجموعة المواد المسموحة فيه.
 */
data class WizardDraft(
    val mode: String = "new",
    val subjects: List<String> = emptyList(),
    val backlogs: Map<String, Int> = emptyMap(),
    val weekPlan: Map<String, Set<String>> = emptyMap(),
    val restDays: Set<String> = emptySet(),
    val startDate: String = "",
    val endDate: String = "",
    val dailyStudyMin: Int = 240,
    val schoolDays: Set<String> = emptySet(),
    val oldOnly: Boolean = true,
    val newWeekly: Map<String, Int> = emptyMap(),
    val newLectureDays: Map<String, Set<String>> = emptyMap(),   // مادة → أيام النشر الأسبوعية
    val newLectureTime: Map<String, String> = emptyMap(),         // مادة → وقت النشر "HH:MM" (اختياري — لا نخترع وقتًا)
    val lectureDur: Int = 45,                                      // مدة المحاضرة بالدقائق — تغذي المُخصص والبرومبت
    val hasNewScheduleReady: Boolean = false,
    val finalGoal: String = "",
    val exams: List<ExamEntry> = emptyList(),
    val firstOldNo: Map<String, Int> = emptyMap(),   // مادة → رقم أول محاضرة قديمة متبقية (يدخلها الطالب؛ لا تُخمَّن)
    val firstNewNo: Map<String, Int> = emptyMap(),   // مادة → رقم أول محاضرة جديدة قادمة (اختياري)
    val lectureDurBy: Map<String, Int> = emptyMap(), // مادة → مدة محاضرتها (اختياري؛ الغياب = lectureDur العامة)
    val autoExtend: Boolean = true                   // تمديد الجدول تلقائيًا إن لم تكفِ الفترة
) {
    /** مدة محاضرة المادة بالدقائق: المخصصة إن وُجدت وإلا العامة. */
    fun durOf(subject: String): Int = (lectureDurBy[subject]?.takeIf { it > 0 } ?: lectureDur).coerceAtLeast(1)
    /**
     * أيام المحاضرات الجديدة للمادة: ما حدده الطالب في «أيام النشر» إن وُجد، وإلا أيام الخطوة 3 (توزيع الأسبوع).
     * في وضع «تراكمات + جديد» تعني الخطوة 3 أيام الجديد/الاختبارات، لا أيام السماح بالتراكم.
     */
    fun newDaysOf(subject: String): Set<String> =
        newLectureDays[subject]?.takeIf { it.isNotEmpty() } ?: daysFor(subject).toSet()
    /** هل يجوز وضع تراكم المادة في هذا اليوم؟ مع الجديد: أي يوم دراسة. تراكمات فقط: أيام الخطوة 3 للمادة. */
    fun oldAllowedOn(subject: String, day: String): Boolean =
        day !in restDays && (!oldOnly || weekPlan.isEmpty() || subject in (weekPlan[day] ?: emptySet()))
    /** أيام الدراسة الفعلية لتراكم المادة. */
    fun usableDays(subject: String): List<String> = WizardConst.DAYS.filter { oldAllowedOn(subject, it) }
    fun examsOf(day: String): List<ExamEntry> = exams.filter { it.day == day }
    fun totalBacklog(): Int = subjects.sumOf { backlogs[it] ?: 0 }
    fun missingBacklogs(): List<String> = subjects.filter { !backlogs.containsKey(it) }
    fun daysFor(subject: String): List<String> =
        WizardConst.DAYS.filter { subject in (weekPlan[it] ?: emptySet()) }
    fun undistributed(): List<String> = subjects.filter { daysFor(it).isEmpty() }

    fun validateDates(): String? {
        if (startDate.isBlank() || endDate.isBlank()) return null
        return try {
            val s = LocalDate.parse(startDate); val e = LocalDate.parse(endDate)
            when {
                e < s -> "تاريخ النهاية يسبق تاريخ البداية."
                ChronoUnit.DAYS.between(s, e) > 370 -> "النطاق يتجاوز سنة كاملة — هل هذا مقصود؟"
                else -> null
            }
        } catch (e: Exception) { "التواريخ يجب أن تكون بصيغة YYYY-MM-DD." }
    }

    /** أوقات النشر غير الصالحة صيغيًا (يجب HH:MM). */
    fun invalidLectureTimes(): List<String> =
        newLectureTime.filter { !Regex("^\\d{1,2}:\\d{2}$").matches(it.value) }.keys.toList()

    fun daysCount(): Long? = try {
        if (startDate.isBlank() || endDate.isBlank()) null
        else ChronoUnit.DAYS.between(LocalDate.parse(startDate), LocalDate.parse(endDate)) + 1
    } catch (e: Exception) { null }

    fun readyForSummary(): List<String> {
        val problems = mutableListOf<String>()
        invalidLectureTimes().forEach { problems += "وقت محاضرة $it بصيغة غير صحيحة — استخدم HH:MM." }
        if (subjects.isEmpty()) problems += "اختر مادة واحدة على الأقل."
        missingBacklogs().forEach { problems += "حدد عدد تراكم مادة $it (أو أكّد أنها صفر)." }
        validateDates()?.let { problems += it }
        if (subjects.isNotEmpty() && weekPlan.isEmpty()) problems += "وزّع المواد على أيام الأسبوع."
        return problems
    }
}

// ===== عمليات خطة الأسبوع (دالات نقية) =====

object WeekOps {
    fun toggle(d: WizardDraft, day: String, subject: String): WizardDraft {
        if (day in d.restDays) return d
        val cur = d.weekPlan[day] ?: emptySet()
        val next = if (subject in cur) cur - subject else cur + subject
        return d.copy(weekPlan = d.weekPlan + (day to next))
    }
    fun setAll(d: WizardDraft, day: String): WizardDraft {
        if (day in d.restDays) return d
        return d.copy(weekPlan = d.weekPlan + (day to d.subjects.toSet()))
    }
    fun clearDay(d: WizardDraft, day: String): WizardDraft =
        d.copy(weekPlan = d.weekPlan + (day to emptySet()))
    fun copyDay(d: WizardDraft, from: String, targets: Collection<String>): WizardDraft {
        val src = d.weekPlan[from] ?: emptySet()
        var plan = d.weekPlan
        targets.filter { it != from && it !in d.restDays }.forEach { plan = plan + (it to src) }
        return d.copy(weekPlan = plan)
    }
    fun setRest(d: WizardDraft, day: String, rest: Boolean): WizardDraft =
        if (rest) d.copy(restDays = d.restDays + day, weekPlan = d.weekPlan + (day to emptySet()))
        else d.copy(restDays = d.restDays - day)
    fun addSubject(d: WizardDraft, subject: String): WizardDraft =
        if (subject.isBlank() || subject in d.subjects) d else d.copy(subjects = d.subjects + subject.trim())
    fun removeSubject(d: WizardDraft, subject: String): WizardDraft =
        d.copy(
            subjects = d.subjects - subject,
            backlogs = d.backlogs - subject,
            newWeekly = d.newWeekly - subject,
            firstOldNo = d.firstOldNo - subject,
            firstNewNo = d.firstNewNo - subject,
            lectureDurBy = d.lectureDurBy - subject,
            weekPlan = d.weekPlan.mapValues { (_, v) -> v - subject }
        )
}

// ===== ترميز المسودة (JSON) =====

object WizardDraftCodec {
    fun toJson(d: WizardDraft): JSONObject = JSONObject().apply {
        put("mode", d.mode)
        put("subjects", JSONArray().apply { d.subjects.forEach { put(it) } })
        put("backlogs", JSONObject().apply { d.backlogs.forEach { (k, v) -> put(k, v) } })
        put("weekPlan", JSONObject().apply { d.weekPlan.forEach { (k, v) ->
            put(k, JSONArray().apply { v.forEach { put(it) } }) } })
        put("restDays", JSONArray().apply { d.restDays.forEach { put(it) } })
        put("startDate", d.startDate); put("endDate", d.endDate)
        put("dailyStudyMin", d.dailyStudyMin)
        put("schoolDays", JSONArray().apply { d.schoolDays.forEach { put(it) } })
        put("oldOnly", d.oldOnly)
        put("newWeekly", JSONObject().apply { d.newWeekly.forEach { (k, v) -> put(k, v) } })
        put("newLectureDays", JSONObject().apply { d.newLectureDays.forEach { (k, v) ->
            put(k, JSONArray().apply { v.forEach { put(it) } }) } })
        put("newLectureTime", JSONObject().apply { d.newLectureTime.forEach { (k, v) -> put(k, v) } })
        put("lectureDur", d.lectureDur)
        put("hasNewScheduleReady", d.hasNewScheduleReady)
        put("finalGoal", d.finalGoal)
        put("firstOldNo", JSONObject().apply { d.firstOldNo.forEach { (k, v) -> put(k, v) } })
        put("firstNewNo", JSONObject().apply { d.firstNewNo.forEach { (k, v) -> put(k, v) } })
        put("lectureDurBy", JSONObject().apply { d.lectureDurBy.forEach { (k, v) -> put(k, v) } })
        put("autoExtend", d.autoExtend)
        put("exams", JSONArray().apply { d.exams.forEach { e -> put(JSONObject().apply {
            put("id", e.id); put("day", e.day); put("kind", e.kind)
            put("subjects", JSONArray().apply { e.subjects.forEach { put(it) } })
            put("title", e.title); put("time", e.time)
            if (e.durationMin != null) put("durationMin", e.durationMin)
            put("notes", e.notes)
        }) } })
    }

    private fun jsonToList(a: JSONArray?): List<String> =
        if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }
    private fun jsonToSet(a: JSONArray?): Set<String> = jsonToList(a).toSet()

    fun fromJson(o: JSONObject): WizardDraft {
        val backlogs = mutableMapOf<String, Int>()
        o.optJSONObject("backlogs")?.let { bj -> bj.keys().forEach { k -> backlogs[k] = bj.getInt(k) } }
        val weekPlan = mutableMapOf<String, Set<String>>()
        o.optJSONObject("weekPlan")?.let { pj -> pj.keys().forEach { k -> weekPlan[k] = jsonToSet(pj.getJSONArray(k)) } }
        val newWeekly = mutableMapOf<String, Int>()
        o.optJSONObject("newWeekly")?.let { nj -> nj.keys().forEach { k -> newWeekly[k] = nj.getInt(k) } }
        val newLectureDays = mutableMapOf<String, Set<String>>()
        o.optJSONObject("newLectureDays")?.let { pj -> pj.keys().forEach { k ->
            newLectureDays[k] = jsonToSet(pj.getJSONArray(k)) } }
        val newLectureTime = mutableMapOf<String, String>()
        o.optJSONObject("newLectureTime")?.let { tj -> tj.keys().forEach { k ->
            newLectureTime[k] = tj.getString(k) } }
        val firstOldNo = mutableMapOf<String, Int>()
        o.optJSONObject("firstOldNo")?.let { j -> j.keys().forEach { k -> firstOldNo[k] = j.getInt(k) } }
        val firstNewNo = mutableMapOf<String, Int>()
        o.optJSONObject("firstNewNo")?.let { j -> j.keys().forEach { k -> firstNewNo[k] = j.getInt(k) } }
        val lectureDurBy = mutableMapOf<String, Int>()
        o.optJSONObject("lectureDurBy")?.let { j -> j.keys().forEach { k -> lectureDurBy[k] = j.getInt(k) } }
        return WizardDraft(
            firstOldNo = firstOldNo, firstNewNo = firstNewNo,
            lectureDurBy = lectureDurBy, autoExtend = o.optBoolean("autoExtend", true),
            mode = o.optString("mode", "new"),
            subjects = jsonToList(o.optJSONArray("subjects")),
            backlogs = backlogs, weekPlan = weekPlan,
            restDays = jsonToSet(o.optJSONArray("restDays")),
            startDate = o.optString("startDate"), endDate = o.optString("endDate"),
            dailyStudyMin = o.optInt("dailyStudyMin", 240),
            schoolDays = jsonToSet(o.optJSONArray("schoolDays")),
            oldOnly = o.optBoolean("oldOnly", true), newWeekly = newWeekly,
            newLectureDays = newLectureDays, newLectureTime = newLectureTime,
            lectureDur = o.optInt("lectureDur", 45),
            hasNewScheduleReady = o.optBoolean("hasNewScheduleReady", false),
            finalGoal = o.optString("finalGoal"),
            exams = o.optJSONArray("exams")?.let { arr ->
                (0 until arr.length()).map { j -> arr.getJSONObject(j) }.map { e ->
                    ExamEntry(
                        id = e.optString("id", java.util.UUID.randomUUID().toString()),
                        day = e.optString("day"), kind = e.optString("kind"),
                        subjects = jsonToList(e.optJSONArray("subjects")),
                        title = e.optString("title"), time = e.optString("time"),
                        durationMin = if (e.has("durationMin")) e.getInt("durationMin") else null,
                        notes = e.optString("notes"))
                }
            } ?: emptyList()
        )
    }
}

// ===== بنّاء البرومبت — يعكس اختيارات الطالب حرفيًا =====

object WizardPromptBuilder {
    fun build(d: WizardDraft): String = buildString {
        appendLine("أنت منظّم جداول دراسية لطالب السادس العلمي. أنشئ ملف JSON واحدًا وفق صيغة rafiq_schedule_v1.")
        appendLine("ممنوع اختراع محاضرات أو أرقام أو أسماء غير موجودة في بيانات الطالب أدناه.")
        appendLine()
        appendLine("=== بيانات الطالب (مصدرها الأساسي) ===")
        appendLine("نوع العملية: ${if (d.mode == "replan") "إعادة تنظيم جدول موجود مع الإبقاء على المنجز" else "جدول سنوي جديد"}")
        appendLine("--- القسم A: التراكمات القديمة ---")
        d.subjects.forEach { s ->
            val cnt = d.backlogs[s]
            val days = d.daysFor(s).joinToString("، ").ifBlank { "غير محددة" }
            val firstNo = d.firstOldNo[s]?.let { " — أول محاضرة قديمة متبقية رقم $it (متسلسلة بعدها)" } ?: ""
            appendLine("- $s: المتبقي ${cnt ?: "غير محدد"} محاضرة تراكم (مدة المحاضرة ${d.durOf(s)} دقيقة)$firstNo" +
                if (d.oldOnly) " — أيام التوزيع: $days" else " — تُوزَّع على كل أيام الدراسة غير الراحة")
        }
        if (!d.oldOnly) {
            appendLine()
            appendLine("--- القسم B: المحاضرات الجديدة (إلزامي — لا تحذفه) ---")
            d.subjects.forEach { s ->
                val pubDays = d.newDaysOf(s).sortedBy { WizardConst.DAYS.indexOf(it) }
                val weekly = d.newWeekly[s]
                val pubTime = d.newLectureTime[s]?.takeIf { it.isNotBlank() }
                when {
                    pubDays.isNotEmpty() -> appendLine("- $s: محاضرة جديدة ثابتة يوم ${pubDays.joinToString("، ")} (مدة ${d.durOf(s)} دقيقة)" +
                        (pubTime?.let { " الساعة $it" } ?: "") +
                        (weekly?.let { " ($it محاضرات/أسبوع)" } ?: ""))
                    weekly != null -> appendLine("- $s: $weekly محاضرات جديدة أسبوعيًا (الأيام غير محددة — وزّعها على أيام غير مزدحة)")
                    else -> appendLine("- $s: محاضرات جديدة أسبوعية (الأيام غير محددة)")
                }
            }
            if (d.hasNewScheduleReady) appendLine("لدى الطالب جدول محاضرات جديدة جاهز — وزّع الجديد وفق أيامه.")
        }
        appendLine("مجموع التراكمات الكلي: ${d.totalBacklog()} محاضرة")
        if (d.restDays.isNotEmpty()) appendLine("أيام الراحة (ممنوع جدولة أي مهمة دراسية فيها): ${d.restDays.sortedBy { WizardConst.DAYS.indexOf(it) }.joinToString("، ")}")
        appendLine("تاريخ بداية الجدول: ${d.startDate.ifBlank { "؟" }} — تاريخ النهاية: ${d.endDate.ifBlank { "؟" }}" +
            (d.daysCount()?.let { " (المتاح $it يومًا)" } ?: ""))
        appendLine("الحد الأقصى للدراسة يوميًا: ${d.dailyStudyMin / 60} ساعات · مدة المحاضرة الواحدة: ${d.lectureDur} دقيقة")
        if (d.lectureDurBy.isNotEmpty()) appendLine("مدد المحاضرات حسب المادة: " +
            d.subjects.joinToString("، ") { "$it ${d.durOf(it)}د" } + " — احسب كل محاضرة بمدة مادتها بالضبط.")
        if (d.autoExtend) appendLine("إذا لم تكفِ الفترة لإكمال التراكم فمدّد الجدول بعد تاريخ النهاية أسبوعًا فأسبوعًا مع الالتزام بالراحة والحد اليومي وأيام الجديد، ولا تحذف أي تراكم.")
        if (d.schoolDays.isNotEmpty()) appendLine("أيام الدوام المدرسي: ${d.schoolDays.joinToString("، ")}")
        if (d.oldOnly) appendLine("المطلوب: توزيع التراكمات فقط — لا تنشئ أي محاضرة جديدة.")
        else {
            appendLine("المطلوب: توزيع التراكمات + المحاضرات الجديدة.")
            if (d.newWeekly.isNotEmpty()) {
                appendLine("المحاضرات الجديدة المتوقعة أسبوعيًا:")
                d.newWeekly.forEach { (s, n) -> appendLine("- $s: $n محاضرات أسبوعيًا") }
            }
            if (d.hasNewScheduleReady) appendLine("لدى الطالب جدول محاضرات جديدة جاهز — وزّع الجديد وفق أيامها إن ذُكرت، وإلا فوفق الأيام المتاحة.")
        }
        if (d.finalGoal.isNotBlank()) appendLine("هدف مهم: ${d.finalGoal}")
        if (d.exams.isNotEmpty()) {
            appendLine()
            appendLine("=== الاختبارات المطلوبة (أدرج كل اختبار كمهمة مستقلة) ===")
            d.exams.forEach { e ->
                appendLine("- ${if (e.kind == "daily") "اختبار يومي" else "اختبار تراكمي"} يوم ${e.day}: ${e.subjects.joinToString("، ")}" +
                    (e.time.takeIf { it.isNotBlank() }?.let { " — الساعة $it" } ?: "") +
                    (e.durationMin?.let { " — المدة $it دقيقة" } ?: " — بدون مدة محددة") +
                    (e.title.takeIf { it.isNotBlank() }?.let { " — $it" } ?: "") +
                    (e.notes.takeIf { it.isNotBlank() }?.let { " (${it})" } ?: ""))
            }
            appendLine("النوع في الملف: dailyExam لليومي وcumulativeExam للتراكمي، مع مادة كل اختبار.")
        }
        appendLine()
        appendLine("=== قواعد إلزامية ===")
        if (!d.oldOnly) {
            appendLine("قاعدة التوزيع الأساسية (أهم قاعدة): المحاضرات الجديدة والاختبارات ثابتة في أيامها (القسم B) ولا تُنقل. التراكم القديم يُوزَّع «بالتساوي» على كل أيام الدراسة غير الراحة مع الجديد: احسب لكل يوم الوقت المتبقي = الحد اليومي − (الجديد + الاختبارات) ثم وزّع إجمالي دقائق التراكم على الأيام بنسبة الوقت المتبقي في كلٍّ منها، وبين المواد بالتناوب حسب الأكبر تراكمًا. لا تكدّس التراكم في أيام قليلة ولا تترك أيامًا فارغة وفيها وقت.")
            appendLine("الحد اليومي صارم: مجموع دقائق (الجديد + الاختبارات + التراكم) في اليوم ≤ ${d.dailyStudyMin} دقيقة، وكل محاضرة بمدتها الكاملة بلا تقريب. إن بقي تراكم بعد تاريخ النهاية فأكمله في أسابيع إضافية بالقاعدة نفسها، وإن كان الجديد يستهلك الوقت كله فاذكر في issues أن التراكم لن ينتهي بدل ادّعاء إكماله.")
        }
        appendLine("0. أنشئ جدولاً واحدًا يجمع القسمين طوال الفترة. المحاضرات الجديدة المتكررة أسبوعيًا جزء إلزامي: ثبّتها أولًا وفق أيام النشر في القسم B — ممنوع حذفها أو تجاهلها لتسهيل التراكمات. ثم وزّع التراكمات (القسم A) في الوقت المتبقي بعدها والاختبارات والالتزامات. إذا تعارض الوقت، أظهر التعارض ولا تحذف أي قسم بصمت.")
        appendLine("1. وزّع جميع محاضرات التراكمات (${d.totalBacklog()}) دون فقدان أي محاضرة؛ اجعل العنوان: «تراكم $ — {المادة}» مع ترقيم متسلسل. لا تحسب المحاضرات الجديدة ضمن هذا العدد.")
        if (d.oldOnly) appendLine("2. جدولة مهام المادة مسموحة فقط في أيامها المذكورة أعلاه؛ استثناءً: مراجعة عامة أو امتحان شامل يجوز توزيعه في يوم آخر مع ذكر ذلك في الملاحظات.")
        else appendLine("2. المحاضرات الجديدة والاختبارات في أيامها المحددة فقط؛ التراكم القديم يجوز في أي يوم دراسة غير راحة وفق التوزيع بالتساوي.")
        appendLine("3. ممنوع جدولة أي مهمة دراسية في أيام الراحة.")
        appendLine("4. لا تتجاوز الحد اليومي (${d.dailyStudyMin} دقيقة)؛ إذا تعذّر التوزيع ضمن الوقت المتاح فاذكر ذلك بوضوح في مصفوفة issues ولا تختصر التراكمات صمتًا.")
        appendLine("5. كل مهمة: تاريخ + مادة + نوع + عنوان + مدة > 0. الأنواع: oldLecture (تراكم)، newLecture (جديدة)، review، homework، dailyExam، cumulativeExam، quiz، commitment.")
        appendLine("6. تحقق أن مجموع المحاضرات لكل مادة يساوي عدد تراكماتها تمامًا.")
        appendLine("7. التواريخ بصيغة YYYY-MM-DD وضمن نطاق الجدول.")
        appendLine("8. أخرج JSON فقط — بلا مقدمات ولا Markdown ولا نص خارج JSON.")
        appendLine("9. إذا كان الملف كبيرًا قسّمه وفق بروتوكول الأجزاء أدناه.")
        appendLine()
        appendLine("=== مخطط الإخراج ===")
        appendLine("""{"format":"rafiq_schedule","formatVersion":1,"metadata":{"scheduleName":"..."},"startDate":"YYYY-MM-DD","endDate":"YYYY-MM-DD","days":[{"date":"YYYY-MM-DD","tasks":[{"id":"فريد","subject":"المادة","type":"oldLecture","title":"...","lectureNo":1,"durationMin":45,"start":"HH:MM","end":"HH:MM","note":"..."}]}]}""")
        PlanAllocator.allocate(d)?.let { r ->
            appendLine()
            appendLine(PlanAllocator.reportSummary(r))
        }
        appendLine()
        appendLine("=== بروتوكول الأجزاء ===")
        appendLine("""{"format":"rafiq_part","partIndex":1,"totalParts":3,"payload":{"metadata":{...},"startDate":"...","endDate":"...","days":[...أيام كاملة بلا تقطيع...]}}""")
    }
}

// ===== تجميع الأجزاء (كل جزء JSON مستقل يحمل أيامًا كاملة) =====

object PartAssembler {
    data class Assembly(val text: String?, val errors: List<String>)

    fun assemble(parts: List<String>): Assembly {
        if (parts.isEmpty()) return Assembly(null, listOf("لا توجد أجزاء."))
        val metas = mutableListOf<Triple<Int, Int, JSONObject>>()
        val errors = mutableListOf<String>()
        parts.forEachIndexed { i, raw ->
            try {
                val o = JSONObject(raw.trim())
                if (o.optString("format") != "rafiq_part") { errors += "الجزء ${i + 1} ليس جزءًا (format=rafiq_part)."; return@forEachIndexed }
                val payload = o.optJSONObject("payload") ?: run { errors += "الجزء ${i + 1} يفتقد payload."; return@forEachIndexed }
                if (!payload.has("days")) { errors += "الجزء ${i + 1} يفتقد payload.days."; return@forEachIndexed }
                metas += Triple(o.getInt("partIndex"), o.getInt("totalParts"), payload)
            } catch (e: Exception) { errors += "الجزء ${i + 1} ليس JSON صالحًا." }
        }
        if (errors.isNotEmpty()) return Assembly(null, errors)
        val total = metas.first().second
        if (metas.any { it.second != total }) return Assembly(null, listOf("عدد الأجزاء الكلي غير متطابق."))
        if (metas.size != total) return Assembly(null, listOf("الأجزاء المستلمة ${metas.size} من أصل $total."))
        val sorted = metas.sortedBy { it.first }
        if (sorted.map { it.first } != (1..total).toList()) return Assembly(null, listOf("أرقام الأجزاء غير متسلسلة: ${sorted.map { it.first }}"))
        val first = sorted.first().third
        val days = JSONArray(); val seen = mutableSetOf<String>()
        sorted.forEach { (_, _, payload) ->
            val arr = payload.getJSONArray("days")
            for (j in 0 until arr.length()) {
                val day = arr.getJSONObject(j); val dd = day.optString("date")
                if (dd.isNotBlank() && !seen.add(dd)) errors += "تاريخ مكرر بين الأجزاء: $dd"
                days.put(day)
            }
        }
        if (errors.isNotEmpty()) return Assembly(null, errors.distinct())
        return Assembly(JSONObject().apply {
            put("format", "rafiq_schedule"); put("formatVersion", 1)
            put("metadata", first.optJSONObject("metadata") ?: JSONObject())
            if (first.has("startDate")) put("startDate", first.getString("startDate"))
            if (first.has("endDate")) put("endDate", first.getString("endDate"))
            put("days", days)
        }.toString(), emptyList())
    }
}

// ===== التحقق والمعاينة =====

data class PlanStats(
    val dayCount: Int, val taskCount: Int, val totalMin: Int,
    val perSubject: Map<String, Int>, val highLoadDays: List<Pair<String, Int>>,
    val oldLectures: Int, val newLectures: Int, val warnings: List<String>,
    val expectedNew: Map<String, Int> = emptyMap(),     // المتوقع من أيام النشر × الفترة
    val missingNew: Map<String, Int> = emptyMap()         // النقص الفعلي لكل مادة
)

object WizardVerify {
    /** عدد المحاضرات الجديدة المتوقعة لمادة بين تاريخين وفق أيام النشر الأسبوعية. */
    fun expectedNewLectures(start: LocalDate, end: LocalDate, publishDays: Set<String>): Int {
        if (publishDays.isEmpty()) return 0
        var count = 0
        var cur = start
        while (!cur.isAfter(end)) {
            if (WizardConst.dayOfWeekName(cur.dayOfWeek) in publishDays) count++
            cur = cur.plusDays(1)
        }
        return count
    }

    fun stats(file: ScheduleFile, d: WizardDraft): PlanStats {
        val perSubject = mutableMapOf<String, Int>()
        var total = 0; var oldL = 0; var newL = 0
        val daily = mutableMapOf<String, Int>()
        file.days.forEach { day ->
            var dayMin = 0
            day.tasks.forEach { t ->
                perSubject[t.subject] = (perSubject[t.subject] ?: 0) + 1
                total += t.durationMin; dayMin += t.durationMin
                if (t.type == TaskTypes.OLD) oldL++
                if (t.type == TaskTypes.NEW) newL++
            }
            daily[day.date.toString()] = dayMin
        }
        val warnings = mutableListOf<String>()
        val high = daily.filter { it.value > d.dailyStudyMin }.toList().sortedByDescending { it.second }
        high.forEach { (dd, m) -> warnings += "يوم $dd يتجاوز الحد اليومي (${m / 60}س ${m % 60}د > ${d.dailyStudyMin / 60}س)." }
        // مطابقة أعداد التراكمات المتوقعة فعليًا (حساب داخلي، لا من أرقام النموذج)
        val actualOld = mutableMapOf<String, Int>()
        file.days.forEach { day -> day.tasks.filter { it.type == TaskTypes.OLD }.forEach { t ->
            actualOld[t.subject] = (actualOld[t.subject] ?: 0) + 1 } }
        d.backlogs.forEach { (s, n) ->
            val act = actualOld[s] ?: 0
            if (act != n) warnings += "تراكمات $s: الموزعة $act ≠ المطلوبة $n."
        }
        val start = file.startDate; val end = file.endDate
        if (start != null && end != null) {
            val days = ChronoUnit.DAYS.between(start, end) + 1
            if (days < file.days.size) warnings += "عدد الأيام (${file.days.size}) أكبر من نطاق التواريخ ($days)."
        }
        // مطابقة المحاضرات الجديدة المتوقعة (من أيام النشر × الفترة) بالموجود فعليًا
        val expectedNew = mutableMapOf<String, Int>()
        val missingNew = mutableMapOf<String, Int>()
        if (!d.oldOnly && file.startDate != null && file.endDate != null) {
            val actualNewPerSubject = mutableMapOf<String, Int>()
            file.days.forEach { day -> day.tasks.filter { it.type == TaskTypes.NEW }.forEach { t ->
                actualNewPerSubject[t.subject] = (actualNewPerSubject[t.subject] ?: 0) + 1 } }
            d.subjects.forEach { s ->
                val days = d.newDaysOf(s)
                if (days.isNotEmpty()) {
                    val exp = expectedNewLectures(file.startDate, file.endDate, days)
                    expectedNew[s] = exp
                    val miss = exp - (actualNewPerSubject[s] ?: 0)
                    if (miss > 0) missingNew[s] = miss
                }
            }
            if (d.subjects.any { d.newDaysOf(it).isNotEmpty() } && file.days.sumOf { day ->
                    day.tasks.count { it.type == TaskTypes.NEW } } == 0)
                warnings += "الملف يحتوي التراكمات فقط ولا يحوي أي محاضرة جديدة رغم تحديد أيام نشر — غير مكتمل."
        }
        return PlanStats(file.days.size, file.taskCount(), total,
            perSubject.toList().sortedByDescending { it.second }.toMap(), high, oldL, newL, warnings.distinct(),
            expectedNew.toMap(), missingNew.toMap())
    }

    /** تحقق مطابقة الملف لخطة الطالب: الأيام المسموحة، الراحة، النطاق، المدد، المعرّفات. */
    fun compliance(file: ScheduleFile, d: WizardDraft): List<String> {
        val errors = mutableListOf<String>()
        val ids = mutableSetOf<String>()
        val start = file.startDate; val end = file.endDate
        file.days.forEach { day ->
            val dayName = WizardConst.dayOfWeekName(day.date.dayOfWeek)
            if (start != null && end != null && (day.date < start || day.date > end))
                errors += "يوم ${day.date} خارج نطاق الجدول."
            if (dayName in d.restDays)
                day.tasks.forEach { errors += "مهمة «${it.title}» (${it.subject}) مجدولة في يوم راحة ($dayName ${day.date})." }
            day.tasks.forEach { t ->
                if (!ids.add(t.id)) errors += "معرّف مكرر: ${t.id}."
                if (t.durationMin <= 0) errors += "مدة غير صالحة (${t.durationMin}) في «${t.title}»."
                if (d.subjects.isNotEmpty() && t.subject !in d.subjects)
                    errors += "مادة غير معروفة في المسودة: «${t.subject}» (مهمة ${t.id})."
                if (t.type == TaskTypes.OLD) {
                    val allowed = d.weekPlan[dayName] ?: emptySet()
                    if (allowed.isNotEmpty() && t.subject !in allowed)
                        errors += "«${t.title}» (${t.subject}) مجدولة يوم $dayName وهو ليس من أيامها المسموحة."
                }
            }
        }
        return errors.distinct()
    }
}

// ===== مُخصص الخطة: حماية وقت الجديد أولًا ثم توزيع القديم على المتبقي (منطق نقي) =====

data class SubjectAllocation(
    val subject: String,
    val oldCount: Int,                 // التراكم المطلوب إنجازه
    val expectedNew: Int,              // الجديد المتوقع خلال الفترة
    val totalLectures: Int,
    val newMinNeeded: Int,             // وقت الجديد المطلوب
    val oldMinNeeded: Int,             // وقت القديم المطلوب كاملًا
    val oldMinFitted: Int,             // ما استوعبته الخطة فعليًا
    val oldLeftover: Int               // محاضرات قديمة متبقية (تقرير العجز)
)

data class DayAllocation(
    val date: LocalDate, val dayName: String,
    val newMin: Int,                   // محمي للمحاضرات الجديدة
    val examMin: Int,                  // وقت الاختبارات المؤكد في اليوم
    val oldMin: Int,                   // المتاح للتراكم بعد حماية الجديد
    val overLimit: Boolean,            // الجديد+الاختبارات يتجاوزان الحد اليومي
    val isRest: Boolean = false        // يوم راحة: لا دراسة فيه
)

data class AllocationReport(
    val days: List<DayAllocation>,
    val subjects: List<SubjectAllocation>,
    val totalStudyMin: Int,            // مجموع الوقت المتاح كاملًا
    val totalNewMin: Int, val totalOldFittedMin: Int, val totalOldNeededMin: Int,
    val feasible: Boolean,             // كل القديم يُنجز ضمن الفترة
    val totalOldLeftover: Int,
    val estimatedFinishDate: LocalDate?,  // تاريخ إنهاء القديم المتوقع
    val notes: List<String>,
    val extendedDays: Int = 0,            // أيام أُضيفت بعد تاريخ النهاية الأصلي
    val effectiveEnd: LocalDate? = null,  // آخر يوم في الجدول بعد التمديد
    val extensionBlocked: Boolean = false // التمديد لا يُنهي التراكم (توقّف بدل حلقة لا نهائية)
) {
    val extendedWeeks: Int get() = (extendedDays + 6) / 7
}

/** توزيع التراكم بالتساوي: حصة اليوم = إجمالي المتبقي × (سعة اليوم ÷ مجموع سعات الأيام المتبقية في الفترة). */
object Leveling {
    /** سعة اليوم للتراكم = الحد − الجديد − الاختبارات (0 في الراحة). تقدير دوري لا يشمل ترحيل أيام الراحة. */
    fun freeCap(d: WizardDraft, date: LocalDate): Int {
        val name = WizardConst.dayOfWeekName(date.dayOfWeek)
        if (name in d.restDays) return 0
        val newMin = if (d.oldOnly) 0 else d.subjects.filter { name in d.newDaysOf(it) }.sumOf { d.durOf(it) }
        val examMin = d.exams.filter { it.day == name }.sumOf { it.durationMin ?: 0 }
        return (d.dailyStudyMin - newMin - examMin).coerceAtLeast(0)
    }
    fun quota(d: WizardDraft, leftMin: Int, from: LocalDate, end: LocalDate): Int {
        if (leftMin <= 0) return 0
        val today = freeCap(d, from)
        if (today <= 0) return 0
        var sum = 0L
        var c = from
        while (!c.isAfter(end)) { sum += freeCap(d, c); c = c.plusDays(1) }
        if (sum <= 0) return Int.MAX_VALUE
        return ((leftMin.toLong() * today + sum - 1) / sum).toInt().coerceAtLeast(1)
    }
}

/**
 * قرار تمديد الجدول بعد تاريخ النهاية — مشترك بين PlanAllocator وScheduleGenerator لضمان تطابقهما.
 * يستمر التمديد ما دام هناك تراكم لم يُجدول. حمايتان من الحلقة اللانهائية:
 *  1) كل STALL_DAYS يومًا: إن كانت كل المواد المتبقية بلا أي تقدم → توقّف (الأنماط أسبوعية دورية، فانعدام التقدم دائم).
 *  2) سقف مطلق MAX_EXTRA_DAYS.
 */
class ExtensionTracker(private val enabled: Boolean) {
    companion object {
        const val STALL_DAYS = 14
        const val MAX_EXTRA_DAYS = 365
    }
    var extDays = 0; private set
    var stalled = false; private set
    var lastOldDay: LocalDate? = null     // آخر يوم وُضع فيه تراكم
    private val last = mutableMapOf<String, Int>()

    /** يُستدعى عند تجاوز التاريخ الأصلي. true = أضِف يومًا آخر. */
    fun shouldContinue(left: Map<String, Int>, placed: Map<String, Int>): Boolean {
        val pending = left.filter { it.value > 0 }.keys
        if (!enabled || pending.isEmpty()) return false
        if (extDays >= MAX_EXTRA_DAYS) { stalled = true; return false }
        if (extDays == 0) {
            pending.forEach { last[it] = placed[it] ?: 0 }
        } else if (extDays % STALL_DAYS == 0) {
            val starved = pending.filter { (placed[it] ?: 0) == (last[it] ?: -1) }
            pending.forEach { last[it] = placed[it] ?: 0 }
            if (starved.size == pending.size) { stalled = true; return false }
        }
        extDays++
        return true
    }

    fun noteOldPlaced(day: LocalDate) { lastOldDay = day }
}

object PlanAllocator {
    const val BLOCKED_MSG = "تمديد الجدول لا يُنهي التراكم ضمن القيود الحالية (الجديد والاختبارات والأيام المسموحة تستهلك الوقت المتاح، أو بلغ التمديد سقفه) — لم يُمدَّد الجدول. زد الوقت اليومي أو أضف أيام دراسة للمادة أو خفّض الأحمال."

    /**
     * خوارزمية: احجز وقت الجديد المستحق يومه، ثم املأ المتبقي بالقديم (الأكبر وقتًا متبقيًا بين المواد المسموحة اليوم).
     * - مدة كل مادة من draft.durOf(مادة) — لا تُوحَّد المدد.
     * - يوم الراحة: لا دراسة فيه؛ المحاضرة الجديدة المنشورة فيه تنتقل لأول يوم دراسة تالٍ (لا تُسقط).
     * - القديم لا يوضع إلا في الأيام المسموحة للمادة في weekPlan (إن وُجدت خطة أسبوع).
     * - «تراكمات فقط» (oldOnly): لا تُحسب أي محاضرة جديدة.
     * - autoExtend: إن بقي تراكم بعد تاريخ النهاية يستمر اليوم تلو اليوم (أسبوعًا فأسبوعًا) حتى الإنجاز أو التوقف الآمن.
     */
    fun allocate(d: WizardDraft): AllocationReport? {
        val (first, tr) = run(d, d.autoExtend) ?: return null
        if (!tr.stalled) return first
        // التمديد لا ينفع: قصّ الجدول عند آخر يوم تقدّم فيه التراكم فعلًا وأبلغ بدل الادّعاء بالإكمال
        val origEnd = LocalDate.parse(d.endDate)
        val cut = tr.lastOldDay?.let { if (it.isAfter(origEnd)) it else origEnd } ?: origEnd
        val (r, _) = run(d.copy(endDate = cut.toString()), false) ?: return first
        val extra = ChronoUnit.DAYS.between(origEnd, cut).toInt()
        return r.copy(extensionBlocked = true, extendedDays = extra, notes = (r.notes + BLOCKED_MSG).distinct())
    }

    private fun run(d: WizardDraft, extend: Boolean): Pair<AllocationReport, ExtensionTracker>? {
        if (d.startDate.isBlank() || d.endDate.isBlank()) return null
        val start = try { LocalDate.parse(d.startDate) } catch (e: Exception) { return null }
        val end = try { LocalDate.parse(d.endDate) } catch (e: Exception) { return null }
        if (end < start) return null

        val days = mutableListOf<DayAllocation>()
        val notes = mutableListOf<String>()

        val backlogLeft = d.backlogs.toMutableMap()
        val placedOld = mutableMapOf<String, Int>()
        var cumOldMin = 0
        val totalOldNeededMin = d.backlogs.entries.sumOf { it.value * d.durOf(it.key) }
        var finishDate: LocalDate? = null
        val carriedNew = mutableListOf<String>()     // مواد نُشر جديدها في يوم راحة وينتظر أول يوم دراسة
        var carryHappened = false
        val plan = d.weekPlan
        val tr = ExtensionTracker(extend)

        var cur = start
        var lastDay = start
        while (true) {
            if (cur.isAfter(end) && !tr.shouldContinue(backlogLeft, placedOld)) break
            lastDay = cur
            val dayName = WizardConst.dayOfWeekName(cur.dayOfWeek)
            val published = if (d.oldOnly) emptyList()
                else d.subjects.filter { dayName in d.newDaysOf(it) }

            if (dayName in d.restDays) {
                if (published.isNotEmpty()) { carriedNew += published; carryHappened = true }
                days += DayAllocation(cur, dayName, 0, 0, 0, false, isRest = true)
                cur = cur.plusDays(1)
                continue
            }

            // 1) الجديد المستحق اليوم (+ ما انتقل من يوم راحة) بمدة كل مادة
            val newMin = (carriedNew + published).sumOf { d.durOf(it) }
            carriedNew.clear()

            // 2) الاختبارات المؤكدة اليوم (مدة معروفة فقط — لا نخترع مددًا)
            val examMin = d.exams.filter { it.day == dayName }.sumOf { it.durationMin ?: 0 }

            // 3) المتبقي للقديم
            val free = d.dailyStudyMin - newMin - examMin
            val oldMin = free.coerceAtLeast(0)
            if (free < 0) notes += "يوم $dayName ${cur}: الجديد والاختبارات (${newMin + examMin}د) تتجاوز الحد اليومي (${d.dailyStudyMin}د) — لا يتبقّى وقت للتراكم."

            // 4) توزيع القديم في المتبقي
            var room = oldMin
            // مع الجديد: حصة اليوم من التراكم بالتناسب مع سعته (توزيع متساوٍ)؛ بعد نهاية الفترة أو تراكمات فقط: ملء مباشر
            val quota = if (!d.oldOnly && !cur.isAfter(end))
                Leveling.quota(d, backlogLeft.entries.sumOf { it.value * d.durOf(it.key) }, cur, end) else Int.MAX_VALUE
            var oldToday = 0
            while (true) {
                if (oldToday >= quota) break
                val pick = backlogLeft
                    .filter { (s, n) -> n > 0 && d.durOf(s) <= room && d.oldAllowedOn(s, dayName) }
                    .maxByOrNull { it.value * d.durOf(it.key) } ?: break
                val dr = d.durOf(pick.key)
                backlogLeft[pick.key] = pick.value - 1
                placedOld[pick.key] = (placedOld[pick.key] ?: 0) + 1
                room -= dr
                oldToday += dr
                cumOldMin += dr
                tr.noteOldPlaced(cur)
                if (finishDate == null && cumOldMin >= totalOldNeededMin) finishDate = cur
            }

            days += DayAllocation(cur, dayName, newMin, examMin, oldMin - room, free < 0)
            cur = cur.plusDays(1)
        }

        if (carryHappened) notes += "محاضرات جديدة نُشرت في أيام راحة نُقلت إلى أول يوم دراسة تالٍ."
        if (carriedNew.isNotEmpty()) notes += "${carriedNew.size} محاضرة جديدة نُشرت في أيام راحة آخر الفترة ولا يوجد يوم دراسة بعدها داخل الفترة."

        val effEnd = if (tr.extDays > 0) lastDay else end
        if (tr.extDays > 0) notes += "الفترة لا تكفي فتمدّد الجدول ${tr.extDays} يومًا (≈ ${(tr.extDays + 6) / 7} أسبوعًا) حتى $effEnd."

        // تقرير كل مادة بالأرقام
        val subjects = d.subjects.map { s ->
            val old = d.backlogs[s] ?: 0
            val expectedNew = if (d.oldOnly) 0
                else WizardVerify.expectedNewLectures(start, effEnd, d.newDaysOf(s))
            val leftover = backlogLeft[s] ?: 0
            val fitted = old - leftover
            val dur = d.durOf(s)
            SubjectAllocation(s, old, expectedNew, old + expectedNew,
                expectedNew * dur, old * dur, fitted * dur, leftover)
        }
        val totalLeftover = subjects.sumOf { it.oldLeftover }
        val feasible = totalLeftover == 0 && d.backlogs.isNotEmpty()
        if (totalLeftover > 0) notes += "عجز: $totalLeftover محاضرة تراكم لا تُنجز ضمن الفترة" +
            (if (extend) " حتى بعد محاولة التمديد." else " — فعّل التمديد التلقائي أو أضف تواريخ.")
        if (d.oldOnly && plan.isNotEmpty()) d.undistributed().filter { (d.backlogs[it] ?: 0) > 0 }.forEach {
            notes += "مادة $it لها تراكم لكنها غير موزعة على أي يوم دراسة — لن يُجدول لها شيء."
        }
        if (d.backlogs.isEmpty()) notes += "لا توجد تراكمات — الخطة جديد فقط."

        val report = AllocationReport(days, subjects,
            days.count { !it.isRest } * d.dailyStudyMin, days.sumOf { it.newMin },
            days.sumOf { it.oldMin }, totalOldNeededMin,
            feasible, totalLeftover,
            if (feasible) finishDate else null, notes.distinct(),
            extendedDays = tr.extDays, effectiveEnd = effEnd, extensionBlocked = false)
        return report to tr
    }

    /** نص مختصر من التقرير يُدرج في البرومبت كحسابات مسبقة موثوقة. */
    fun reportSummary(r: AllocationReport): String = buildString {
        appendLine("=== الحسابات المسبقة من التطبيق (موثوقة — استخدمها) ===")
        r.subjects.forEach { s ->
            appendLine("- ${s.subject}: قديم ${s.oldCount} (وقتها ${s.oldMinNeeded}د) · جديد متوقع ${s.expectedNew} (وقتها ${s.newMinNeeded}د)" +
                if (s.oldLeftover > 0) " · ⚠ يتبقى ${s.oldLeftover} قديم غير قابل للإنجاز ضمن الفترة" else "")
        }
        appendLine("الإجمالي: دراسة متاحة ${r.totalStudyMin}د · جديد محمي ${r.totalNewMin}د · قديم موزع ${r.totalOldFittedMin}د من ${r.totalOldNeededMin}د مطلوبة" +
            if (!r.feasible && r.totalOldLeftover > 0) " · عجز ${r.totalOldLeftover} محاضرة" else "")
        r.estimatedFinishDate?.let { appendLine("تاريخ إنهاء التراكم المتوقع: $it") }
        appendLine("قاعدة التوزيع المعتمدة: يوم النشر يحجز وقت محاضرته الجديدة أولًا، ويملأ الوقت المتبقي بالتراكم الأكثر حجمًا.")
    }
}
