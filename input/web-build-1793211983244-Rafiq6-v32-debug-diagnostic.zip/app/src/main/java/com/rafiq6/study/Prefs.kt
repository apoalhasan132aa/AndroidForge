package com.rafiq6.study

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

val Context.ds by preferencesDataStore("rafiq6_settings")

data class Settings(
    val wakeMin: Int = 270, val sleepMin: Int = 1290,
    val schoolStart: Int = 450, val schoolEnd: Int = 780,
    val breakMin: Int = 15, val dailyGoalMin: Int = 720,
    val maxPostponeDays: Int = 7,
    val dark: Boolean = false, val fridayLight: Boolean = false,
    val outingDates: String = "",
    val focusExitDelaySec: Int = 10,   // تأخير زر إنهاء جلسة التركيز
    val focusPin: Boolean = true,      // تثبيت الشاشة أثناء الجلسة
    val focusDnd: Boolean = false,     // كتم إشعارات التطبيقات الأخرى (اختياري)
    val focusGuard: Boolean = true,    // حارس التركيز: يمنع الخروج من التطبيق المسموح حتى انتهاء المدة
    val dynamicColor: Boolean = true   // ألوان Material You الديناميكية (حسب خلفية الهاتف) — متاحة من أندرويد 12 فصاعدًا، وإلا تُستخدم ألوان رفيق الأصلية تلقائيًا
)

object Prefs {
    private val WAKE = intPreferencesKey("wake"); private val SLEEP = intPreferencesKey("sleep")
    private val SCHS = intPreferencesKey("schs"); private val SCHE = intPreferencesKey("sche")
    private val BRK = intPreferencesKey("brk"); private val GOAL = intPreferencesKey("goal")
    private val POSTPONE = intPreferencesKey("postpone")
    private val DARK = booleanPreferencesKey("dark"); private val FRI = booleanPreferencesKey("fri")
    private val OUT = stringPreferencesKey("outing")
    private val FED = intPreferencesKey("fed"); private val FPIN = booleanPreferencesKey("fpin")
    private val FDND = booleanPreferencesKey("fdnd")
    private val FG = booleanPreferencesKey("fg")
    private val DYN = booleanPreferencesKey("dyn")
    suspend fun get(c: Context): Settings { val p = c.ds.data.first(); return Settings(
        p[WAKE] ?: 270, p[SLEEP] ?: 1290, p[SCHS] ?: 450, p[SCHE] ?: 780, p[BRK] ?: 15,
        p[GOAL] ?: 720, p[POSTPONE] ?: 7, p[DARK] ?: false, p[FRI] ?: false, p[OUT] ?: "",
        p[FED] ?: 10, p[FPIN] ?: true, p[FDND] ?: false, p[FG] ?: true, p[DYN] ?: true) }
    suspend fun put(c: Context, s: Settings) { c.ds.edit {
        it[WAKE]=s.wakeMin; it[SLEEP]=s.sleepMin; it[SCHS]=s.schoolStart; it[SCHE]=s.schoolEnd
        it[BRK]=s.breakMin; it[GOAL]=s.dailyGoalMin; it[POSTPONE]=s.maxPostponeDays
        it[DARK]=s.dark; it[FRI]=s.fridayLight; it[OUT]=s.outingDates
        it[FED]=s.focusExitDelaySec; it[FPIN]=s.focusPin; it[FDND]=s.focusDnd; it[FG]=s.focusGuard
        it[DYN]=s.dynamicColor } }
    suspend fun addOuting(c: Context, date: String) { val s = get(c); if (date !in s.outingDates)
        put(c, s.copy(outingDates = (s.outingDates + "," + date).trim(','))) }
    suspend fun resetSettingsOnly(c: Context) { c.ds.edit { it.clear() } }
}
