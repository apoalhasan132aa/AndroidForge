package com.rafiq6.study

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class MainVm(app: Application) : AndroidViewModel(app) {
    val db = AppDb.get(app)
    private val _settings = MutableStateFlow(Settings()); val settings = _settings.asStateFlow()
    val all = db.dao().all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val timer = MutableStateFlow(TimerState())
    init { viewModelScope.launch {
        SeedImporter.importIfEmpty(app, db)
        _settings.value = Prefs.get(app)
        timer.value = StudyTimer.state(app)
        refreshAlarms()
    } }
    fun dayTasks(date: LocalDate): Flow<List<TaskEntity>> = db.dao().day(date.toString())
    fun refreshAlarms() = viewModelScope.launch {
        val today = Subjects.now().toLocalDate().toString()
        val list = db.dao().all().first()
        list.filter { it.date >= today }.forEach { AlarmScheduler.schedule(getApplication<Application>(), it) }
    }
    fun toggleDone(t: TaskEntity, done: Boolean) = viewModelScope.launch {
        val cur = db.dao().byId(t.id) ?: return@launch   // أحدث نسخة من القاعدة
        val n = if (!cur.done && done) cur.copy(done = true, doneAt = System.currentTimeMillis(),
                actualMin = cur.actualMin ?: cur.durationMin)
            else if (cur.done && !done) cur.copy(done = false, doneAt = null, actualMin = null)
            else return@launch // حماية من النقر المزدوج
        db.dao().upsert(n)
        if (done) { AlarmScheduler.cancel(getApplication(), n); StudyTimer.cancel(getApplication())
            Notify.notify(getApplication(), n.id.hashCode() + 1, "أحسنت! 🎉",
                "أنجزت «${n.title}». خطوة إضافية نحو هدفك.", null) }
        else { AlarmScheduler.schedule(getApplication(), n); refreshAlarms() }
    }
    fun updateTime(t: TaskEntity, startMin: Int, endMin: Int) = viewModelScope.launch {
        db.dao().upsert(t.copy(startMin = startMin, endMin = endMin)); refreshAlarms() }
    fun startTimer(t: TaskEntity) = viewModelScope.launch { StudyTimer.start(getApplication(), t.id)
        timer.value = StudyTimer.state(getApplication()) }
    fun pauseTimer() = viewModelScope.launch { StudyTimer.pause(getApplication())
        timer.value = StudyTimer.state(getApplication()) }
    fun resumeTimer() = viewModelScope.launch { StudyTimer.resume(getApplication())
        timer.value = StudyTimer.state(getApplication()) }
    fun finishTimer(onDone: (TaskEntity) -> Unit) = viewModelScope.launch {
        val r = StudyTimer.finish(getApplication()); timer.value = TimerState()
        if (r != null) { val t = db.dao().byId(r.first); if (t != null && !t.done) {
            val n = t.copy(actualMin = r.second); db.dao().upsert(n); onDone(n) } } }
    fun saveSettings(s: Settings) = viewModelScope.launch { Prefs.put(getApplication(), s); _settings.value = s }
    // الأنشطة الشخصية
    fun dayActs(date: LocalDate): Flow<List<ActivityEntity>> = db.act().day(date.toString())
    fun addActivity(a: ActivityEntity) = viewModelScope.launch { db.act().upsert(a) }
    fun toggleAct(a: ActivityEntity, v: Boolean) = viewModelScope.launch { db.act().upsert(a.copy(done = v)) }
    fun deleteAct(id: String) = viewModelScope.launch { db.act().delete(id) }
    fun postponeAct(a: ActivityEntity, to: LocalDate) = viewModelScope.launch {
        db.act().delete(a.id)
        db.act().upsert(a.copy(id = a.id + "-p" + to.dayOfYear, date = to.toString(),
            startMin = null, postponedFrom = a.date)) }
    fun stats(tasks: List<TaskEntity>): Stats {
        val done = tasks.filter { it.done }
        val byDay = tasks.groupBy { it.date }
        val best = byDay.maxByOrNull { e -> e.value.count { it.done } }
        var streak = 0; val dates = byDay.keys.sorted().reversed()
        val today = Subjects.now().toLocalDate().toString()
        for (d in dates) { val g = byDay[d]!!
            val pct = if (g.isEmpty()) 0 else 100 * g.count { it.done } / g.size
            if (pct >= 70) streak++ else if (d <= today) break }
        return Stats(tasks.size, done.size, done.sumOf { it.actualMin ?: 0 },
            done.groupBy { it.subject }.mapValues { e -> e.value.size }, streak, best?.key)
    }
}
data class Stats(val total: Int, val done: Int, val actualMin: Int,
                 val perSubject: Map<String, Int>, val streak: Int, val bestDay: String?)
