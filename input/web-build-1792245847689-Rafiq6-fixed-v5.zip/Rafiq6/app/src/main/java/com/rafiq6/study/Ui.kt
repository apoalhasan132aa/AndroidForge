package com.rafiq6.study

import android.content.Intent
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.edit
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.system.exitProcess

class MainActivity : ComponentActivity() {
    private val vm: MainVm by viewModels()
    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(b: Bundle?) { super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this,
                Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { App(vm, intent.getStringExtra("taskId")) } }
}

@Composable fun App(vm: MainVm, openTaskId: String?) {
    val s by vm.settings.collectAsState()
    MaterialTheme(colorScheme = if (s.dark) darkColorScheme() else lightColorScheme()) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize()) { RootNav(vm, openTaskId) } } } }

@Composable fun RootNav(vm: MainVm, openTaskId: String?) {
    var tab by remember { mutableStateOf(0) }
    val tasks by vm.all.collectAsState()
    var selDate by remember { mutableStateOf(Subjects.now().toLocalDate()) }
    Scaffold(bottomBar = { NavigationBar {
        listOf("اليوم","الجدول","التقويم","الإنجازات","الأنشطة","الإعدادات").forEachIndexed { i, l ->
            NavigationBarItem(selected = tab == i, onClick = { tab = i },
                icon = { Text("●") }, label = { Text(l) }) } } }) { pad ->
        Box(Modifier.padding(pad)) { when (tab) {
            0 -> HomeScreen(vm, tasks, openTaskId) { tab = 1 }
            1 -> DayScreen(vm, selDate, { selDate = it })
            2 -> CalendarScreen(vm, tasks) { selDate = it; tab = 1 }
            3 -> StatsScreen(vm, tasks)
            4 -> ActivitiesScreen(vm)
            5 -> SettingsScreen(vm)
        } } }
}

@Composable fun Clock(): Int { var now by remember { mutableStateOf(Subjects.now()) }
    LaunchedEffect(Unit) { while (true) { now = Subjects.now(); delay(1000) } }
    return now.hour * 60 + now.minute }

@Composable fun HomeScreen(vm: MainVm, tasks: List<TaskEntity>, openTaskId: String?, onShowAll: () -> Unit) {
    val today = Subjects.now().toLocalDate().toString()
    val dayTasks = tasks.filter { it.date == today }.sortedBy { it.startMin ?: 9999 }
    val nowMin = Clock()
    val cur = dayTasks.firstOrNull { !it.done && it.startMin != null && nowMin >= it.startMin!! && (it.endMin == null || nowMin < it.endMin!!) }
    val nxt = dayTasks.firstOrNull { !it.done && (it.startMin ?: 9999) > nowMin }
    val late = dayTasks.count { !it.done && it.endMin != null && nowMin >= it.endMin!! }
    val doneCnt = dayTasks.count { it.done }
    val pct = if (dayTasks.isEmpty()) 0 else 100 * doneCnt / dayTasks.size
    val actual = dayTasks.sumOf { it.actualMin ?: 0 }
    val timer by vm.timer.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("هسه — ${Subjects.fmt12(nowMin)}", style = MaterialTheme.typography.titleMedium)
            val shown = cur ?: nxt
            if (shown != null) {
                Text(shown.title, style = MaterialTheme.typography.headlineSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${Subjects.fmt12(shown.startMin!!)} إلى ${Subjects.fmt12(shown.endMin ?: (shown.startMin!! + shown.durationMin))} · ${shown.durationMin} دقيقة")
                val remain = if (cur != null) ((shown.endMin ?: 0) - nowMin).coerceAtLeast(0) else (shown.startMin!! - nowMin).coerceAtLeast(0)
                Text(if (cur != null) "المتبقي للانتهاء: ${remain/60}س ${remain%60}د" else "تبدأ بعد ${remain/60}س ${remain%60}د", style = MaterialTheme.typography.titleMedium)
                shown.note?.let { Text("⚠ $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (timer.running && timer.taskId == shown.id)
                        Row { Button(onClick = { vm.pauseTimer() }) { Text("إيقاف مؤقت") }
                            OutlinedButton(onClick = { vm.finishTimer { t -> vm.toggleDone(t, true) } }) { Text("إنهاء ✓") } }
                    else Row { OutlinedButton(onClick = { vm.startTimer(shown) }) { Text("بدأت المهمة") }
                        Button(onClick = { vm.toggleDone(shown, true) }) { Text("تم الإنجاز ✓") } } } }
            else Text(if (dayTasks.isEmpty()) "لا مهام اليوم" else "خلصت كل مهام اليوم — بطل! 🏆", style = MaterialTheme.typography.headlineSmall) } }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
            Text("إنجاز اليوم", style = MaterialTheme.typography.titleMedium)
            Text("$doneCnt من ${dayTasks.size} مهام · $pct%")
            LinearProgressIndicator(progress = { pct / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp))
            Text("دقائق الدراسة الفعلية: $actual · متبقية: ${dayTasks.size - doneCnt} · متأخرة: $late", style = MaterialTheme.typography.bodySmall) } }
        OutlinedButton(onClick = onShowAll, modifier = Modifier.fillMaxWidth()) { Text("عرض كل مهام اليوم (${dayTasks.size})") }
        Text("المهمة التالية: ${nxt?.let { "${it.title} — ${Subjects.fmt12(it.startMin!!)}" } ?: "لا شيء"}", style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable fun TaskCard(vm: MainVm, t: TaskEntity) {
    var editing by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Checkbox(checked = t.done, onCheckedChange = { vm.toggleDone(t, it) })
            Column(Modifier.weight(1f)) {
                Text(t.title, style = MaterialTheme.typography.titleSmall, maxLines = 3, overflow = TextOverflow.Visible,
                    color = if (t.done) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface)
                Text("${t.type} · ${t.subject}${t.lectureNo?.let { " · رقم $it" } ?: ""}", style = MaterialTheme.typography.bodySmall)
                Text(t.startMin?.let { "${Subjects.fmt12(it)} — ${Subjects.fmt12(t.endMin ?: it + t.durationMin)} · ${t.durationMin} دقيقة" } ?: "بدون موعد ثابت", style = MaterialTheme.typography.bodySmall)
                t.note?.let { Text("⚠ $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) } } }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (t.flexible) TextButton(onClick = { editing = true }) { Text("تعديل الموعد") }
            if (t.done) Text("✓ مكتملة${t.actualMin?.let { " · $it د فعلية" } ?: ""}", style = MaterialTheme.typography.bodySmall) } } }
    if (editing) AlertDialog(onDismissRequest = { editing = false },
        title = { Text("تعديل موعد المهمة") },
        text = { Text("المهمة: ${t.title}\nالموعد الحالي: ${t.startMin?.let { Subjects.fmt12(it) } ?: "—"}") },
        confirmButton = { TextButton(onClick = { val ns = ((t.startMin ?: 1200) + 60).coerceAtMost(1290); vm.updateTime(t, ns, ns + t.durationMin); editing = false }) { Text("أجّل ساعة") } },
        dismissButton = { TextButton(onClick = { editing = false }) { Text("إلغاء") } })
}

@Composable fun DayScreen(vm: MainVm, date: LocalDate, onDate: (LocalDate) -> Unit) {
    val tasks by remember(date) { vm.dayTasks(date) }.collectAsState(initial = emptyList())
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { onDate(date.minusDays(1)) }) { Text("السابق ›") }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(date.format(DateTimeFormatter.ofPattern("yyyy/MM/dd")), style = MaterialTheme.typography.titleMedium)
                Text(tasks.firstOrNull()?.dayName ?: "", style = MaterialTheme.typography.bodySmall) }
            TextButton(onClick = { onDate(date.plusDays(1)) }) { Text("‹ التالي") } }
        TextButton(onClick = { onDate(Subjects.now().toLocalDate()) }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("العودة لليوم الحالي") }
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tasks, key = { it.id }) { TaskCard(vm, it) } }
    }
}

@Composable fun CalendarScreen(vm: MainVm, tasks: List<TaskEntity>, onPick: (LocalDate) -> Unit) {
    var month by remember { mutableStateOf(Subjects.now().toLocalDate().withDayOfMonth(1)) }
    val byDate = tasks.groupBy { it.date }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { month = month.minusMonths(1) }) { Text("‹") }
            Text(month.format(DateTimeFormatter.ofPattern("MMMM yyyy")), style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { month = month.plusMonths(1) }) { Text("›") } }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("أحد","اثنين","ثلاثاء","أربعاء","خميس","جمعة","سبت").forEach { Text(it, style = MaterialTheme.typography.bodySmall) } }
        val first = month.dayOfWeek.value % 7; val len = month.lengthOfMonth()
        val today = Subjects.now().toLocalDate()
        for (r in 0..5) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            for (c in 0..6) { val cell = r * 7 + c; val dnum = cell - first + 1
                if (dnum in 1..len) { val d = month.withDayOfMonth(dnum); val ts = byDate[d.toString()] ?: emptyList()
                    val p = if (ts.isEmpty()) 0 else 100 * ts.count { it.done } / ts.size
                    val late = ts.any { !it.done && it.endMin != null && d < today }
                    TextButton(onClick = { onPick(d) }) {
                        Text("$dnum${if (p == 100) " ✅" else if (late) " ⚠" else if (p > 0) " ◐" else ""}",
                            color = if (d == today) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface) } }
                else Text(" ") } } }
        Text("✅ مكتمل · ◐ جزئي · ⚠ فيه مهام متأخرة", style = MaterialTheme.typography.bodySmall)
        TextButton(onClick = { onPick(today) }) { Text("اليوم الحالي") } }
}

@Composable fun StatsScreen(vm: MainVm, tasks: List<TaskEntity>) {
    val st = vm.stats(tasks)
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("الإنجازات", style = MaterialTheme.typography.headlineSmall)
        Text("المهام المكتملة: ${st.done} من ${st.total} (${if (st.total==0) 0 else 100*st.done/st.total}%)")
        Text("ساعات الدراسة الفعلية: ${st.actualMin/60}س ${st.actualMin%60}د")
        Text("سلسلة أيام الإنجاز (≥70%): ${st.streak} يوم 🔥")
        Text("أفضل يوم: ${st.bestDay ?: "—"}")
        Text("الإنجاز حسب المادة:", style = MaterialTheme.typography.titleMedium)
        st.perSubject.forEach { (sub, n) -> Text("• $sub: $n مهام منجزة") }
        Text("النقاط: ${st.done * 10} نقطة", style = MaterialTheme.typography.titleMedium)
        Text(listOf("استمر! كل محاضرة تكملها تقرّبك من القبول","اليوم استثمار في نفسك","الثبات يتفوق على الحماس").random(), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable fun ActivitiesScreen(vm: MainVm) {
    val today = Subjects.now().toLocalDate()
    val tasks by remember(today) { vm.dayTasks(today) }.collectAsState(initial = emptyList())
    val acts by remember(today) { vm.dayActs(today) }.collectAsState(initial = emptyList())
    var kind by remember { mutableStateOf("قراءة") }
    var title by remember { mutableStateOf("") }
    var dur by remember { mutableStateOf(30) }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("أنشطتي الشخصية (لا تُحسب ضمن ساعات الدراسة)", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("قراءة","ألعاب","مهارة").forEach { k -> FilterChip(selected = kind == k, onClick = { kind = k }, label = { Text(k) }) } }
        OutlinedTextField(value = title, onValueChange = { title = it }, modifier = Modifier.fillMaxWidth(), label = { Text("العنوان (اختياري)") })
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("المدة: $dur د"); Slider(value = dur.toFloat(), onValueChange = { dur = it.toInt() }, valueRange = 10f..90f) }
        Button(onClick = {
            val slot = ActivityPlanner.suggestSlot(tasks, acts, dur)
            val target = if (slot != null) today else today.plusDays(1)
            vm.addActivity(ActivityEntity("a${System.currentTimeMillis()}", target.toString(), kind,
                title.ifBlank { kind }, dur, slot, postponedFrom = if (slot == null) today.toString() else null))
            title = "" }, modifier = Modifier.fillMaxWidth()) { Text("إضافة لليوم (أو تأجيل تلقائي إذا انشغل اليوم)") }
        Text("أنشطة اليوم:", style = MaterialTheme.typography.titleSmall)
        acts.forEach { a -> Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = a.done, onCheckedChange = { vm.toggleAct(a, it) })
            Column(Modifier.weight(1f)) {
                Text("${a.kind}: ${a.title}", maxLines = 2, overflow = TextOverflow.Visible)
                Text(a.startMin?.let { "${Subjects.fmt12(it)} · ${a.durationMin} د" } ?: "بلا موعد (مرن)${a.postponedFrom?.let { " — مؤجلة من $it" } ?: ""}", style = MaterialTheme.typography.bodySmall) }
            TextButton(onClick = { vm.postponeAct(a, today.plusDays(1)) }) { Text("تأجيل") }
            TextButton(onClick = { vm.deleteAct(a.id) }) { Text("حذف") } } } }
        Text("ملاحظة: عند تفعيل «عندي طلعة اليوم» تُخفى الأنشطة المرنة، وتبقى الامتحانات في 7:00 مساءً كما هي.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable fun SettingsScreen(vm: MainVm) {
    val s by vm.settings.collectAsState(); val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineSmall)
        Text("الاستيقاظ: ${Subjects.fmt12(s.wakeMin)} · النوم: ${Subjects.fmt12(s.sleepMin)} · الاستراحة: ${s.breakMin} د")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.saveSettings(s.copy(breakMin = (s.breakMin + 5).let { if (it > 30) 5 else it })) }) { Text("الاستراحة: ${s.breakMin}د") }
            OutlinedButton(onClick = { vm.saveSettings(s.copy(dailyGoalMin = s.dailyGoalMin + 30)) }) { Text("الهدف اليومي: ${s.dailyGoalMin/60}س") } }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("الوضع الداكن"); Switch(checked = s.dark, onCheckedChange = { vm.saveSettings(s.copy(dark = it)) }) }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("جمعة أخف (إخفاء المرنة)"); Switch(checked = s.fridayLight, onCheckedChange = { vm.saveSettings(s.copy(fridayLight = it)) }) }
        val today = Subjects.now().toLocalDate().toString()
        OutlinedButton(onClick = { scope.launch { Prefs.addOuting(ctx, today) } }, modifier = Modifier.fillMaxWidth()) { Text("عندي طلعة اليوم (خميس) — إعادة ترتيب المرنة فقط") }
        Text("ملاحظة: الامتحانات الثابتة (7:00 مساءً) لا تُغيّر أبداً بخيار الطلعة.", style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = { scope.launch { Prefs.resetSettingsOnly(ctx); vm.saveSettings(Settings()) } }) { Text("إعادة ضبط الإعدادات (يحفظ الإنجازات)") }
        var confirmWipe by remember { mutableStateOf(false) }
        OutlinedButton(onClick = { confirmWipe = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("حذف جميع البيانات…") }
        if (confirmWipe) AlertDialog(onDismissRequest = { confirmWipe = false },
            title = { Text("تأكيد الحذف الكامل") },
            text = { Text("سيتم حذف كل المهام والإنجازات نهائياً. هذا الإجراء لا يمكن التراجع عنه.") },
            confirmButton = { TextButton(onClick = { scope.launch {
                AppDb.close(); ctx.deleteDatabase("rafiq6.db"); ctx.timerDs.edit { it.clear() }
                val i = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
                if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }
                exitProcess(0) } }) { Text("نعم، احذف") } },
            dismissButton = { TextButton(onClick = { confirmWipe = false }) { Text("تراجع") } })
        Text("إذا لم تصل الإشعارات: فعّل «المنبهات والتذكيرات الدقيقة» من إعدادات النظام › التطبيقات › رفيق السادس، وأوقف تقييد البطارية. لا ضمان 100% بسبب سياسات توفير الطاقة.",
            style = MaterialTheme.typography.bodySmall)
    }
}
