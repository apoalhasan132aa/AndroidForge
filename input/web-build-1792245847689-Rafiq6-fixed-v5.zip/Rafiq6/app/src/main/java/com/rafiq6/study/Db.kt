package com.rafiq6.study

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import org.json.JSONObject

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks WHERE date=:d ORDER BY COALESCE(startMin, 9999)") fun day(d: String): Flow<List<TaskEntity>>
    @Query("SELECT * FROM tasks ORDER BY date, COALESCE(startMin,9999)") fun all(): Flow<List<TaskEntity>>
    @Query("SELECT * FROM tasks WHERE id=:id") suspend fun byId(id: String): TaskEntity?
    @Query("SELECT COUNT(*) FROM tasks") suspend fun count(): Int
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(t: TaskEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(l: List<TaskEntity>)
}

@Dao
interface ActivityDao {
    @Query("SELECT * FROM activities WHERE date=:d ORDER BY COALESCE(startMin,9999)") fun day(d: String): Flow<List<ActivityEntity>>
    @Query("SELECT * FROM activities ORDER BY date") fun all2(): Flow<List<ActivityEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(a: ActivityEntity)
    @Query("DELETE FROM activities WHERE id=:id") suspend fun delete(id: String)
}

@Database(entities = [TaskEntity::class, ActivityEntity::class], version = 2, exportSchema = true)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): TaskDao
    abstract fun act(): ActivityDao
    companion object {
        private val M1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS activities (id TEXT PRIMARY KEY NOT NULL, date TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, durationMin INTEGER NOT NULL, startMin INTEGER, done INTEGER NOT NULL, postponedFrom TEXT)")
            }
        }
        @Volatile private var I: AppDb? = null
        fun get(c: Context): AppDb = I ?: synchronized(this) {
            I ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "rafiq6.db")
                .addMigrations(M1_2)
                .build().also { I = it }
        }
        fun close() = synchronized(this) { I?.close(); I = null }
    }
}

object SeedImporter {
    suspend fun importIfEmpty(ctx: Context, db: AppDb) {
        if (db.dao().count() > 0) return
        val json = JSONObject(ctx.assets.open("schedule.json").bufferedReader().readText())
        val list = mutableListOf<TaskEntity>()
        val days = json.getJSONArray("days")
        for (i in 0 until days.length()) {
            val d = days.getJSONObject(i)
            val date = d.getString("date"); val wd = d.getString("wd")
            val arr = d.getJSONArray("tasks")
            for (j in 0 until arr.length()) {
                val t = arr.getJSONObject(j)
                val flex = t.optBoolean("flex", false)
                val st = if (t.isNull("st")) (if (flex) 20 * 60 else null) else Subjects.toMin(t.getString("st"))
                val en = if (t.isNull("en")) (if (flex) 20 * 60 + 45 else null) else Subjects.toMin(t.getString("en"))
                list += TaskEntity(
                    t.getString("id"), date, wd, t.getString("s"), t.getString("ty"),
                    t.getString("t"), if (t.isNull("lec")) null else t.getInt("lec"),
                    t.getInt("dur"), st, en, flex,
                    if (t.isNull("note")) null else t.getString("note")
                )
            }
        }
        db.dao().insertAll(list)
    }
}
