package com.rafiq6.study

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.datastore.preferences.core.edit
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Shapes
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import kotlin.system.exitProcess

class MainActivity : ComponentActivity() {
    private val vm: MainVm by viewModels()
    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(b: Bundle?) { super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this,
                Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { App(vm, intent.getStringExtra("taskId")) } }
}

private val LightColors = lightColorScheme(
    primary = Color(0xFF3A6EA5), onPrimary = Color.White,
    primaryContainer = Color(0xFFD4E4F5), onPrimaryContainer = Color(0xFF0F2A44),
    secondary = Color(0xFF4C7A5C), surface = Color(0xFFF7F9FC),
    surfaceVariant = Color(0xFFE8EEF5), background = Color(0xFFF7F9FC))
private val DarkColors = darkColorScheme(
    primary = Color(0xFFA8C8EC), onPrimary = Color(0xFF0F2A44),
    primaryContainer = Color(0xFF28425E), onPrimaryContainer = Color(0xFFD4E4F5),
    secondary = Color(0xFF9CC7AC), surface = Color(0xFF11161D),
    surfaceVariant = Color(0xFF1C2530), background = Color(0xFF11161D))
// زوايا أكثر استدارة بكل شاشات التطبيق (بطاقات، حوارات، أزرار) لمظهر أعصرن — تغيير مظهر فقط،
// لا يمسّ أي منطق أو بيانات. يُطبَّق تلقائيًا على كل Card/AlertDialog/Button بلا تعديل كل شاشة لوحدها.
private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp), small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(22.dp), extraLarge = RoundedCornerShape(28.dp))

@Composable fun App(vm: MainVm, openTaskId: String?) {
    val s by vm.settings.collectAsState()
    MaterialTheme(colorScheme = if (s.dark) DarkColors else LightColors, shapes = AppShapes) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize()) {
                val pdfRequest by vm.pdfViewerRequest.collectAsState()
                val request = pdfRequest
                if (request != null) PdfViewerScreen(vm, request) { vm.closePdfPage() }
                else RootNav(vm, openTaskId)
            }
        }
    }
}

@Composable fun RootNav(vm: MainVm, openTaskId: String?) {
    // خمسة عناصر رئيسية فقط حتى تبقى الواجهة صالحة على شاشات الهواتف الصغيرة.
    // شاشة واحدة هي مصدر الحقيقة للتنقل، وشريط التبويبات يشتق اختياره منها.
    // 0 اليوم، 1 الجدول اليومي، 2 التقويم، 3 الإنجازات، 4 المزيد، 5 الجداول، 6 البنك، 7 الاختبار، 8 الإتقان، 9 الإعدادات، 10 الأنشطة، 11 التركيز، 12 صانع الجدول السنوي.
    var screen by remember { mutableStateOf(0) }
    val tabSel = when (screen) { 0 -> 0; 1, 2, 3 -> 1; 6 -> 2; 8 -> 3; else -> 4 }
    val bundle by vm.bundle.collectAsState(initial = ScheduleBundle())
    val tasks = bundle.tasks
    var selDate by remember { mutableStateOf(Subjects.now().toLocalDate()) }

    // أيقونات تعبيرية بدل النقطة الموحّدة "●" حتى يُميَّز كل تبويب بصريًا من أول نظرة — بلا أي مكتبة أيقونات
    // خارجية جديدة (صفر مخاطرة بناء إضافية).
    val tabIcons = listOf("🏠", "🗓️", "📚", "🎯", "☰")
    Scaffold(bottomBar = { NavigationBar {
        listOf("اليوم","الجدول","البنك","الإتقان","المزيد").forEachIndexed { i, l ->
            NavigationBarItem(
                selected = tabSel == i,
                onClick = { screen = when (i) { 0 -> 0; 1 -> 1; 2 -> 6; 3 -> 8; else -> 4 } },
                icon = {
                    val scale by animateFloatAsState(if (tabSel == i) 1.15f else 1f, tween(180), label = "tabScale")
                    Text(tabIcons[i], fontSize = (16 * scale).sp)
                },
                label = { Text(l, maxLines = 1) }
            )
        }
    } }) { pad ->
        Box(Modifier.padding(pad)) {
            // انتقال ناعم (تلاشي + انزلاق خفيف) بين الشاشات بدل التبديل الفجائي — تحسين شكل فقط لكل تنقل
            // بالتطبيق، لا يغيّر أي شاشة من داخلها.
            AnimatedContent(targetState = screen, label = "screenTransition",
                transitionSpec = { (fadeIn(tween(220)) + slideInHorizontally(tween(220)) { w -> w / 10 })
                    .togetherWith(fadeOut(tween(140)) + slideOutHorizontally(tween(140)) { w -> -w / 10 }) }
            ) { s ->
                when (s) {
                    0 -> HomeScreen(vm, tasks, openTaskId, onShowAll = { screen = 1 }, onFocus = { screen = 11 }, onWizard = { screen = 12 })
                    1 -> DayScreen(vm, tasks, selDate) { d -> selDate = d; screen = 1 }
                    2 -> CalendarScreen(vm, tasks) { d -> selDate = d; screen = 1 }
                    3 -> StatsScreen(vm, tasks)
                    4 -> MoreScreen { index -> screen = index }
                    5 -> SchedulesScreen(vm)
                    6 -> PdfBankScreen(vm)
                    7 -> SelfQuizScreen(vm)
                    8 -> MasteryScreen(vm, tasks)
                    9 -> SettingsScreen(vm, tasks)
                    10 -> ActivitiesScreen(vm, tasks)
                    11 -> FocusHubScreen(vm, tasks)
                    12 -> ScheduleBuilderHubScreen(vm)
                }
            }
        }
    }
}

@Composable private fun MoreScreen(onPick: (Int) -> Unit) {
    val items = listOf(
        2 to "التقويم",
        3 to "الإنجازات",
        10 to "الأنشطة الشخصية",
        11 to "وضع التركيز (محاضرة بدون مشتّتات)",
        12 to "📅 إنشاء / تغيير الجدول السنوي",
        5 to "الجداول واستيراد JSON",
        7 to "اختبر نفسي",
        9 to "الإعدادات وإعادة الجدولة"
    )
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("المزيد", style = MaterialTheme.typography.headlineSmall)
        Text("اختار القسم المطلوب؛ العناصر الرئيسية الباقية موجودة في شريط التنقل السفلي.")
        items.forEach { (index, label) ->
            Card(Modifier.fillMaxWidth()) {
                TextButton(onClick = { onPick(index) }, modifier = Modifier.fillMaxWidth()) {
                    Text(label, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable fun Clock(): Int { var now by remember { mutableStateOf(Subjects.now()) }
    LaunchedEffect(Unit) { while (true) { now = Subjects.now(); delay(1000) } }
    return now.hour * 60 + now.minute }

@Composable fun HomeScreen(vm: MainVm, tasks: List<UiTask>, openTaskId: String?,
                           onShowAll: () -> Unit, onFocus: () -> Unit = {}, onWizard: () -> Unit = {}) {
    val todayL = Subjects.now().toLocalDate()
    val today = todayL.toString()
    val dayTasks = tasks.filter { it.date == today }.sortedBy { it.startMin ?: 9999 }
    val nowMin = Clock()
    val doneCnt = dayTasks.count { it.done }
    val pct = if (dayTasks.isEmpty()) 0 else 100 * doneCnt / dayTasks.size
    val cur = dayTasks.firstOrNull { !it.done && it.startMin != null && nowMin >= it.startMin!! && (it.endMin == null || nowMin < it.endMin!!) }
    val nxt = dayTasks.firstOrNull { !it.done && (it.startMin ?: 9999) > nowMin }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // ترحيب + تاريخ
        Text(when (Subjects.now().hour) { in 5..11 -> "صباح الخير"; in 12..17 -> "مساء الخير"; else -> "ليلة سعيدة" } + " 👋",
            style = MaterialTheme.typography.headlineSmall)
        Text("${todayL.dayOfMonth}/${todayL.monthValue}/${todayL.year} · ${WizardConst.dayOfWeekName(todayL.dayOfWeek)}",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

        if (tasks.isEmpty()) {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("🗓️", style = MaterialTheme.typography.displayLarge)
                Text("ما عندك جدول بعد", style = MaterialTheme.typography.titleLarge)
                Text("أنشئ جدولك السنوي بدقيقة: اختر موادك، حدد تراكماتك، وزّعها على أيامك.")
                Button(onClick = onWizard) { Text("إنشاء الجدول السنوي 📅") }
            } }
        } else {
            // تقدم اليوم — نسبة متحركة بدل قفزة فجائية عند تغيّر الإنجاز، نفس الرقم المحسوب كما هو.
            val animatedPct by animateFloatAsState(pct / 100f, tween(500, easing = FastOutSlowInEasing), label = "dayProgress")
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row { Text("تقدم اليوم", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("$pct%", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer) }
                LinearProgressIndicator(progress = { animatedPct }, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)))
                Text("$doneCnt من ${dayTasks.size} مهام", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
            } }
            // المهمة الحالية/التالية
            if (cur != null) Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("الآن 🔴", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                Text("${cur.title} — ${cur.subject}", style = MaterialTheme.typography.titleMedium)
                Text("${Subjects.fmt12(cur.startMin ?: nowMin)} → ${cur.endMin?.let { Subjects.fmt12(it) } ?: "…"} · ${cur.durationMin} د",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } } else if (nxt != null) Text("المهمة التالية: ${nxt.title} — ${Subjects.fmt12(nxt.startMin!!)}",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

            // بطاقات مهام اليوم (أول 5) — نفس تمييز اللون/الشارة المستخدم في شاشة الجدول (taskVisual) حتى يكون
            // التمييز بين الجديد/التراكم/الاختبار/المكتملة موحّدًا بكل شاشات التطبيق، لا شاشة لوحدها.
            dayTasks.take(5).forEach { t ->
                val visual = taskVisual(t)
                Card(onClick = { vm.toggleDone(t, !t.done) }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.width(8.dp).height(8.dp).background(visual.color, androidx.compose.foundation.shape.CircleShape))
                        Text(t.title, Modifier.weight(1f).padding(horizontal = 8.dp),
                            maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                        Text("${t.durationMin}د", style = MaterialTheme.typography.bodySmall, color = visual.color)
                        Checkbox(checked = t.done, onCheckedChange = { vm.toggleDone(t, it) })
                    } }
            }
            if (dayTasks.size > 5) TextButton(onClick = onShowAll) { Text("عرض كل مهام اليوم (${dayTasks.size}) ›") }
            DueReviewsCard(vm)
        }
        // وصول سريع
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onFocus, modifier = Modifier.weight(1f)) { Text("🎯 تركيز") }
            OutlinedButton(onClick = onWizard, modifier = Modifier.weight(1f)) { Text("📅 صانع الجدول") }
            OutlinedButton(onClick = onShowAll, modifier = Modifier.weight(1f)) { Text("📆 الأسبوع") }
        }
    }
}
/**
 * لقطة تمييز بصري لنوع المهمة (جديد/تراكم/اختبار/مكتملة/أخرى): لون مميّز + شارة نصية قصيرة،
 * تُستخدم في TaskCard وفي تجميع DayScreen، حتى يفرّق المستخدم بينها بسرعة من أول نظرة دون قراءة النص.
 */
private data class TaskVisual(val badge: String, val color: Color, val groupLabel: String, val groupOrder: Int)

private fun taskVisual(t: UiTask): TaskVisual = when {
    t.done -> TaskVisual("✓ مكتملة", Color(0xFF6B7280), "مكتملة", 4)
    t.type == TaskTypes.NEW -> TaskVisual("🆕 جديد", Color(0xFF2E7D4F), "جديد", 0)
    t.type == TaskTypes.OLD -> TaskVisual("🔁 تراكم", Color(0xFFC77A1F), "تراكم", 1)
    TaskTypes.isAssessment(t.type) -> TaskVisual("📝 اختبار", Color(0xFF8E3B8E), "اختبارات", 2)
    else -> TaskVisual("•", MaterialTheme.colorScheme.outline, "أخرى", 3)
}

@Composable fun TaskCard(vm: MainVm, t: UiTask) {
    var editing by remember { mutableStateOf(false) }
    val settings by vm.settings.collectAsState()
    val visual = taskVisual(t)

    // سحب أفقي: يمين = إنجاز سريع، يسار = فتح تعديل الموعد — بديل تفاعلي سريع عن الضغط على الأزرار.
    // offsetX حالة بسيطة (غير متحركة) أثناء السحب الفعلي، وتُرجَع بحركة ناعمة (animate) بعد رفع الإصبع؛
    // هذا تغيير بالتفاعل والعرض فقط، الإجراءات نفسها (toggleDone/فتح نافذة التعديل) موجودة مسبقًا بالتطبيق.
    var offsetX by remember { mutableStateOf(0f) }
    val density = LocalDensity.current
    val thresholdPx = with(density) { 84.dp.toPx() }
    val maxPx = thresholdPx * 1.4f
    val dragState = rememberDraggableState { delta -> offsetX = (offsetX + delta).coerceIn(-maxPx, maxPx) }

    Box(Modifier.fillMaxWidth()) {
        if (!t.done) Row(Modifier.matchParentSize().clip(RoundedCornerShape(16.dp))) {
            Box(Modifier.weight(1f).fillMaxHeight()
                .background(Color(0xFF2E7D4F).copy(alpha = (offsetX / thresholdPx).coerceIn(0f, 1f))),
                contentAlignment = Alignment.CenterStart) {
                if (offsetX > 12f) Text("  ✓ إنجاز", color = Color.White, style = MaterialTheme.typography.labelLarge)
            }
            Box(Modifier.weight(1f).fillMaxHeight()
                .background(Color(0xFF3A6EA5).copy(alpha = (-offsetX / thresholdPx).coerceIn(0f, 1f))),
                contentAlignment = Alignment.CenterEnd) {
                if (offsetX < -12f) Text("تعديل ✎  ", color = Color.White, style = MaterialTheme.typography.labelLarge)
            }
        }
    Card(Modifier.fillMaxWidth()
        .offset { IntOffset(offsetX.roundToInt(), 0) }
        .draggable(state = dragState, orientation = Orientation.Horizontal,
            onDragStopped = {
                val swiped = offsetX
                if (swiped > thresholdPx && !t.done) vm.toggleDone(t, true)
                else if (swiped < -thresholdPx) editing = true
                animate(offsetX, 0f, animationSpec = tween(220, easing = FastOutSlowInEasing)) { v, _ -> offsetX = v }
            })
    ) { Row(Modifier.fillMaxWidth()) {
        // شريط لوني رفيع يميّز نوع المهمة من أول نظرة (يُعكس تلقائيًا بالاتجاه RTL).
        Box(Modifier.width(4.dp).fillMaxHeight().background(visual.color))
        Column(Modifier.padding(12.dp).weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Checkbox(checked = t.done, onCheckedChange = { vm.toggleDone(t, it) })
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(color = visual.color.copy(alpha = 0.15f), contentColor = visual.color,
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(6.dp)) {
                        Text(visual.badge, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
                Text(t.title, style = MaterialTheme.typography.titleSmall, maxLines = 3, overflow = TextOverflow.Visible,
                    color = if (t.done) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface)
                Text("${t.type} · ${t.subject}${t.lectureNo?.let { " · رقم $it" } ?: ""}", style = MaterialTheme.typography.bodySmall)
                Text(t.startMin?.let { "${Subjects.fmt12(it)} — ${Subjects.fmt12(t.endMin ?: it + t.durationMin)} · ${t.durationMin} دقيقة" } ?: "بدون موعد ثابت", style = MaterialTheme.typography.bodySmall)
                if (t.fixed) Text("مهمة ثابتة محمية", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                t.rescheduleReason?.let { Text("↩ $it", style = MaterialTheme.typography.bodySmall) }
                t.note?.let { Text("⚠ $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { editing = true }) { Text("تعديل الموعد") }
            TextButton(onClick = { vm.toggleFixed(t, !t.fixed) }) { Text(if (t.fixed) "إلغاء التثبيت" else "تثبيت المهمة") }
            if (t.done) Text("✓ مكتملة${t.actualMin?.let { " · $it د فعلية" } ?: ""}", style = MaterialTheme.typography.bodySmall)
        }
    } } } }
    if (editing) {
        val latestLimit = (settings.sleepMin - t.durationMin).coerceAtLeast(settings.wakeMin)
        var startValue by remember { mutableStateOf((t.startMin ?: 20 * 60).coerceIn(settings.wakeMin, latestLimit).toFloat()) }
        AlertDialog(onDismissRequest = { editing = false },
            title = { Text("تعديل موعد المهمة") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المهمة: ${t.title}")
                Text("البداية: ${Subjects.fmt12(startValue.toInt())} — النهاية: ${Subjects.fmt12(startValue.toInt() + t.durationMin)}")
                Slider(value = startValue, onValueChange = { startValue = it }, valueRange = settings.wakeMin.toFloat()..latestLimit.toFloat())
                Text("لن يقبل التطبيق موعدًا بعد وقت النوم المحدد.", style = MaterialTheme.typography.bodySmall)
            } },
            confirmButton = { TextButton(onClick = {
                val ns = startValue.toInt().coerceIn(settings.wakeMin, latestLimit)
                vm.updateTime(t, ns, ns + t.durationMin); editing = false
            }) { Text("حفظ الموعد") } },
            dismissButton = { TextButton(onClick = { editing = false }) { Text("إلغاء") } })
    }
}

@Composable fun DayScreen(vm: MainVm, allTasks: List<UiTask>, date: LocalDate, onDate: (LocalDate) -> Unit) {
    val tasks = allTasks.filter { it.date == date.toString() }.sortedBy { it.startMin ?: 9999 }
    // تجميع بصري حسب نوع المهمة (جديد أولًا ثم تراكم ثم اختبارات ثم مكتملة/أخرى)، مع الحفاظ على ترتيب
    // الوقت داخل كل مجموعة — هذا عرض فقط، لا يغيّر مواعيد المهام المحفوظة فعليًا.
    val groups = tasks.groupBy { taskVisual(it) }.toSortedMap(compareBy { it.groupOrder })
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { onDate(date.minusDays(1)) }) { Text("السابق ›") }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(date.format(DateTimeFormatter.ofPattern("yyyy/MM/dd")), style = MaterialTheme.typography.titleMedium)
                Text(tasks.firstOrNull()?.dayName ?: ScheduleParser.weekday(date), style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = { onDate(date.plusDays(1)) }) { Text("‹ التالي") }
        }
        TextButton(onClick = { onDate(Subjects.now().toLocalDate()) }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("العودة لليوم الحالي") }
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            groups.forEach { (visual, groupTasks) ->
                item(key = "header-${visual.groupLabel}") {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(top = 4.dp)) {
                        Box(Modifier.width(10.dp).height(10.dp).background(visual.color, androidx.compose.foundation.shape.CircleShape))
                        Text("${visual.groupLabel} (${groupTasks.size})", style = MaterialTheme.typography.titleSmall, color = visual.color)
                    }
                }
                items(groupTasks, key = { it.id }) { TaskCard(vm, it) }
            }
        }
    }
}

@Composable fun CalendarScreen(vm: MainVm, tasks: List<UiTask>, onPick: (LocalDate) -> Unit) {
    var month by remember { mutableStateOf(Subjects.now().toLocalDate().withDayOfMonth(1)) }
    val byDate = tasks.groupBy { it.date }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { month = month.minusMonths(1) }) { Text("‹") }
            Text(month.format(DateTimeFormatter.ofPattern("MMMM yyyy")), style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { month = month.plusMonths(1) }) { Text("›") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("أحد","اثنين","ثلاثاء","أربعاء","خميس","جمعة","سبت").forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
        val first = month.dayOfWeek.value % 7; val len = month.lengthOfMonth()
        val today = Subjects.now().toLocalDate()
        for (r in 0..5) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            for (c in 0..6) { val cell = r * 7 + c; val dnum = cell - first + 1
                if (dnum in 1..len) { val d = month.withDayOfMonth(dnum); val ts = byDate[d.toString()] ?: emptyList()
                    val p = if (ts.isEmpty()) 0 else 100 * ts.count { it.done } / ts.size
                    val late = ts.any { !it.done && it.endMin != null && d < today }
                    TextButton(onClick = { onPick(d) }) {
                        Text("$dnum${if (p == 100) " ✅" else if (late) " ⚠" else if (p > 0) " ◐" else ""}",
                            color = if (d == today) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    }
                } else Text(" ") }
        } }
        Text("✅ مكتمل · ◐ جزئي · ⚠ فيه مهام متأخرة", style = MaterialTheme.typography.bodySmall)
        TextButton(onClick = { onPick(today) }) { Text("اليوم الحالي") }
    }
}

@Composable fun StatsScreen(vm: MainVm, tasks: List<UiTask>) {
    val st = vm.stats(tasks)
    val donePct = if (st.total == 0) 0 else 100 * st.done / st.total
    val animatedDonePct by animateFloatAsState(donePct / 100f, tween(600, easing = FastOutSlowInEasing), label = "statsProgress")
    val maxSubject = (st.perSubject.maxOfOrNull { it.value } ?: 0).coerceAtLeast(1)

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("الإنجازات", style = MaterialTheme.typography.headlineSmall)

        // بطاقة الإنجاز الكلي — شريط متحرك بدل رقم نص فقط
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row { Text("المهام المكتملة", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("$donePct%", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer) }
                LinearProgressIndicator(progress = { animatedDonePct }, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)))
                Text("${st.done} من ${st.total} مهمة", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }

        // ثلاث بطاقات صغيرة لأهم الأرقام بدل سطور نص متتالية
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                "⏱️" to "${st.actualMin / 60}س ${st.actualMin % 60}د" to "دراسة فعلية",
                "🔥" to "${st.streak} يوم" to "سلسلة ≥70%",
                "⭐" to "${st.done * 10}" to "نقطة"
            ).forEach { (top, label) ->
                val (emoji, value) = top
                Card(Modifier.weight(1f)) { Column(Modifier.padding(10.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(emoji, style = MaterialTheme.typography.titleLarge)
                    Text(value, style = MaterialTheme.typography.titleSmall)
                    Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } }
            }
        }
        Text("أفضل يوم: ${st.bestDay ?: "—"}", style = MaterialTheme.typography.bodyMedium)

        // الإنجاز حسب المادة — أشرطة أفقية متحركة نسبيًا لأكبر مادة، بدل نقاط نصية
        Text("الإنجاز حسب المادة", style = MaterialTheme.typography.titleMedium)
        st.perSubject.forEach { (sub, n) ->
            val ratio by animateFloatAsState(n / maxSubject.toFloat(), tween(600, easing = FastOutSlowInEasing), label = "subj-$sub")
            Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                Row { Text(sub, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium); Text("$n") }
                LinearProgressIndicator(progress = { ratio }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp)),
                    color = MaterialTheme.colorScheme.secondary)
            }
        }

        Text(listOf("استمر! كل محاضرة تكملها تقرّبك من القبول","اليوم استثمار في نفسك","الثبات يتفوق على الحماس").random(),
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable fun ActivitiesScreen(vm: MainVm, tasks: List<UiTask>) {
    val today = Subjects.now().toLocalDate()
    val acts by remember(today) { vm.dayActs(today) }.collectAsState(initial = emptyList())
    var kind by remember { mutableStateOf("قراءة") }
    var title by remember { mutableStateOf("") }
    var dur by remember { mutableStateOf(30) }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("أنشطتي الشخصية (لا تُحسب ضمن ساعات الدراسة)", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("قراءة","ألعاب","مهارة").forEach { k -> FilterChip(selected = kind == k, onClick = { kind = k }, label = { Text(k) }) }
        }
        OutlinedTextField(value = title, onValueChange = { title = it }, modifier = Modifier.fillMaxWidth(), label = { Text("العنوان (اختياري)") })
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("المدة: $dur د"); Slider(value = dur.toFloat(), onValueChange = { dur = it.toInt() }, valueRange = 10f..90f)
        }
        Button(onClick = {
            val slot = ActivityPlanner.suggestSlot(tasks.map { it.task }, acts, dur)
            val target = if (slot != null) today else today.plusDays(1)
            vm.addActivity(ActivityEntity("a${System.currentTimeMillis()}", target.toString(), kind,
                title.ifBlank { kind }, dur, slot, postponedFrom = if (slot == null) today.toString() else null))
            title = ""
        }, modifier = Modifier.fillMaxWidth()) { Text("إضافة لليوم (أو تأجيل تلقائي إذا انشغل اليوم)") }
        Text("أنشطة اليوم:", style = MaterialTheme.typography.titleSmall)
        acts.forEach { a -> Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = a.done, onCheckedChange = { vm.toggleAct(a, it) })
            Column(Modifier.weight(1f)) {
                Text("${a.kind}: ${a.title}", maxLines = 2, overflow = TextOverflow.Visible)
                Text(a.startMin?.let { "${Subjects.fmt12(it)} · ${a.durationMin} د" } ?: "بلا موعد (مرن)${a.postponedFrom?.let { " — مؤجلة من $it" } ?: ""}", style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = { vm.postponeAct(a, today.plusDays(1)) }) { Text("تأجيل") }
            TextButton(onClick = { vm.deleteAct(a.id) }) { Text("حذف") }
        } } }
    }
}

private fun parseDateOrNull(value: String): LocalDate? = try {
    if (value.isBlank()) null else LocalDate.parse(value.trim())
} catch (e: DateTimeParseException) { null }

private suspend fun writeFileToUri(ctx: Context, uri: Uri, file: File) {
    ctx.contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { input -> input.copyTo(output) } }
        ?: throw IllegalStateException("تعذر فتح ملف الوجهة.")
}

private fun shareJsonFile(ctx: Context, file: File, title: String) {
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/json"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, title)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(intent, "مشاركة الملف").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable fun SchedulesScreen(vm: MainVm) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val schedules by vm.schedules.collectAsState()
    val bundle by vm.bundle.collectAsState(initial = ScheduleBundle())
    var showCreate by remember { mutableStateOf(false) }
    var showAi by remember { mutableStateOf(false) }
    var importText by remember { mutableStateOf("") }
    var importResult by remember { mutableStateOf<ScheduleParseResult?>(null) }
    var replaceId by remember { mutableStateOf<String?>(null) }
    var confirmReplace by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var dupOf by remember { mutableStateOf<ScheduleEntity?>(null) }
    var restoreText by remember { mutableStateOf<String?>(null) }
    var restorePreview by remember { mutableStateOf<BackupParseResult?>(null) }
    var restoreCurrent by remember { mutableStateOf<BackupSummary?>(null) }
    val doImport: (Boolean) -> Unit = { allow ->
        scope.launch {
            val r = vm.importSchedule(importText, null, allow)
            if (r.ok) { message = "تم الاستيراد كجدول جديد."; importResult = null }
            else message = "فشل الاستيراد — لم يُحفظ شيء: " + r.errorText()
        }
        Unit
    }

    val openScheduleImport = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                importText = ctx.contentResolver.openInputStream(uri)!!.bufferedReader().readText()
                importResult = ScheduleParser.parse(importText)
                replaceId = null
                message = ""
            } catch (e: Exception) {
                importResult = null
                message = "تعذر قراءة الملف: ${e.message ?: "خطأ غير معروف"}"
            }
        }
    }
    val exportScheduleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            try { writeFileToUri(ctx, uri, vm.exportSchedule(ctx, null)); message = "تم تصدير الجدول بنجاح." }
            catch (e: Exception) { message = "فشل التصدير: ${e.message ?: "خطأ غير معروف"}" }
        }
    }
    val exportBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            try { writeFileToUri(ctx, uri, Backup.export(ctx)); message = "تم إنشاء النسخة الاحتياطية." }
            catch (e: Exception) { message = "فشل إنشاء النسخة: ${e.message ?: "خطأ غير معروف"}" }
        }
    }
    val importBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val text = ctx.contentResolver.openInputStream(uri)!!.bufferedReader().readText()
                val pr = Backup.preview(text)      // فحص فقط — لا كتابة قبل تأكيدك
                if (!pr.ok) message = "فشل الاسترجاع — لم يتغير شيء:\n" + pr.errorText()
                else { restoreCurrent = Backup.currentSummary(ctx); restorePreview = pr; restoreText = text }
            } catch (e: Exception) { message = "فشل الاسترجاع — لم يتغير شيء: ${e.message ?: "ملف غير صالح"}" }
        }
    }

    if (showAi) { AiScheduleScreen(onBack = { showAi = false }); return }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("الجداول", style = MaterialTheme.typography.headlineSmall)
        Text("الجدول النشط: ${bundle.schedule?.name ?: "لا يوجد"}", style = MaterialTheme.typography.titleMedium)

        Button(onClick = { showCreate = true }, modifier = Modifier.fillMaxWidth()) { Text("إنشاء جدول جديد") }
        OutlinedButton(onClick = { openScheduleImport.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("استيراد جدول من ملف") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { exportScheduleLauncher.launch("rafiq_schedule_v1.json") }, modifier = Modifier.weight(1f)) { Text("تصدير جدولي") }
            OutlinedButton(onClick = { scope.launch { runCatching { shareJsonFile(ctx, vm.exportSchedule(ctx, null), "جدول رفيق") }.onFailure { message = it.message ?: "تعذر المشاركة" } } }, modifier = Modifier.weight(1f)) { Text("مشاركة/نسخ الملف") }
        }
        OutlinedButton(onClick = { showAi = true }, modifier = Modifier.fillMaxWidth()) { Text("أنشئ جدولك بالذكاء الاصطناعي") }

        Text("النسخ الاحتياطي الكامل:", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { exportBackupLauncher.launch("rafiq6-full-backup.json") }, modifier = Modifier.weight(1f)) { Text("إنشاء نسخة") }
            OutlinedButton(onClick = { importBackupLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) { Text("استرجاع نسخة") }
        }

        if (message.isNotBlank()) Text(message, color = if (message.startsWith("فشل") || message.startsWith("تعذر")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)

        importResult?.let { result ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("معاينة الاستيراد", style = MaterialTheme.typography.titleMedium)
                val file = result.file
                if (file != null && result.ok) {
                    Text("الاسم: ${file.meta.name}")
                    Text("الفترة: ${file.startDate ?: "غير محددة"} → ${file.endDate ?: "غير محددة"}")
                    Text("عدد الأيام: ${file.days.size} · عدد المهام: ${file.taskCount()}")
                    if (result.warnings.isNotEmpty()) Text("تحذيرات:\n${result.warningText()}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    Text("اختر طريقة الاستيراد:", style = MaterialTheme.typography.titleSmall)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = replaceId == null, onClick = { replaceId = null })
                        Text("إضافة كجدول جديد")
                    }
                    schedules.forEach { s ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = replaceId == s.scheduleId, onClick = { replaceId = s.scheduleId })
                            Text("استبدال «${s.name}»")
                        }
                    }
                    Button(onClick = { if (replaceId == null) scope.launch { val d = vm.duplicateOf(importText); if (d != null) dupOf = d else doImport(false) } else confirmReplace = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (replaceId == null) "تأكيد الاستيراد" else "استبدال الجدول المحدد…")
                    }
                } else {
                    Text("لا يمكن استيراد الملف. صحّح الأخطاء التالية:", color = MaterialTheme.colorScheme.error)
                    Text(result.errorText(), style = MaterialTheme.typography.bodySmall)
                }
            } }
        }

        Text("الجداول الموجودة:", style = MaterialTheme.typography.titleMedium)
        if (schedules.isEmpty()) Text("لا توجد جداول بعد.")
        schedules.forEach { s ->
            Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(s.name, style = MaterialTheme.typography.titleSmall)
                    Text("${s.startDate ?: "—"} → ${s.endDate ?: "—"}${if (s.active) " · نشط" else ""}", style = MaterialTheme.typography.bodySmall)
                }
                if (!s.active) TextButton(onClick = { vm.activateSchedule(s.scheduleId) }) { Text("تفعيل") }
            } }
        }
    }

    if (showCreate) {
        var name by remember { mutableStateOf("") }
        var alias by remember { mutableStateOf("") }
        var stage by remember { mutableStateOf("") }
        var country by remember { mutableStateOf("") }
        var start by remember { mutableStateOf("") }
        var end by remember { mutableStateOf("") }
        var error by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { showCreate = false },
            title = { Text("إنشاء جدول جديد") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم الجدول") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = alias, onValueChange = { alias = it }, label = { Text("اسم الطالب المستعار (اختياري)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = stage, onValueChange = { stage = it }, label = { Text("المرحلة الدراسية") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = country, onValueChange = { country = it }, label = { Text("البلد") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = start, onValueChange = { start = it }, label = { Text("تاريخ البداية YYYY-MM-DD") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = end, onValueChange = { end = it }, label = { Text("تاريخ النهاية YYYY-MM-DD") }, modifier = Modifier.fillMaxWidth())
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            } },
            confirmButton = { TextButton(onClick = {
                val sd = parseDateOrNull(start); val ed = parseDateOrNull(end)
                error = when {
                    name.isBlank() -> "اسم الجدول مطلوب."
                    start.isNotBlank() && sd == null -> "تاريخ البداية غير صالح."
                    end.isNotBlank() && ed == null -> "تاريخ النهاية غير صالح."
                    sd != null && ed != null && ed < sd -> "تاريخ النهاية يسبق البداية."
                    else -> ""
                }
                if (error.isBlank()) { vm.createSchedule(name, alias, stage, country, sd, ed); showCreate = false }
            }) { Text("إنشاء وتفعيل") } },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("إلغاء") } })
    }

    restorePreview?.let { pr ->
        val sm = pr.summary; val cur = restoreCurrent
        AlertDialog(onDismissRequest = { restorePreview = null; restoreText = null },
            title = { Text("تأكيد استرجاع النسخة") },
            text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("سيُستبدل كل ما في التطبيق بمحتوى النسخة (جداول، مهام، إنجازات، أنشطة، بنك أسئلة" +
                    (if (sm?.hasSettings == true) "، إعدادات" else "") + (if (sm?.focusSessions != null) "، سجل التركيز" else "") + ").")
                if (cur != null) Text("الحالي: ${cur.schedules} جداول · ${cur.tasks} مهمة · ${cur.doneTasks} منجزة · ${cur.activities} نشاط")
                if (sm != null) Text("في النسخة: ${sm.schedules} جداول · ${sm.tasks} مهمة · ${sm.doneTasks} منجزة · ${sm.activities} نشاط")
                if (pr.warnings.isNotEmpty()) Text("تنبيهات:\n" + pr.warnings.joinToString("\n") { "• $it" },
                    color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.bodySmall)
                Text("تُحفظ نسخة أمان تلقائية من وضعك الحالي داخل التطبيق قبل الاستبدال (pre-restore.json).", style = MaterialTheme.typography.bodySmall)
            } },
            confirmButton = { TextButton(onClick = {
                val text = restoreText; restorePreview = null; restoreText = null
                if (text != null) scope.launch {
                    val r = try { vm.restoreBackup(text) } catch (e: Exception) { null }
                    message = if (r != null && r.ok) "تم استرجاع النسخة الاحتياطية."
                    else "فشل الاسترجاع: " + (r?.errorText() ?: "خطأ غير متوقع أثناء الكتابة؛ راجع نسخة الأمان pre-restore.json")
                }
            }) { Text("استبدال واسترجاع") } },
            dismissButton = { TextButton(onClick = { restorePreview = null; restoreText = null }) { Text("إلغاء") } })
    }

    dupOf?.let { d -> AlertDialog(onDismissRequest = { dupOf = null },
        title = { Text("هذا الجدول مستورد سابقًا") },
        text = { Text("محتوى الملف مطابق تمامًا للجدول «${d.name}». يمكنك إلغاء الاستيراد، أو المتابعة كنسخة مستقلة (ستكون إنجازاتها منفصلة عن الجدول الموجود).") },
        confirmButton = { TextButton(onClick = { dupOf = null; doImport(true) }) { Text("متابعة كنسخة مستقلة") } },
        dismissButton = { TextButton(onClick = { dupOf = null; message = "أُلغي الاستيراد: الجدول مكرر."; importResult = null }) { Text("إلغاء الاستيراد") } }) }

    if (confirmReplace) AlertDialog(onDismissRequest = { confirmReplace = false },
        title = { Text("تأكيد استبدال الجدول") },
        text = { Text("سيتم حذف مهام الجدول المحدد واستبدالها بالملف الجديد. ستُنقل الإنجازات فقط عندما تتطابق المهمة بثقة عبر معرّف المصدر والمادة والنوع والعنوان والمدة. يُنصح بإنشاء نسخة احتياطية أولًا.") },
        confirmButton = { TextButton(onClick = {
            val target = replaceId
            scope.launch {
                val r = if (target != null) vm.importSchedule(importText, target) else null
                if (r == null || r.ok) { message = "تم استبدال الجدول."; importResult = null }
                else message = "فشل الاستبدال: " + r.errorText()
            }
            confirmReplace = false
        }) { Text("استبدال بعد الحفظ") } },
        dismissButton = { TextButton(onClick = { confirmReplace = false }) { Text("تراجع") } })
}

@Composable fun AiScheduleScreen(onBack: () -> Unit) {
    var stage by remember { mutableStateOf("") }
    var subjects by remember { mutableStateOf("") }
    var lectureCounts by remember { mutableStateOf("") }
    var teacherSchedule by remember { mutableStateOf("") }
    var durations by remember { mutableStateOf("") }
    var school by remember { mutableStateOf("") }
    var sleepWake by remember { mutableStateOf("") }
    var availableStudy by remember { mutableStateOf("") }
    var lightDays by remember { mutableStateOf("") }
    var range by remember { mutableStateOf("") }
    var fixedCommitments by remember { mutableStateOf("") }
    var preferences by remember { mutableStateOf("") }
    var copied by remember { mutableStateOf(false) }
    val ctx = LocalContext.current

    val prompt = buildString {
        appendLine("أنت مساعد جدولة دراسية. أنشئ ملف JSON فقط وفق صيغة rafiq_schedule_v1.")
        appendLine("اقرأ كل معلومات الطالب ومصادره المرفقة، ولا تخترع أي معلومة غير موجودة.")
        appendLine("استخرج المهام كما وردت في المصادر، ولا تغيّر عناوينها أو أرقام محاضراتها أو تواريخها إلا لضرورة زمنية موضحة.")
        appendLine("إذا كان هناك أكثر من امتحان في اليوم نفسه، رتّبهما بالتتابع من 19:00 بالمدد الفعلية الموجودة، ولا تسمح بتداخلهما.")
        appendLine("إذا كانت مدة امتحان غير موجودة، لا تخترعها؛ اجعلها غير محددة وأبلغ عن الحاجة إلى حسم المستخدم.")
        appendLine("ضع الصلاة والغداء والنوم والمدرسة والاستراحات كالتزامات أو قيود فقط إذا زودك الطالب بها، ولا تخترع أوقات صلاة.")
        appendLine("اكتشف تعارضات الامتحانات والمحاضرات والالتزامات، وأبلغ عن أي تعارض غير قابل للحسم بدل اتخاذ قرار صامت.")
        appendLine("تحقق من مجموع المهام وأرقام المحاضرات والتواريخ قبل الإخراج.")
        appendLine("أخرج JSON صالحًا فقط بلا شرح إضافي، أو JSON مع تقرير تحقق منفصل إذا طلب المستخدم ذلك.")
        appendLine("الحقول المطلوبة: format=rafiq_schedule، formatVersion=1، metadata، startDate، endDate، days[].date، days[].tasks[].id، subject، type، title، durationMin، وأوقات start/end عندما تكون ثابتة.")
        appendLine()
        appendLine("بيانات الطالب:")
        appendLine("- المرحلة والمواد: ${stage.ifBlank { "غير محددة" }}")
        appendLine("- أعداد المحاضرات الجديدة والتراكمية: ${lectureCounts.ifBlank { "غير محددة" }}")
        appendLine("- جدول المدرسين والامتحانات والواجبات: ${teacherSchedule.ifBlank { "غير محدد" }}")
        appendLine("- مدة المحاضرات وأوقات الامتحانات: ${durations.ifBlank { "غير محددة" }}")
        appendLine("- المدرسة والتنقل: ${school.ifBlank { "غير محدد" }}")
        appendLine("- النوم والاستيقاظ: ${sleepWake.ifBlank { "غير محدد" }}")
        appendLine("- الوقت المتاح للدراسة والاستراحات: ${availableStudy.ifBlank { "غير محدد" }}")
        appendLine("- الأيام الخفيفة أو العطل: ${lightDays.ifBlank { "غير محددة" }}")
        appendLine("- نطاق الجدول: ${range.ifBlank { "غير محدد" }}")
        appendLine("- الالتزامات الثابتة: ${fixedCommitments.ifBlank { "غير محددة" }}")
        appendLine("- تفضيلات وقيود إضافية: ${preferences.ifBlank { "غير محددة" }}")
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("أنشئ جدولك بالذكاء الاصطناعي", style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = onBack) { Text("رجوع") }
        }
        Text("التطبيق لا يتصل بأي خدمة ذكاء اصطناعي. أنشئ البرومبت هنا، انسخه، استخدمه في أي أداة خارجية، ثم استورد ملف JSON الناتج من صفحة الجداول. الاستيراد يعمل دون إنترنت.")
        OutlinedTextField(value = stage, onValueChange = { stage = it }, label = { Text("المرحلة الدراسية والمنهج والمواد") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = lectureCounts, onValueChange = { lectureCounts = it }, label = { Text("أعداد المحاضرات الجديدة والتراكمية لكل مادة") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = teacherSchedule, onValueChange = { teacherSchedule = it }, label = { Text("جدول المدرسين وأيام المحاضرات والامتحانات والواجبات") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = durations, onValueChange = { durations = it }, label = { Text("مدة المحاضرات وأوقات الامتحانات") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = school, onValueChange = { school = it }, label = { Text("المدرسة والتنقل") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = sleepWake, onValueChange = { sleepWake = it }, label = { Text("النوم والاستيقاظ") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = availableStudy, onValueChange = { availableStudy = it }, label = { Text("الوقت المتاح للدراسة والاستراحات") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = lightDays, onValueChange = { lightDays = it }, label = { Text("الأيام الخفيفة أو أيام العطلة") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = range, onValueChange = { range = it }, label = { Text("تاريخ البداية والنهاية") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = fixedCommitments, onValueChange = { fixedCommitments = it }, label = { Text("أوقات الالتزامات الثابتة") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = preferences, onValueChange = { preferences = it }, label = { Text("تفضيلاتك وأي قيود إضافية") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("برومبت إنشاء جدول رفيق", prompt))
            copied = true
        }, modifier = Modifier.fillMaxWidth()) { Text(if (copied) "تم النسخ ✓" else "توليد البرومبت ونسخه") }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
            Text("البرومبت الجاهز", style = MaterialTheme.typography.titleSmall)
            Text(prompt, style = MaterialTheme.typography.bodySmall)
        } }
    }
}

@Composable fun SettingsScreen(vm: MainVm, tasks: List<UiTask>) {
    val s by vm.settings.collectAsState(); val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val undo by vm.undoAvailable.collectAsState()
    var showOuting by remember { mutableStateOf(false) }
    var outingDate by remember { mutableStateOf(Subjects.now().toLocalDate().toString()) }
    var plan by remember { mutableStateOf<ReschedulePlan?>(null) }
    var outingError by remember { mutableStateOf("") }

    LaunchedEffect(showOuting) {
        if (showOuting) {
            val d = parseDateOrNull(outingDate) ?: Subjects.now().toLocalDate()
            outingDate = d.toString()
            plan = vm.planOuting(d, tasks)
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineSmall)
        Text("الاستيقاظ: ${Subjects.fmt12(s.wakeMin)} · النوم: ${Subjects.fmt12(s.sleepMin)} · الاستراحة: ${s.breakMin} د")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.saveSettings(s.copy(breakMin = (s.breakMin + 5).let { if (it > 30) 5 else it })) }) { Text("الاستراحة: ${s.breakMin}د") }
            OutlinedButton(onClick = { vm.saveSettings(s.copy(dailyGoalMin = ((s.dailyGoalMin + 30).let { if (it > 960) 300 else it }))) }) { Text("الهدف اليومي: ${s.dailyGoalMin/60}س") }
            OutlinedButton(onClick = { vm.saveSettings(s.copy(maxPostponeDays = ((s.maxPostponeDays + 1).let { if (it > 14) 1 else it }))) }) { Text("التأجيل: ${s.maxPostponeDays} يوم") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("الوضع الداكن"); Switch(checked = s.dark, onCheckedChange = { vm.saveSettings(s.copy(dark = it)) }) }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("جمعة أخف (إخفاء المرنة)"); Switch(checked = s.fridayLight, onCheckedChange = { vm.saveSettings(s.copy(fridayLight = it)) }) }

        OutlinedButton(onClick = { showOuting = true }, modifier = Modifier.fillMaxWidth()) { Text("عندي طلعة — معاينة وإعادة جدولة") }
        if (undo) OutlinedButton(onClick = { vm.undoOuting() }, modifier = Modifier.fillMaxWidth()) { Text("تراجع عن إعادة الجدولة الأخيرة") }

        OutlinedButton(onClick = { scope.launch { Prefs.resetSettingsOnly(ctx); vm.saveSettings(Settings()) } }) { Text("إعادة ضبط الإعدادات (يحفظ الإنجازات)") }
        var confirmWipe by remember { mutableStateOf(false) }
        OutlinedButton(onClick = { confirmWipe = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("حذف جميع البيانات…") }
        if (confirmWipe) AlertDialog(onDismissRequest = { confirmWipe = false },
            title = { Text("تأكيد الحذف الكامل") },
            text = { Text("سيتم حذف كل الجداول والمهام والإنجازات والأنشطة نهائيًا. هذا الإجراء لا يمكن التراجع عنه.") },
            confirmButton = { TextButton(onClick = { scope.launch {
                AppDb.close(); ctx.deleteDatabase("rafiq6.db"); ctx.ds.edit { it.clear() }
                val i = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
                if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }
                exitProcess(0)
            } }) { Text("نعم، احذف") } },
            dismissButton = { TextButton(onClick = { confirmWipe = false }) { Text("تراجع") } })
        Text("إذا لم تصل الإشعارات: فعّل «المنبهات والتذكيرات الدقيقة» من إعدادات النظام › التطبيقات › رفيق السادس، وأوقف تقييد البطارية. لا ضمان 100% بسبب سياسات توفير الطاقة.", style = MaterialTheme.typography.bodySmall)
    }

    if (showOuting) {
        val currentPlan = plan
        AlertDialog(onDismissRequest = { showOuting = false; plan = null },
            title = { Text("إعادة جدولة يوم طلعة") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = outingDate, onValueChange = {
                    outingDate = it
                    val d = parseDateOrNull(it)
                    if (d != null) { outingError = ""; plan = vm.planOuting(d, tasks) } else outingError = "صيغة التاريخ يجب أن تكون YYYY-MM-DD"
                }, label = { Text("تاريخ الطلعة") }, modifier = Modifier.fillMaxWidth())
                if (outingError.isNotBlank()) Text(outingError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                if (currentPlan == null) Text("جارٍ حساب المعاينة…")
                else {
                    Text("المهام المحمية: ${currentPlan.protectedTasks.size}")
                    currentPlan.protectedTasks.take(5).forEach { Text("• ${it.title}", style = MaterialTheme.typography.bodySmall) }
                    Text("المهام التي ستُنقل: ${currentPlan.moved.size}")
                    currentPlan.moved.take(8).forEach { Text("• ${it.title} → ${it.date} ${it.startMin?.let { m -> Subjects.fmt12(m) } ?: ""}", style = MaterialTheme.typography.bodySmall) }
                    if (currentPlan.hasUnplaced) {
                        Text("تعذر توزيع ${currentPlan.unplaced.size} مهام ضمن الحدود الحالية. سيبقى موعدها كما هو إذا طبّقت التغيير.", color = MaterialTheme.colorScheme.error)
                        currentPlan.unplaced.forEach { Text("• ${it.title}", style = MaterialTheme.typography.bodySmall) }
                    }
                    currentPlan.warnings.forEach { Text("⚠ $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            } },
            confirmButton = { TextButton(onClick = {
                val d = parseDateOrNull(outingDate)
                if (d != null) { vm.applyOuting(d, tasks); showOuting = false; plan = null }
            }) { Text("تطبيق ما أمكن") } },
            dismissButton = { TextButton(onClick = { showOuting = false; plan = null }) { Text("إلغاء") } })
    }
}
