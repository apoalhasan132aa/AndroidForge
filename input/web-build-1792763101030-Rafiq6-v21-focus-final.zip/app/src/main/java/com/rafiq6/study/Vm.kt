package com.rafiq6.study

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.util.UUID

class MainVm(app: Application) : AndroidViewModel(app) {
    val db = AppDb.get(app)
    private val _settings = MutableStateFlow(Settings()); val settings = _settings.asStateFlow()
    val timer = MutableStateFlow(TimerState())

    val bundle: Flow<ScheduleBundle> = combine(
        db.dao().activeSchedule(),
        db.dao().allTasks(),
        db.dao().allProgress()
    ) { schedule, tasks, progress ->
        if (schedule == null) ScheduleBundle(null, emptyList())
        else {
            val pmap = progress.associateBy { it.taskId }
            ScheduleBundle(schedule, tasks.filter { it.scheduleId == schedule.scheduleId }
                .map { UiTask(it, pmap[it.id]) })
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, ScheduleBundle())

    val schedules = db.dao().schedules().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val bankDocuments = db.bank().documents().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val bankQuestions = db.bank().questions().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val bankAttempts = db.bank().attempts().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val bankAnswers = db.bank().allAnswers().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val pdfViewerRequest = MutableStateFlow<OpenPdfRequest?>(null)
    val pdfViewerBitmap = MutableStateFlow<Bitmap?>(null)
    val pdfViewerError = MutableStateFlow<String?>(null)
    val undoAvailable = MutableStateFlow(false)
    val focus = MutableStateFlow(FocusState())
    val focusNotice = MutableStateFlow("")   // رسالة صريحة عند فشل تفعيل القفل الحقيقي
    val focusTotals = MutableStateFlow<Pair<Long, Long>?>(null)

    init { viewModelScope.launch {
        SeedImporter.ensureDefault(app, db)
        _settings.value = Prefs.get(app)
        timer.value = StudyTimer.state(app)
        focus.value = FocusStore.state(app)
        focusTotals.value = FocusHistory.totals(app)
        refreshAlarms()
        refreshUndoState()
    } }

    fun refreshUndoState() = viewModelScope.launch {
        val scheduleId = bundle.first().schedule?.scheduleId
        undoAvailable.value = scheduleId != null && db.dao().latestSnapshot(scheduleId) != null
    }

    fun refreshAlarms() = viewModelScope.launch {
        AlarmScheduler.scheduleUpcoming(getApplication<Application>(), bundle.first().tasks)
    }

    fun toggleDone(t: UiTask, done: Boolean) = viewModelScope.launch {
        val cur = db.dao().progressById(t.id) ?: ProgressEntity(t.id)
        val n = if (!cur.done && done) cur.copy(done = true, doneAt = System.currentTimeMillis(),
                actualMin = cur.actualMin ?: t.durationMin)
            else if (cur.done && !done) cur.copy(done = false, doneAt = null, actualMin = null)
            else return@launch
        db.dao().upsertProgress(n)
        if (done) { AlarmScheduler.cancel(getApplication(), t.task); StudyTimer.cancel(getApplication())
            Notify.notify(getApplication(), t.id.hashCode() + 1, "أحسنت! 🎉",
                "أنجزت «${t.title}». خطوة إضافية نحو هدفك.", null) }
        else refreshAlarms()
        WidgetRefresher.refresh(getApplication())
    }

    fun updateTime(t: UiTask, startMin: Int, endMin: Int) = viewModelScope.launch {
        val updated = t.task.copy(
            startMin = startMin, endMin = endMin,
            originalDate = t.originalDate ?: t.date,
            originalStartMin = t.originalStartMin ?: t.startMin,
            originalEndMin = t.originalEndMin ?: t.endMin,
            rescheduleReason = "تعديل يدوي من المستخدم"
        )
        AlarmScheduler.cancel(getApplication(), t.task)
        db.dao().upsertTask(updated)
        refreshAlarms()
    }

    fun toggleFixed(t: UiTask, fixed: Boolean) = viewModelScope.launch {
        db.dao().upsertTask(t.task.copy(fixed = fixed))
    }

    fun startTimer(t: UiTask) = viewModelScope.launch { StudyTimer.start(getApplication(), t.id)
        timer.value = StudyTimer.state(getApplication()) }
    fun pauseTimer() = viewModelScope.launch { StudyTimer.pause(getApplication())
        timer.value = StudyTimer.state(getApplication()) }
    fun resumeTimer() = viewModelScope.launch { StudyTimer.resume(getApplication())
        timer.value = StudyTimer.state(getApplication()) }
    fun finishTimer(onDone: (UiTask) -> Unit) = viewModelScope.launch {
        val r = StudyTimer.finish(getApplication()); timer.value = TimerState()
        if (r != null) { val t = bundle.first().tasks.firstOrNull { it.id == r.first }
            if (t != null && !t.done) { onDone(t) } } }
    fun saveSettings(s: Settings) = viewModelScope.launch { Prefs.put(getApplication(), s); _settings.value = s }

    // جلسة التركيز الإجباري
    fun startFocus(title: String, planMin: Int, allowed: List<String> = emptyList(), enforce: Boolean = false) =
        viewModelScope.launch { val a = getApplication<Application>()
            focusNotice.value = ""
            var s = FocusStore.start(a, title, planMin, allowed)
            FocusScheduler.arm(a, s)                      // المنبّه أولًا: النهاية مضمونة قبل أي قفل
            if (enforce) {
                if (FocusLockdown.begin(a, allowed)) { s = s.copy(enforced = true); FocusStore.save(a, s) }
                else focusNotice.value = "تعذّر تفعيل القفل الحقيقي (Lock Task) — الجلسة تعمل كمؤقت غير مُلزِم."
            }
            focus.value = s }

    fun endFocus(natural: Boolean) = viewModelScope.launch { val a = getApplication<Application>()
        // المصدر الحقيقي هو المخزن: قد يكون FocusEndReceiver أنهى الجلسة وسجّلها فلا نسجّلها مرة ثانية
        val s = FocusStore.state(a).takeIf { it.sessionId.isNotEmpty() } ?: FocusState()
        FocusScheduler.disarm(a)
        FocusLockdown.release(a)                           // فك التقييد دائمًا (لا أثر على جهاز غير مُدار)
        FocusGuardService.stop(a)                          // إيقاف حارس المنع بعد انتهاء الجلسة
        if (s.sessionId.isNotEmpty()) {
            FocusHistory.record(a, s); focusTotals.value = FocusHistory.totals(a)
            if (!natural) Notify.notify(a, 7102, "أنهيت جلسة التركيز",
                "«${s.title}» — ${s.planMin} دقيقة. لا بأس، الجلسة القادمة أقوى.", null)
            FocusStore.clear(a)
        }
        focus.value = FocusState() }

    fun refreshFocus() = viewModelScope.launch { val a = getApplication<Application>()
        focus.value = FocusStore.state(a); focusTotals.value = FocusHistory.totals(a) }

    // الأنشطة الشخصية
    fun dayActs(date: LocalDate): Flow<List<ActivityEntity>> = db.act().day(date.toString())
    fun addActivity(a: ActivityEntity) = viewModelScope.launch { db.act().upsert(a) }
    fun toggleAct(a: ActivityEntity, v: Boolean) = viewModelScope.launch { db.act().upsert(a.copy(done = v)) }
    fun deleteAct(id: String) = viewModelScope.launch { db.act().delete(id) }
    fun postponeAct(a: ActivityEntity, to: LocalDate) = viewModelScope.launch {
        db.act().delete(a.id)
        db.act().upsert(a.copy(id = a.id + "-p" + to.dayOfYear, date = to.toString(),
            startMin = null, postponedFrom = a.date)) }

    // الجداول
    fun createSchedule(name: String, alias: String?, stage: String?, country: String?, start: LocalDate?, end: LocalDate?) =
        viewModelScope.launch {
            val id = "custom-" + UUID.randomUUID().toString().take(8)
            db.dao().replaceSchedule(
                ScheduleEntity(
                    scheduleId = id,
                    name = name.ifBlank { "جدول جديد" },
                    studentAlias = alias,
                    stage = stage,
                    country = country,
                    startDate = start?.toString(),
                    endDate = end?.toString()
                ),
                emptyList(), emptyList()
            )
            refreshAlarms(); refreshUndoState()
        }

    /** جدول محفوظ محتواه مطابق تمامًا لهذا النص (أو null). لا يقارن الأسماء ولا التواريخ. */
    suspend fun duplicateOf(text: String): ScheduleEntity? {
        val file = ScheduleParser.parse(text).file ?: return null
        val hash = ScheduleFingerprint.ofFile(file)
        return db.dao().schedules().first().firstOrNull { s ->
            val h = s.contentHash ?: db.dao().tasksForOnce(s.scheduleId)
                .takeIf { it.isNotEmpty() }?.let { ScheduleFingerprint.ofEntities(it) }
            h == hash
        }
    }

    /**
     * allowDuplicate=false: إن وُجد جدول مطابق المحتوى يُرفض الاستيراد قبل أي حفظ برسالة واضحة.
     * الاستبدال الصريح (replaceScheduleId) لا يخضع لفحص التكرار لأن المستخدم اختار الهدف.
     * weekConstraints: لقطة «توزيع الأسبوع» من مسودة المعالج (إن جاء الاستيراد منها) — تُحفظ مع الجدول
     * لتُستخدم لاحقًا في إعادة الجدولة التلقائية (RescheduleEngine)، وليس فقط عند إنشاء الجدول أو عرضه.
     */
    suspend fun importSchedule(text: String, replaceScheduleId: String? = null, allowDuplicate: Boolean = false, weekConstraints: WeekPlanSnapshot? = null): ScheduleParseResult {
        val parsed = ScheduleParser.parse(text)
        val file = parsed.file ?: return parsed
        if (replaceScheduleId == null && !allowDuplicate) {
            duplicateOf(text)?.let { dup ->
                return ScheduleParseResult(null,
                    listOf(ValidationIssue("duplicate", "الملف مطابق تمامًا للجدول «${dup.name}» المستورد سابقًا. لم يُحفظ شيء.")),
                    parsed.warnings)
            }
        }
        val id = replaceScheduleId ?: "imported-" + UUID.randomUUID().toString().take(8)
        val entities = ScheduleParser.toEntities(id, file)
        // الجدول الجديد يصبح فعّالًا: ألغِ تنبيهات المستبدَل وتنبيهات الفعّال الحالي معًا
        replaceScheduleId?.let { AlarmScheduler.cancelAll(getApplication(), db.dao().tasksForOnce(it)) }
        bundle.first().schedule?.scheduleId?.let { AlarmScheduler.cancelAll(getApplication(), db.dao().tasksForOnce(it)) }
        val matchedProgress = if (replaceScheduleId != null) matchProgress(replaceScheduleId, entities) else emptyList()
        db.dao().replaceSchedule(
                ScheduleEntity(
                    scheduleId = id,
                    name = file.meta.name,
                    studentAlias = file.meta.studentAlias,
                    stage = file.meta.stage,
                    country = file.meta.country,
                    timeZone = file.meta.timeZone,
                    startDate = file.startDate?.toString(),
                    endDate = file.endDate?.toString(),
                    active = true,
                    contentHash = ScheduleFingerprint.ofFile(file),
                    weekPlanJson = weekConstraints?.let { WeekPlanSnapshot.toJson(it) }
                ),
                entities,
                matchedProgress
            )
        refreshAlarms(); refreshUndoState()
        return parsed
    }

    /** استرجاع آمن: فحص كامل ← إلغاء التنبيهات القديمة ← نسخة أمان ← تطبيق ← إعادة جدولة. أي خطأ في الفحص لا يمس شيئًا. */
    suspend fun restoreBackup(text: String): BackupParseResult {
        val app = getApplication<Application>()
        val parsed = BackupCodec.parse(text)
        val data = parsed.data
        if (!parsed.ok || data == null) return parsed
        db.dao().schedules().first().forEach { AlarmScheduler.cancelAll(app, db.dao().tasksForOnce(it.scheduleId)) }
        Backup.safetySnapshot(app)
        Backup.restore(app, data)
        _settings.value = Prefs.get(app); focusTotals.value = FocusHistory.totals(app)
        refreshAlarms(); refreshUndoState()
        return parsed
    }

    private suspend fun matchProgress(oldScheduleId: String, newTasks: List<TaskEntity>): List<ProgressEntity> {
        val oldTasks = db.dao().tasksForOnce(oldScheduleId)
        val oldBySource = oldTasks.associateBy { it.sourceId }
        val result = mutableListOf<ProgressEntity>()
        for (newTask in newTasks) {
            val old = oldBySource[newTask.sourceId] ?: continue
            // نقل الإنجاز فقط عند تطابق معرّف المصدر والمادة والنوع والعنوان والمدة.
            if (old.subject != newTask.subject || old.type != newTask.type ||
                old.title != newTask.title || old.durationMin != newTask.durationMin) continue
            db.dao().progressById(old.id)?.copy(taskId = newTask.id)?.let { result += it }
        }
        return result
    }

    fun activateSchedule(id: String) = viewModelScope.launch {
        // ألغِ منبهات الجدول الحالي قبل تفعيل جدول آخر حتى لا تبقى تنبيهات قديمة.
        bundle.first().tasks.forEach { AlarmScheduler.cancel(getApplication(), it.task) }
        db.dao().activateOnly(id); refreshAlarms(); refreshUndoState()
    }

    suspend fun exportSchedule(context: Context, scheduleId: String?): File {
        val schedule = scheduleId?.let { db.dao().scheduleById(it) }
            ?: bundle.first().schedule ?: throw IllegalStateException("لا يوجد جدول نشط للتصدير")
        val tasks = db.dao().tasksForOnce(schedule.scheduleId)
        val f = File(context.cacheDir, "exports/rafiq_schedule_v1.json")
        f.parentFile?.mkdirs()
        f.writeText(ScheduleParser.toJson(schedule, tasks).toString(2))
        return f
    }


    // بنك الأسئلة وملفات PDF
    suspend fun importPdf(ctx: Context, uri: Uri): PdfImportResult {
        val result = PdfImportService.import(ctx, uri)
        val doc = result.document ?: return result
        db.bank().importDocument(doc, result.pages)
        return result
    }

    fun deletePdfDocument(id: String) = viewModelScope.launch {
        val doc = db.bank().documentById(id) ?: return@launch
        PdfPageRenderer.clearCacheFor(getApplication(), doc.uri)
        db.bank().deleteDocument(id)
    }
    fun openPdfPage(document: PdfDocumentEntity, pageNumber: Int) {
        pdfViewerRequest.value = OpenPdfRequest(document, pageNumber)
    }
    fun closePdfPage() { pdfViewerRequest.value = null; pdfViewerBitmap.value = null; pdfViewerError.value = null }
    fun renderPdfPage(ctx: Context, request: OpenPdfRequest) = viewModelScope.launch {
        pdfViewerBitmap.value = null
        pdfViewerError.value = null
        try { pdfViewerBitmap.value = PdfPageRenderer.render(ctx, request.document.uri, request.pageNumber) }
        catch (e: SecurityException) { pdfViewerError.value = "لا يملك التطبيق صلاحية الوصول إلى الملف الأصلي. أعد استيراد PDF أو أعد منح الصلاحية." }
        catch (e: Exception) { pdfViewerError.value = "تعذر عرض الصفحة: ${e.message ?: "خطأ غير معروف"}" }
    }

    fun saveQuestion(q: QuestionEntity) = viewModelScope.launch { db.bank().upsertQuestion(q.copy(updatedAt = System.currentTimeMillis())) }
    fun deleteQuestion(id: String) = viewModelScope.launch { db.bank().deleteQuestion(id) }

    suspend fun startQuiz(subject: String?, topic: String?, limit: Int): Pair<ActiveQuiz?, String> {
        val selection = QuizSelector.select(bankQuestions.first(), subject, topic, limit)
        if (!selection.hasQuestions) return null to selection.message
        db.bank().activeAttempt()?.let { if (it.status == QuizStatus.ACTIVE) db.bank().upsertAttempt(it.copy(status = QuizStatus.DONE, finishedAt = System.currentTimeMillis())) }
        val attempt = QuizAttemptEntity(id = UUID.randomUUID().toString(), subject = subject, topic = topic, total = selection.questions.size)
        db.bank().upsertAttempt(attempt)
        return ActiveQuiz(attempt, selection.questions) to ""
    }

    suspend fun resumeQuiz(): Pair<ActiveQuiz?, String> {
        val attempt = db.bank().activeAttempt() ?: return null to "لا يوجد اختبار غير مكتمل."
        val answers = db.bank().answersForAttempt(attempt.id)
        if (answers.size >= attempt.total) {
            db.bank().upsertAttempt(attempt.copy(status = QuizStatus.DONE, finishedAt = attempt.finishedAt ?: System.currentTimeMillis()))
            return null to "الاختبار السابق مكتمل."
        }
        val answeredIds = answers.map { it.questionId }.toSet()
        val allQuestions = mutableListOf<QuestionEntity>()
        // نسترجع الأسئلة المجابة ثم نكمل بقية الأسئلة المطابقة بنفس ترتيب بنك الأسئلة.
        val answeredQuestions = answers.mapNotNull { db.bank().questionById(it.questionId) }
        val remaining = QuizSelector.select(bankQuestions.first(), attempt.subject, attempt.topic, 10000).questions
            .filter { it.id !in answeredIds && it.question.isNotBlank() }
        val reconstructed = QuizAttemptReconstruction.remainingOrder(answeredQuestions, remaining)
        allQuestions += reconstructed
        return ActiveQuiz(attempt, allQuestions.distinctBy { it.id }) to ""
    }

    suspend fun answerQuizQuestion(quiz: ActiveQuiz, index: Int, userAnswer: String, correct: Boolean): Pair<ActiveQuiz?, String> {
        val q = quiz.questions.getOrNull(index) ?: return quiz to "رقم السؤال غير صالح."
        val currentAttempt = db.bank().attemptById(quiz.attempt.id) ?: return quiz to "لم يعد الاختبار موجودًا."
        QuizAttemptPolicy.duplicateMessage(db.bank().answersForAttempt(currentAttempt.id), q.id)?.let {
            return ActiveQuiz(currentAttempt, quiz.questions) to it
        }
        if (userAnswer.isBlank()) return quiz to "اكتب محاولة إجابة أولًا حتى لو كانت غير مؤكدة."
        val (nextStage, nextAt) = ReviewScheduler.nextAfter(correct, q.reviewStage)
        db.bank().insertAnswer(AttemptAnswerEntity(
            id = UUID.randomUUID().toString(), attemptId = quiz.attempt.id, questionId = q.id,
            userAnswer = userAnswer.trim(), isCorrect = correct, previousStage = q.reviewStage,
            nextStage = nextStage, nextReviewAt = nextAt
        ))
        db.bank().upsertQuestion(QuestionStateUpdater.applyResult(q, correct))
        val updated = QuizResultRecorder.update(currentAttempt, correct)
        db.bank().upsertAttempt(updated.attempt)
        return if (updated.finished) null to "انتهى الاختبار." else ActiveQuiz(updated.attempt, quiz.questions) to ""
    }

    fun finishQuiz(attemptId: String) = viewModelScope.launch {
        db.bank().attemptById(attemptId)?.let { db.bank().upsertAttempt(it.copy(status = QuizStatus.DONE, finishedAt = System.currentTimeMillis())) }
    }

    // الطلعة وإعادة الجدولة
    // تُقرأ قيود «توزيع الأسبوع» (أيام الراحة وأيام كل مادة) من الجدول النشط نفسه إن كانت محفوظة معه،
    // حتى تُحترَم هذه الإعدادات عند إعادة الجدولة التلقائية لا عند إنشاء الجدول فقط.
    private fun activeWeekConstraints(): WeekPlanSnapshot? = WeekPlanSnapshot.fromJson(runBlocking { bundle.first() }.schedule?.weekPlanJson)

    fun planOuting(date: LocalDate, currentTasks: List<UiTask>): ReschedulePlan =
        RescheduleEngine.plan(currentTasks, date, settings.value, activeWeekConstraints())

    fun applyOuting(date: LocalDate, currentTasks: List<UiTask>) = viewModelScope.launch {
        val plan = RescheduleEngine.plan(currentTasks, date, settings.value, activeWeekConstraints())
        if (!plan.hasChanges) return@launch
        val scheduleId = bundle.first().schedule?.scheduleId ?: return@launch
        val affectedIds = (plan.moved.map { it.id } + plan.protectedTasks.map { it.id }).distinct()
        val snapshotTasks = currentTasks.filter { it.id in affectedIds }.map { it.task }
        val snapshotProgress = affectedIds.mapNotNull { db.dao().progressById(it) }
        val payload = JSONObject().apply {
            put("tasks", JSONArray().apply { snapshotTasks.forEach { put(JsonCodec.taskToJson(it)) } })
            put("progress", JSONArray().apply { snapshotProgress.forEach { put(JsonCodec.progressToJson(it)) } })
        }.toString()
        plan.moved.forEach { AlarmScheduler.cancel(getApplication(), it.task) }
        db.dao().insertSnapshot(RescheduleSnapshotEntity(
            id = UUID.randomUUID().toString(), scheduleId = scheduleId,
            createdAt = System.currentTimeMillis(), reason = "طلعة يوم $date", payload = payload
        ))
        plan.moved.forEach { db.dao().upsertTask(it.task) }
        Prefs.addOuting(getApplication(), date.toString())
        refreshAlarms(); refreshUndoState()
    }

    fun undoOuting() = viewModelScope.launch {
        val scheduleId = bundle.first().schedule?.scheduleId ?: return@launch
        val snapshot = db.dao().latestSnapshot(scheduleId) ?: return@launch
        val payload = JSONObject(snapshot.payload)
        val tasks = payload.getJSONArray("tasks").let { arr -> (0 until arr.length()).map { JsonCodec.taskFromJson(arr.getJSONObject(it)) } }
        val progress = if (payload.has("progress")) payload.getJSONArray("progress").let { arr -> (0 until arr.length()).map { JsonCodec.progressFromJson(arr.getJSONObject(it)) } } else emptyList()
        tasks.forEach { AlarmScheduler.cancel(getApplication(), it) }
        db.dao().insertTasks(tasks)
        progress.forEach { db.dao().upsertProgress(it) }
        db.dao().deleteSnapshot(snapshot.id)
        refreshAlarms(); refreshUndoState()
    }

    fun stats(tasks: List<UiTask>): StudyStats = StatsCalculator.calculate(tasks)
}
