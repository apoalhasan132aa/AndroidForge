package com.rafiq6.study

import android.app.AlarmManager
import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.Process
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

/**
 * حارس التركيز النسخة المعززة:
 * - فحص كل ثانية بدل ثانيتين، وإعادة فورية للتطبيق المسموح بأي محاولة خروج.
 * - كشف مزدوج للتطبيق الأمامي (أحداث الاستخدام + آخر وقت استخدام) فلا ينخدع.
 * - START_STICKY + نبضة دقيقية (GuardHeartbeat) تعيد تشغيله إذا قتلته إدارة الطاقة (MIUI).
 */
class FocusGuardService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    companion object {
        const val CH = "focus_guard"
        private const val NID = 7103
        @Volatile var isRunning = false; private set

        fun start(c: Context) { runCatching { ContextCompat.startForegroundService(c, Intent(c, FocusGuardService::class.java)) } }
        fun stop(c: Context) { runCatching { c.stopService(Intent(c, FocusGuardService::class.java)); FocusGuardHeartbeat.stop(c) } }

        /** فحص صحيح وفعّال لإذن «بيانات الاستخدام» عبر AppOps — فوري ولا نتائج مضللة. */
        fun usageGranted(c: Context): Boolean {
            val appOps = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
            else @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
            return mode == AppOpsManager.MODE_ALLOWED
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); isRunning = true }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "حارس التركيز",
            NotificationManager.IMPORTANCE_LOW).apply { description = "يمنع الخروج من التطبيق المسموح أثناء جلسة التركيز" })
        val pi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE)
        startForeground(NID, NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setContentTitle("جلسة تركيز جارية 🔒")
            .setContentText("الحارس يرجعك للتطبيق فورًا — اضغط هنا للعودة إلى رفيق")
            .setContentIntent(pi).setOngoing(true).build())

        job?.cancel()
        job = scope.launch {
            var lastRelaunch = 0L
            while (true) {
                val s = FocusStore.state(this@FocusGuardService)
                val nowE = SystemClock.elapsedRealtime(); val nowW = System.currentTimeMillis()
                if (!s.running || s.sessionId.isEmpty() || FocusMath.isExpired(s, nowE, nowW)) {
                    FocusGuardHeartbeat.stop(this@FocusGuardService)
                    stopSelf(); return@launch
                }
                if (usageGranted(this@FocusGuardService)) {
                    val top = topPackage()
                    if (top != null && top != packageName && top !in s.allowed && nowE - lastRelaunch > 1200) {
                        lastRelaunch = nowE
                        val target = s.allowed.firstOrNull()
                        if (target != null) FocusLockdown.launch(this@FocusGuardService, target, s.enforced)
                        else runCatching { startActivity(Intent(this@FocusGuardService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    }
                }
                delay(1000)
            }
        }
        return START_STICKY
    }

    /** التطبيق الأمامي الآن: أحداث الاستخدام (نافذة 30 ثانية) ثم آخر وقت استخدام كاحتياطي. */
    private fun topPackage(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        runCatching {
            val events = usm.queryEvents(now - 30_000, now)
            val e = UsageEvents.Event()
            var last: String? = null; var lastT = 0L
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                if ((e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                     e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) && e.timeStamp > lastT) {
                    last = e.packageName; lastT = e.timeStamp
                }
            }
            if (last != null && now - lastT < 15_000) return last
        }
        runCatching {
            val best = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 60_000, now)
                ?.filter { it.lastTimeUsed > 0 }?.maxByOrNull { it.lastTimeUsed }
            if (best != null && now - best.lastTimeUsed < 10_000) return best.packageName
        }
        return null
    }

    override fun onDestroy() { job?.cancel(); isRunning = false; super.onDestroy() }
}

/** نبضة كل دقيقة أثناء الجلسة: تعيد تشغيل الحارس إذا قتلته إدارة طاقة الروم. */
object FocusGuardHeartbeat {
    private const val REQ = 7104
    private fun pi(c: Context) = PendingIntent.getBroadcast(c, REQ,
        Intent(c, GuardHeartbeatReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun arm(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        runCatching {
            val trigger = System.currentTimeMillis() + 60_000
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi(c))
            else am.setWindow(AlarmManager.RTC_WAKEUP, trigger, 30_000, pi(c))
        }
    }
    fun stop(c: Context) { runCatching { (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c)) } }
}

class GuardHeartbeatReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val go = goAsync()
        try { runBlocking {
            val s = FocusStore.state(c)
            val alive = s.running && s.sessionId.isNotEmpty() &&
                !FocusMath.isExpired(s, SystemClock.elapsedRealtime(), System.currentTimeMillis())
            if (!alive) { FocusGuardService.stop(c) }
            else {
                if (!FocusGuardService.isRunning) FocusGuardService.start(c)   // إحياء بعد القتل
                FocusGuardHeartbeat.arm(c)                                       // الجولة التالية
            }
        } } finally { go.finish() }
    }
}
