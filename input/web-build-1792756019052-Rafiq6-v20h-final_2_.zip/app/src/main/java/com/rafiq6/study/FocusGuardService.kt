package com.rafiq6.study

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * حارس التركيز: خدمة أمامية تراقب التطبيق الظاهر أثناء الجلسة (عبر بيانات الاستخدام)
 * وتعيد فتح التطبيق المسموح فورًا إذا حاولت مغادرته — حتى انتهاء المدة.
 * لا تمنع زر الرجوع على مستوى النظام (هذا يتطلب Device Owner) لكنها تغلق كل مخارج العودة عمليًا.
 */
class FocusGuardService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    companion object {
        const val CH = "focus_guard"
        private const val NID = 7103
        fun start(c: Context) { runCatching { ContextCompat.startForegroundService(c, Intent(c, FocusGuardService::class.java)) } }
        fun stop(c: Context) { runCatching { c.stopService(Intent(c, FocusGuardService::class.java)) } }
        /** هل مُنح إذن «الوصول إلى بيانات الاستخدام»؟ بدونه لا نرى التطبيق الأمامي ولا تشتغل الحراسة. */
        fun usageGranted(c: Context): Boolean {
            val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            return runCatching { !usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 120_000, now).isNullOrEmpty() }
                .getOrDefault(false)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "حارس التركيز",
            NotificationManager.IMPORTANCE_LOW).apply { description = "يمنع الخروج من التطبيق المسموح أثناء جلسة التركيز" })
        val pi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE)
        startForeground(NID, NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setContentTitle("جلسة تركيز جارية 🔒")
            .setContentText("الحارس يمنع الخروج حتى انتهاء المدة — اضغط هنا للعودة إلى رفيق")
            .setContentIntent(pi).setOngoing(true).build())

        job?.cancel()
        job = scope.launch {
            var lastRelaunch = 0L
            while (true) {
                val s = FocusStore.state(this@FocusGuardService)
                val nowE = SystemClock.elapsedRealtime(); val nowW = System.currentTimeMillis()
                if (!s.running || s.sessionId.isEmpty() || FocusMath.isExpired(s, nowE, nowW)) { stopSelf(); return@launch }
                val top = if (usageGranted(this@FocusGuardService)) topPackage() else null
                if (top != null && top != packageName && top !in s.allowed && nowE - lastRelaunch > 3000) {
                    lastRelaunch = nowE
                    val target = s.allowed.firstOrNull()
                    if (target != null) FocusLockdown.launch(this@FocusGuardService, target, s.enforced)
                    else runCatching { startActivity(Intent(this@FocusGuardService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }
                delay(2000)
            }
        }
        return START_NOT_STICKY
    }

    /** آخر تطبيق انتقل للمقدمة خلال آخر 5 ثوانٍ (null إذا كانت الشاشة مطفأة). */
    private fun topPackage(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        return runCatching {
            val events = usm.queryEvents(now - 5000, now)
            val e = UsageEvents.Event()
            var last: String? = null
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                    e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) last = e.packageName
            }
            last
        }.getOrNull()
    }

    override fun onDestroy() { job?.cancel(); super.onDestroy() }
}
