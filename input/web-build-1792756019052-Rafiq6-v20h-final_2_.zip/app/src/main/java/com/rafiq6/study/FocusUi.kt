package com.rafiq6.study

import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable fun FocusHubScreen(vm: MainVm, tasks: List<UiTask>) {
    val f by vm.focus.collectAsState()
    var done by remember { mutableStateOf<FocusState?>(null) }
    var showApps by remember { mutableStateOf(false) }
    val totals by vm.focusTotals.collectAsState()
    val hubCtx = LocalContext.current
    LaunchedEffect(f.running) {
        val st = FocusStore.state(hubCtx)
        val over = !st.running || FocusMath.isExpired(st, SystemClock.elapsedRealtime(), System.currentTimeMillis())
        if (over && FocusLockdown.isDeviceOwner(hubCtx)) {
            FocusLockdown.release(hubCtx)
            val am = hubCtx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            if (am.lockTaskModeState != android.app.ActivityManager.LOCK_TASK_MODE_NONE)
                runCatching { (hubCtx as? Activity)?.stopLockTask() }
        }
    }
    val d = done
    when {
        showApps -> FocusAppsScreen(onClose = { showApps = false })
        d != null -> FocusDoneScreen(d, totals) { done = null }
        f.running -> FocusSessionScreen(vm) { finished -> done = finished }
        else -> FocusSetupScreen(vm, tasks) { showApps = true }
    }
}

@Composable private fun permStatus(ctx: Context): Triple<Boolean, Boolean, Boolean> {
    val notif = Build.VERSION.SDK_INT < 33 ||
        ctx.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val dnd = nm.isNotificationPolicyAccessGranted
    val exact = Build.VERSION.SDK_INT < 31 ||
        (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
    return Triple(notif, dnd, exact)
}

@Composable fun FocusSetupScreen(vm: MainVm, tasks: List<UiTask>, onOpenApps: () -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by vm.settings.collectAsState()
    val focus by vm.focus.collectAsState()
    val today = Subjects.now().toLocalDate().toString()
    val todays = tasks.filter { it.date == today && !it.done }.sortedBy { it.startMin ?: 9999 }
    var sel by remember { mutableStateOf<UiTask?>(null) }
    var freeTitle by remember { mutableStateOf("") }
    var dur by remember { mutableStateOf(25) }
    var custom by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    var allowedPkgs by remember { mutableStateOf<List<String>>(emptyList()) }
    var goneApps by remember { mutableStateOf<List<String>>(emptyList()) }
    var showSetup by remember { mutableStateOf(false) }
    val isOwner = FocusLockdown.isDeviceOwner(ctx)
    val mode = FocusPolicy.decide(isOwner, settings.focusPin)
    val notice by vm.focusNotice.collectAsState()
    LaunchedEffect(Unit) {
        val (ok, gone) = FocusLockdown.launchable(ctx, FocusAppsStore.allowedOf(ctx))
        allowedPkgs = ok; goneApps = gone
        if (gone.isNotEmpty()) FocusAppsStore.setAllowed(ctx, ok)
    }
    val totals by vm.focusTotals.collectAsState()
    var dayLog by remember { mutableStateOf<List<Pair<String, Int>>>(emptyList()) }
    LaunchedEffect(Unit) { dayLog = FocusHistory.lastNDays(ctx, 7) }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("وضع التركيز الإجباري", style = MaterialTheme.typography.headlineSmall)
        Text("جلسة محاضرة بمؤقت، مع تثبيت الشاشة (إن فعّلته) وتقليل المشتّتات. لا يجمع التطبيق أي بيانات استخدام.")

        if (focus.running) Card(Modifier.fillMaxWidth()) {
            Text("⚠ توجد جلسة نشطة حاليًا. أنهِها أولًا من شاشة الجلسة.", Modifier.padding(12.dp),
                color = MaterialTheme.colorScheme.error) }

        Text("1) اختر المحاضرة من جدول اليوم (أو اكتب مهمة حرة):", style = MaterialTheme.typography.titleSmall)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = sel == null, onClick = { sel = null })
                    Text("مهمة حرة")
                }
                OutlinedTextField(value = freeTitle, onValueChange = { freeTitle = it },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = sel == null, label = { Text("اسم المهمة (مثال: حل مسائل الفيزياء)") })
                todays.take(8).forEach { t ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = sel?.id == t.id, onClick = { sel = t; freeTitle = "" })
                        Text("${t.title} · ${t.durationMin} د", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                if (todays.isEmpty()) Text("لا مهام متبقية اليوم — استخدم مهمة حرة.", style = MaterialTheme.typography.bodySmall)
            }
        }

        Text("2) مدة الجلسة:", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(15, 25, 30, 45, 60, 90).forEach { m ->
                FilterChip(selected = dur == m && !custom, onClick = { dur = m; custom = false }, label = { Text("$m") })
            }
            FilterChip(selected = custom, onClick = { custom = true }, label = { Text("مخصص") })
        }
        if (custom) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("$dur دقيقة"); Slider(value = dur.toFloat(), onValueChange = { dur = it.toInt() },
                valueRange = 5f..180f, modifier = Modifier.fillMaxWidth())
        }

        Text("3) ملخص قبل البدء:", style = MaterialTheme.typography.titleSmall)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("المحاضرة: ${sel?.title ?: freeTitle.ifBlank { "جلسة تركيز" }}", style = MaterialTheme.typography.titleMedium)
            val endMin = (Subjects.now().hour * 60 + Subjects.now().minute + dur) % (24 * 60)
            Text("المدة: $dur دقيقة · تنتهي تقريبًا الساعة ${Subjects.fmt12(endMin)}")
        } }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = settings.focusPin, onCheckedChange = { v -> scope.launch { vm.saveSettings(settings.copy(focusPin = v)) } })
            Text("تثبيت الشاشة أثناء الجلسة (Screen Pinning — بموافقتك من النظام)")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = settings.focusDnd, onCheckedChange = { v -> scope.launch { vm.saveSettings(settings.copy(focusDnd = v)) } })
            Text("كتم إشعارات التطبيقات الأخرى أثناء الجلسة (عدم الإزعاج — اختياري)")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = settings.focusGuard, onCheckedChange = { v -> scope.launch { vm.saveSettings(settings.copy(focusGuard = v)) } })
            Text("منع الخروج من التطبيق حتى انتهاء المدة (حارس التركيز 🔒)")
        }
        if (settings.focusGuard && allowedPkgs.isNotEmpty() && !FocusGuardService.usageGranted(ctx))
            Text("⚠ ليعمل المنع: امنح «الوصول إلى بيانات الاستخدام» من إعدادات النظام (مرة واحدة فقط).",
                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("تأخير زر الإنهاء: ${settings.focusExitDelaySec} ثوانٍ")
            Slider(value = settings.focusExitDelaySec.toFloat(),
                onValueChange = { v -> scope.launch { vm.saveSettings(settings.copy(focusExitDelaySec = v.toInt())) } },
                valueRange = 5f..30f, modifier = Modifier.weight(1f).padding(start = 8.dp))
        }

        Text("التطبيقات المسموحة (حتى ${FocusSelection.MAX_APPS}):", style = MaterialTheme.typography.titleSmall)
        Text(if (allowedPkgs.isEmpty()) "رفيق فقط" else "رفيق + " + allowedPkgs.joinToString("، ") { FocusAppsStore.labelOf(ctx, it) })
        if (goneApps.isNotEmpty()) Text("⚠ أُزيل من الاختيار لأنه لم يعد مثبتًا/قابلًا للتشغيل: ${goneApps.joinToString("، ")}",
            color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = { onOpenApps() }, modifier = Modifier.fillMaxWidth()) { Text("اختيار / تعديل التطبيقات") }

        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("إحصائيات التركيز 📊", style = MaterialTheme.typography.titleSmall)
            totals?.let { Text("الإجمالي: ${it.first} جلسة · ${it.second} دقيقة تركيز", style = MaterialTheme.typography.bodySmall) }
            if (dayLog.any { it.second > 0 }) {
                FocusWeekChart(dayLog)
                Text("اليوم: ${dayLog.last().second} د · هذا الأسبوع: ${dayLog.sumOf { it.second }} د",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else Text("لا جلسات مسجلة بعد — ابدأ أول جلسة وستظهر هنا.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } }

        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("آلية التقييد على هذا الجهاز:", style = MaterialTheme.typography.titleSmall)
            when (mode) {
                FocusMode.LOCK_TASK_ALLOWLIST -> Text("✅ قفل حقيقي (Lock Task): يُمنع فتح أي تطبيق خارج المسموحين حتى ينتهي المؤقت.")
                FocusMode.SCREEN_PIN_SELF -> Text("⚠ يُفتح التطبيق المختار مباشرة. التطبيق لا يستطيع تثبيته عنك: بعد الفتح اضغط زر التطبيقات الأخيرة ثم أيقونة التطبيق ثم «تثبيت» ليحبسك فيه النظام، ويمكنك فك التثبيت بإيماءة النظام.")
                FocusMode.TIMER_ONLY -> Text("⚠ يُفتح التطبيق المختار مباشرة مع مؤقت، لكن بلا منع فعلي. فعّل «تثبيت الشاشة» من إعدادات الأمان لتتمكن من تثبيته، أو اجعل رفيق Device Owner للقفل الحقيقي.")
            }
            if (!isOwner) TextButton(onClick = { showSetup = true }) { Text("كيف أفعّل القفل الحقيقي لتطبيقين؟") }
        } }
        if (notice.isNotBlank()) Text(notice, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)

        val title = sel?.title ?: freeTitle.ifBlank { "جلسة تركيز" }
        Button(onClick = { scope.launch {
                val target0 = allowedPkgs.firstOrNull()
                if (settings.focusGuard && target0 != null && !FocusGuardService.usageGranted(ctx)) {
                    android.widget.Toast.makeText(ctx, "لتفعيل المنع الكامل: امنح «بيانات الاستخدام» ثم ابدأ الجلسة مجددًا.", android.widget.Toast.LENGTH_LONG).show()
                    runCatching { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
                    return@launch
                }
                vm.startFocus(title, dur, allowedPkgs, enforce = isOwner).join()
                val locked = vm.focus.value.enforced
                val act = ctx as? Activity
                val target = allowedPkgs.firstOrNull()
                // القفل الحقيقي: نثبّت رفيق أولًا (مسموح ضمن القائمة) ثم نفتح التطبيق المختار داخل القفل
                if (locked) runCatching { act?.startLockTask() }
                if (target != null) {
                    if (!FocusLockdown.launch(ctx, target, locked))
                        android.widget.Toast.makeText(ctx, "تعذّر فتح التطبيق المختار — تحقق أنه مثبّت ومفعّل.", android.widget.Toast.LENGTH_LONG).show()
                    else if (!locked)
                        android.widget.Toast.makeText(ctx, "للتقييد على هذا التطبيق: الأخيرة ← أيقونة التطبيق ← تثبيت (يتطلب تفعيل تثبيت الشاشة في الأمان).", android.widget.Toast.LENGTH_LONG).show()
                    if (settings.focusGuard) FocusGuardService.start(ctx)
                }
            } },
            enabled = !focus.running && dur >= 5, modifier = Modifier.fillMaxWidth()) {
            Text("ابدأ جلسة التركيز ▶")
        }
        OutlinedButton(onClick = { showHelp = true }, modifier = Modifier.fillMaxWidth()) { Text("الصلاحيات المطلوبة وكيف تفعّلها") }

        if (showHelp) FocusHelpDialog(ctx) { showHelp = false }
        if (showSetup) OwnerSetupDialog(ctx) { showSetup = false }
    }
}

@Composable private fun OwnerSetupDialog(ctx: Context, onClose: () -> Unit) {
    val cmd = FocusLockdown.setupCommand(ctx)
    AlertDialog(onDismissRequest = onClose,
        title = { Text("القفل الحقيقي: Device Owner") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Android يسمح بتحديد تطبيقين مسموحين فقط (Lock Task) لمالك الجهاز وحده. لا يوجد إذن عادي يمنحك ذلك على هاتف شخصي.")
            Text("الإعداد الرسمي (مرة واحدة، من حاسوب مع تفعيل تصحيح USB):")
            Text(cmd, style = MaterialTheme.typography.bodySmall)
            Text("شروط النظام: غالبًا يرفض Android الأمر إذا كانت على الجهاز حسابات (مثل Google) أو مستخدمون آخرون — احذفها مؤقتًا أو استخدم جهازًا مخصصًا للدراسة. جرّب على جهاز ثانوي أولًا.", style = MaterialTheme.typography.bodySmall)
            Text("للإزالة لاحقًا: اضغط «إزالة صلاحية مالك الجهاز» هنا بعد التفعيل، أو أعد ضبط الجهاز.", style = MaterialTheme.typography.bodySmall)
            Text("أثناء الجلسة: يبقى تطبيق الاتصال مسموحًا للطوارئ، وزر «إنهاء الجلسة» في رفيق متاح دائمًا مع التأكيد والتأخير.", style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { TextButton(onClick = {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("dpm", cmd)); onClose()
        }) { Text("نسخ الأمر") } },
        dismissButton = { Row {
            if (FocusLockdown.isDeviceOwner(ctx)) TextButton(onClick = {
                runCatching { (ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager).clearDeviceOwnerApp(ctx.packageName) }
                onClose() }) { Text("إزالة صلاحية مالك الجهاز") }
            TextButton(onClick = onClose) { Text("إغلاق") }
        } })
}

@Composable private fun FocusHelpDialog(ctx: Context, onClose: () -> Unit) {
    val (notif, dnd, exact) = permStatus(ctx)
    AlertDialog(onDismissRequest = onClose,
        title = { Text("الصلاحيات وسببها") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("• الإشعارات: ${if (notif) "✓ ممنوحة" else "غير ممنوحة — نستخدمها فقط لتنبيهك عند انتهاء الجلسة. اضغط السماح عند الطلب أو من إعدادات التطبيق."}")
            Text("• عدم الإزعاج (اختياري): ${if (dnd) "✓ ممنوحة" else "غير ممنوحة — نستخدمها لتقليل إشعارات التطبيقات الأخرى أثناء الجلسة فقط، دون حظر المكالمات والمنبهات."}")
            TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }) { Text("فتح إعدادات عدم الإزعاج") }
            Text("• المنبهات الدقيقة: ${if (exact) "✓ ممنوحة" else "غير ممنوحة — نستخدمها احتياطًا لإنهاء الجلسة في وقتها حتى لو كان التطبيق مغلقًا."}")
            TextButton(onClick = { if (Build.VERSION.SDK_INT >= 31) ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)) }) { Text("فتح إعدادات المنبهات") }
            Text("• تثبيت الشاشة: لا يحتاج صلاحية. فعّله من إعدادات الأمان، ويطلب النظام موافقتك عند أول جلسة، ويمكنك فك التثبيت في أي وقت بالإيماءة المعتادة.")
            Text("ملاحظة أمان: التطبيق لا يجمع أسماء التطبيقات التي تفتحها ولا يستطيع إغلاق تطبيقات أخرى بالقوة — هذا مقصود ووفق قيود أندرويد.", style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { TextButton(onClick = onClose) { Text("فهمت") } })
}

@Composable fun FocusSessionScreen(vm: MainVm, onFinished: (FocusState) -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val settings by vm.settings.collectAsState()
    val s by vm.focus.collectAsState()
    var nowE by remember { mutableStateOf(SystemClock.elapsedRealtime()) }
    var nowW by remember { mutableStateOf(System.currentTimeMillis()) }
    var phase by remember { mutableStateOf(0) } // 0 نشطة · 1 تأكيد أول · 2 تأكيد ثانٍ + عداد
    var lastPhrase by remember { mutableStateOf<String?>(null) }
    var phrase by remember { mutableStateOf<String?>(null) }
    var exitLeft by remember { mutableStateOf(settings.focusExitDelaySec) }
    var pinFailed by remember { mutableStateOf(false) }
    var started by rememberSaveable { mutableStateOf(false) }   // لا نعيد فتح التطبيقات عند تدوير الشاشة
    var prevFilter by remember { mutableStateOf(-1) }
    var ended by remember { mutableStateOf(false) }

    var showLockHelp by remember { mutableStateOf(false) }
    // تثبيت/قفل + فتح التطبيق المسموح الأول + كتم الإشعارات الاختياري
    LaunchedEffect(s.sessionId) {
        if (s.sessionId.isEmpty()) return@LaunchedEffect
        val mode = if (s.enforced) FocusMode.LOCK_TASK_ALLOWLIST else FocusPolicy.decide(false, settings.focusPin)
        // نثبّت رفيق أولًا ثم نفتح التطبيق المسموح داخل Lock Task. startLockTask متكررة الأمان (تُعاد بعد إعادة التشغيل).
        if (s.enforced || FocusPolicy.pinsSelf(mode, s.allowed.isNotEmpty())) try { activity?.startLockTask() }
            catch (e: Exception) { pinFailed = true; if (!s.enforced) showLockHelp = true }
        if (!started) {
            started = true
            // فتح التطبيق المختار يتم مباشرة من زر «ابدأ» (لا نعيد فتحه هنا حتى لا نسحبك إلى التطبيق مرة ثانية)
            if (settings.focusDnd) {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (nm.isNotificationPolicyAccessGranted) {
                    prevFilter = nm.currentInterruptionFilter
                    nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
                }
            }
        }
    }

    LaunchedEffect(phase) {
        if (phase == 2) {
            phrase = FocusPhrases.randomExcept(lastPhrase); lastPhrase = phrase
            exitLeft = settings.focusExitDelaySec
            while (exitLeft > 0) { delay(1000); exitLeft-- }
        }
    }

    val endSession = { natural: Boolean ->
        if (!ended) {
            ended = true
            runCatching { activity?.stopLockTask() }
            if (prevFilter != -1) runCatching {
                (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                    .setInterruptionFilter(prevFilter) }
            val finished = s
            vm.endFocus(natural)
            onFinished(finished)
        }
    }

    BackHandler { if (phase == 0) phase = 1 }

    LaunchedEffect(Unit) {
        while (true) {
            nowE = SystemClock.elapsedRealtime(); nowW = System.currentTimeMillis()
            val cur = vm.focus.value
            if (!ended && cur.running && FocusMath.isExpired(cur, nowE, nowW)) endSession(true)
            delay(500)
        }
    }

    Column(Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("جلسة تركيز — ${s.title}", style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (pinFailed) Text("لم يُفعّل تثبيت الشاشة. فعّله من إعدادات الأمان › تثبيت الشاشة ثم أعد الجلسة.",
            color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        Text(FocusMath.fmtClock(FocusMath.remainingMs(s, nowE, nowW)), style = MaterialTheme.typography.displayLarge)
        LinearProgressIndicator(progress = { FocusMath.progressPct(s, nowE, nowW) / 100f }, modifier = Modifier.fillMaxWidth())
        Text("المتبقي من ${s.planMin} دقيقة", style = MaterialTheme.typography.bodyMedium)
        val (okApps, goneApps) = remember(s.allowed) { FocusLockdown.launchable(ctx, s.allowed) }
        Text("التطبيقات المسموحة: رفيق" + okApps.joinToString("") { " • ${FocusAppsStore.labelOf(ctx, it)}" },
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (goneApps.isNotEmpty()) Text("⚠ غير متاح الآن (حُذف أو عُطّل): ${goneApps.joinToString("، ")}",
            color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        Text(if (s.enforced) "🔒 قفل حقيقي مفعّل (Lock Task) حتى انتهاء المؤقت."
             else if (settings.focusGuard && s.allowed.isNotEmpty()) "🔒 حارس التركيز يعيدك إلى التطبيق المسموح عند أي محاولة خروج حتى ينتهي المؤقت."
             else "⚠ مؤقت غير مُلزِم — يمكنك الخروج من التطبيق.",
            style = MaterialTheme.typography.bodySmall)
        okApps.forEach { pkg ->
            OutlinedButton(onClick = { FocusLockdown.launch(ctx, pkg, s.enforced) }) {
                Text("فتح ${FocusAppsStore.labelOf(ctx, pkg)}") }
        }
        OutlinedButton(onClick = { runCatching { ctx.startActivity(Intent(Intent.ACTION_DIAL)) } }) { Text("📞 اتصال طوارئ") }
        Button(onClick = { phase = 1 }) { Text("إنهاء الجلسة") }
    }

    if (phase == 1) AlertDialog(onDismissRequest = { phase = 0 },
        title = { Text("إنهاء المحاضرة؟") },
        text = { Text("هل أنت متأكد أنك تريد إنهاء المحاضرة؟ ما تبقّى لن يُحتسب.") },
        confirmButton = { TextButton(onClick = { phase = 2 }) { Text("نعم، أكمل الخروج") } },
        dismissButton = { TextButton(onClick = { phase = 0 }) { Text("أرجع للمحاضرة") } })

    if (showLockHelp) AlertDialog(onDismissRequest = { showLockHelp = false },
        title = { Text("تثبيت الشاشة غير مفعّل") },
        text = { Text("رفيق لا يستطيع فرض قفل نظامي كامل على جهاز شخصي عادي. للحصول على إجباري حقيقي:" +
            "\n\n١) فعّل «تثبيت التطبيقات» من إعدادات الأمان، وسيطلب النظام موافقتك عند أول جلسة — يبقى التطبيق مثبتًا حتى تلغي أنت." +
            "\n٢) لقفل كامل بلا إلغاء: يجب ضبط الجهاز كـ Device Owner (إعداد مخصص للأجهزة المُدارة) — غير متاح للهاتف الشخصي دون إعادة ضبط وموافقة." +
            "\n\nلا نستطيع وبصدق منع زر الرجوع أو الطوارئ على كل جهاز.") },
        confirmButton = { TextButton(onClick = {
            showLockHelp = false
            runCatching { ctx.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }
        }) { Text("فتح إعدادات الأمان") } },
        dismissButton = { TextButton(onClick = { showLockHelp = false }) { Text("فهمت") } })

    if (phase == 2) AlertDialog(onDismissRequest = { phase = 0 },
        title = { Text("لحظة واحدة…") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(phrase ?: "", style = MaterialTheme.typography.titleMedium)
            if (exitLeft > 0) Text("يمكنك الإنهاء بعد $exitLeft ثانية", style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { TextButton(onClick = { phase = 0 }) { Text("أرجع للمحاضرة") } },
        dismissButton = { TextButton(enabled = exitLeft == 0, onClick = { endSession(false) }) { Text("إنهاء فعلًا") } })
}

@Composable fun FocusDoneScreen(s: FocusState, totals: Pair<Long, Long>?, onClose: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("🎉", style = MaterialTheme.typography.displayLarge)
        Text("أنجزت جلسة تركيز!", style = MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("المحاضرة: ${s.title}", style = MaterialTheme.typography.titleMedium)
            Text("المدة المخططة: ${s.planMin} دقيقة")
            totals?.let { Text("إجمالي جلسات التركيز: ${it.first} جلسة · ${it.second / 60}س ${it.second % 60}د", style = MaterialTheme.typography.bodySmall) }
        } }
        Text(FocusPhrases.randomExcept(null), style = MaterialTheme.typography.bodyMedium)
        Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("رجوع") }
    }
}

/** رسم بياني بأعمدة لدقائق التركيز في آخر 7 أيام — Canvas خالص بلا مكتبات خارجية. */
@Composable fun FocusWeekChart(days: List<Pair<String, Int>>) {
    if (days.isEmpty()) return
    val accent = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.surfaceVariant
    val today = Subjects.now().toLocalDate().toString()
    Canvas(Modifier.fillMaxWidth().height(110.dp)) {
        val maxV = days.maxOf { it.second }.coerceAtLeast(30)
        val slot = size.width / days.size
        val barW = slot * 0.55f
        days.forEachIndexed { i, (d, v) ->
            val x = i * slot + (slot - barW) / 2
            drawRoundRect(color = track, topLeft = Offset(x, 0f), size = Size(barW, size.height), cornerRadius = CornerRadius(12f, 12f))
            if (v > 0) {
                val h = size.height * v / maxV
                drawRoundRect(color = if (d == today) accent else accent.copy(alpha = 0.55f),
                    topLeft = Offset(x, size.height - h), size = Size(barW, h), cornerRadius = CornerRadius(12f, 12f))
            }
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        days.forEach { (d, _) -> Text(d.substring(8), style = MaterialTheme.typography.labelSmall) }
    }
}
