package com.rafiq6.study

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

class TasksWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, mgr: AppWidgetManager, ids: IntArray) = runBlocking {
        val dao = AppDb.get(c).dao(); val today = Subjects.now().toLocalDate().toString()
        val tasks = first(dao.day(today))
        val nowMin = Subjects.now().hour * 60 + Subjects.now().minute
        val cur = tasks.firstOrNull { !it.done && it.startMin != null && nowMin >= it.startMin!! && (it.endMin == null || nowMin < it.endMin!!) }
        val nxt = tasks.firstOrNull { !it.done && it.startMin != null && it.startMin!! > nowMin }
        val shown = cur ?: nxt
        val pct = if (tasks.isEmpty()) 0 else 100 * tasks.count { it.done } / tasks.size
        for (id in ids) {
            val v = RemoteViews(c.packageName, R.layout.widget_layout)
            v.setTextViewText(R.id.wTitle, shown?.title ?: "لا مهام متبقية اليوم — رتاح!")
            v.setTextViewText(R.id.wTime, shown?.let { "${Subjects.fmt12(it.startMin!!)} — ${it.durationMin} دقيقة" } ?: "")
            v.setProgressBar(R.id.wProgress, 100, pct, false)
            v.setOnClickPendingIntent(R.id.wOpen, PendingIntent.getActivity(c, 0,
                Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            mgr.updateAppWidget(id, v)
        }
    }
}
