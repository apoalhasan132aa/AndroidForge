package com.rafiq6.study

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class MainVm(app: Application) : AndroidViewModel(app) {
    val db = AppDb.get(app)
    private val _settings = MutableStateFlow(Settings()); val settings = _settings.asStateFlow()
    val all = db.dao().all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val timer = MutableStateFlow(TimerState())
    init { viewModelScope.launch {
        SeedImporter.importIfEmpty(app, db)
        _settings.value = Prefs.get(app)
        timer.value = StudyTimer.state(app)
        refreshAlarms()
    } }
    fun dayTasks(date: LocalDate): Flow<List<TaskEntity>> = db.dao().day(date.toString())
    fun refreshAlarms() = viewModelScope.launch {
        val today = Subjects.now().toLocalDate().toString()
        all.value.filter { it.date >= today }.forEach { AlarmScheduler.schedule(getApplication(), it) }
    }
    fun toggleDone(t: TaskEntity, done: Boolean) = viewModelScope.launch {
        val wasDone = t.done
        if (!wasDone && done) { t.done = true; t.doneAt = System.currentTimeMillis()
            if (t.actualMin == null) t.actualMin = t.durationMin }
        else if (wasDone && !done) { t.done = false; t.doneAt = null; t.actualMin = null }
        else return@launch // حماية من النقر المزدوج
        db.dao().upsert(t)
        if (done) { AlarmScheduler.cancel(getApplication(), t); StudyTimer.cancel(getApplication())
            Notify.notify(getApplication(), t.id.hashCode() + 1, "أحسنت! 🎉",
                "أنجزت «${t.title}». خطوة إضافية نحو هدفك.", null) }
        else { AlarmScheduler.schedule(getApplication(), t); refreshAlarms() }
    }
    fun updateTime(t: TaskEntity, startMin: Int, endMin: Int) = viewModelScope.launch {
        t.startMin = startMin; t.endMin = endMin; db.dao().upsert(t); refreshAlarms() }
    fun startTimer(t: TaskEntity) = viewModelScope.launch { StudyTimer.start(getApplication(), t.id)
        timer.value = StudyTimer.state(getApplication()) }
    fun pauseTimer() = viewModelScope.launch { StudyTimer.pause(getApplication())
        timer.value = StudyTimer.state(getApplication()) }
    fun resumeTimer() = viewModelScope.launch { StudyTimer.resume(getApplication())
        timer.value = StudyTimer.state(getApplication()) }
    fun finishTimer(onDone: (TaskEntity) -> Unit) = viewModelScope.launch {
        val r = StudyTimer.finish(getApplication()); timer.value = TimerState()
        if (r != null) { val t = db.dao().byId(r.first); if (t != null && !t.done) {
            t.actualMin = r.second; db.dao().upsert(t); onDone(t) } } }
    fun saveSettings(s: Settings) = viewModelScope.launch { Prefs.put(getApplication(), s); _settings.value = s }
    // الأنشطة الشخصية
    fun dayActs(date: LocalDate): Flow<List<ActivityEntity>> = db.act().day(date.toString())
    fun addActivity(a: ActivityEntity) = viewModelScope.launch { db.act().upsert(a) }
    fun toggleAct(a: ActivityEntity, v: Boolean) = viewModelScope.launch { a.done = v; db.act().upsert(a) }
    fun deleteAct(id: String) = viewModelScope.launch { db.act().delete(id) }
    fun postponeAct(a: ActivityEntity, to: LocalDate) = viewModelScope.launch {
        db.act().delete(a.id)
        db.act().upsert(a.copy(id = a.id + "-p" + to.dayOfYear, date = to.toString(),
            startMin = null, postponedFrom = a.date)) }
    fun stats(tasks: List<TaskEntity>): Stats {
        val done = tasks.filter { it.done }
        val byDay = tasks.groupBy { it.date }
        val best = byDay.maxByOrNull { e -> e.value.count { it.done } }
        var streak = 0; val dates = byDay.keys.sorted().reversed()
        val today = Subjects.now().toLocalDate().toString()
        for (d in dates) { val g = byDay[d]!!
            val pct = if (g.isEmpty()) 0 else 100 * g.count { it.done } / g.size
            if (pct >= 70) streak++ else if (d <= today) break }
        return Stats(tasks.size, done.size, done.sumOf { it.actualMin ?: 0 },
            done.groupBy { it.subject }.mapValues { e -> e.value.size }, streak, best?.key)
    }
}
data class Stats(val total: Int, val done: Int, val actualMin: Int,
                 val perSubject: Map<String, Int>, val streak: Int, val bestDay: String?)
