package com.rafiq6.study

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.ZoneId
import java.time.ZonedDateTime

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val id: String,
    val date: String,
    val dayName: String,
    val subject: String,
    val type: String,
    val title: String,
    val lectureNo: Int?,
    val durationMin: Int,
    val startMin: Int?,
    val endMin: Int?,
    val flexible: Boolean = false,
    val note: String? = null,
    var done: Boolean = false,
    var doneAt: Long? = null,
    var actualMin: Int? = null,
    val remindBeforeMin: Int = 15
)

object Subjects {
    val colors = mapOf(
        "فيزياء" to 0xFF2E6FB7, "كيمياء" to 0xFF7E57C2, "رياضيات" to 0xFFF4842B,
        "أحياء" to 0xFF43A047, "عربي" to 0xFFC9A227, "إنكليزي" to 0xFF4FC3F7
    )
    fun color(s: String) = colors[s] ?: 0xFF607D8B
    val BAGHDAD: ZoneId = ZoneId.of("Asia/Baghdad")
    fun now(): ZonedDateTime = ZonedDateTime.now(BAGHDAD)
    fun fmt12(min: Int): String {
        val h = min / 60; val m = min % 60
        val period = when { h < 12 -> "صباحاً"; h == 12 -> "ظهراً"; else -> "مساءً" }
        val h12 = if (h == 0 || h == 12) 12 else h % 12
        return "%d:%02d %s".format(h12, m, period)
    }
    fun toMin(hhmm: String): Int { val p = hhmm.split(":"); return p[0].toInt() * 60 + p[1].toInt() }
}
