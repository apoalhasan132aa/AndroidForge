package com.rafiq6.study

import android.content.Context
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object Backup {
    suspend fun export(c: Context): File {
        val tasks = first(AppDb.get(c).dao().all())
        val arr = JSONArray(); tasks.forEach { t -> arr.put(JSONObject().apply {
            put("id", t.id); put("date", t.date); put("subject", t.subject); put("type", t.type)
            put("title", t.title); put("done", t.done); put("doneAt", t.doneAt ?: 0)
            put("actualMin", t.actualMin ?: 0); put("startMin", t.startMin ?: -1); put("endMin", t.endMin ?: -1) }) }
        val f = File(c.cacheDir, "backups/rafiq6-backup.json"); f.parentFile?.mkdirs()
        f.writeText(JSONObject().put("tasks", arr).toString()); return f
    }
    suspend fun import(c: Context, json: String) {
        val arr = JSONObject(json).getJSONArray("tasks"); val dao = AppDb.get(c).dao()
        for (i in 0 until arr.length()) { val o = arr.getJSONObject(i)
            dao.byId(o.getString("id"))?.let { it.done = o.getBoolean("done")
                it.doneAt = if (o.getLong("doneAt") == 0L) null else o.getLong("doneAt")
                it.actualMin = if (o.getInt("actualMin") == 0) null else o.getInt("actualMin")
                it.startMin = if (o.getInt("startMin") < 0) null else o.getInt("startMin")
                it.endMin = if (o.getInt("endMin") < 0) null else o.getInt("endMin")
                dao.upsert(it) } } }
}
