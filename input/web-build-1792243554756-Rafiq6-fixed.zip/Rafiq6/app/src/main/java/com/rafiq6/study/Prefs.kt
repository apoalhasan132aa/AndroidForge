package com.rafiq6.study

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

val Context.ds by preferencesDataStore("rafiq6_settings")

data class Settings(
    val wakeMin: Int = 270, val sleepMin: Int = 1290,
    val schoolStart: Int = 450, val schoolEnd: Int = 780,
    val breakMin: Int = 15, val dailyGoalMin: Int = 390,
    val dark: Boolean = false, val fridayLight: Boolean = false,
    val outingDates: String = ""
)

object Prefs {
    private val WAKE = intPreferencesKey("wake"); private val SLEEP = intPreferencesKey("sleep")
    private val SCHS = intPreferencesKey("schs"); private val SCHE = intPreferencesKey("sche")
    private val BRK = intPreferencesKey("brk"); private val GOAL = intPreferencesKey("goal")
    private val DARK = booleanPreferencesKey("dark"); private val FRI = booleanPreferencesKey("fri")
    private val OUT = stringPreferencesKey("outing")
    suspend fun get(c: Context): Settings { val p = c.ds.data.first(); return Settings(
        p[WAKE] ?: 270, p[SLEEP] ?: 1290, p[SCHS] ?: 450, p[SCHE] ?: 780, p[BRK] ?: 15,
        p[GOAL] ?: 390, p[DARK] ?: false, p[FRI] ?: false, p[OUT] ?: "") }
    suspend fun put(c: Context, s: Settings) { c.ds.edit {
        it[WAKE]=s.wakeMin; it[SLEEP]=s.sleepMin; it[SCHS]=s.schoolStart; it[SCHE]=s.schoolEnd
        it[BRK]=s.breakMin; it[GOAL]=s.dailyGoalMin; it[DARK]=s.dark; it[FRI]=s.fridayLight; it[OUT]=s.outingDates } }
    suspend fun addOuting(c: Context, date: String) { val s = get(c); if (date !in s.outingDates)
        put(c, s.copy(outingDates = (s.outingDates + "," + date).trim(','))) }
    suspend fun resetSettingsOnly(c: Context) { c.ds.edit { it.clear() } }
}
