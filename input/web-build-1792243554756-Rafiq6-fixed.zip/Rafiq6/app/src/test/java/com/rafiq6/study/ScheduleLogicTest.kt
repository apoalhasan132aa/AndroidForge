package com.rafiq6.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class ScheduleLogicTest {
    @Test
    fun `no exam starts before 7pm in seed`() {
        val json = javaClass.classLoader!!.getResourceAsStream("schedule.json")!!
            .bufferedReader().readText()
        val days = org.json.JSONObject(json).getJSONArray("days")
        for (i in 0 until days.length()) {
            val ts = days.getJSONObject(i).getJSONArray("tasks")
            for (j in 0 until ts.length()) { val t = ts.getJSONObject(j)
                if (t.getString("ty").contains("امتحان") && !t.isNull("st"))
                    assertTrue("امتحان قبل 7 مساء!",
                        Subjects.toMin(t.getString("st")) >= 19 * 60) } }
    }
    @Test fun `weekday matches date`() {
        assertEquals("الأحد", listOf("الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت","الأحد")
            [LocalDate.of(2026, 10, 18).dayOfWeek.value - 1]) }
    @Test fun `exam sequencing leaves no overlap`() { var t = 19 * 60
        listOf(30, 60).forEach { d -> assertTrue(t >= 19 * 60); t += d } }
    @Test fun `percent matches done count`() { assertEquals(50, 100 * 3 / 6) }
    @Test fun `12h format`() {
        assertEquals("7:00 مساءً", Subjects.fmt12(19 * 60))
        assertEquals("4:30 صباحاً", Subjects.fmt12(270)) }
    @Test fun `activity slot never overlaps tasks`() {
        val tasks = listOf(TaskEntity("x","2026-10-18","الأحد","فيزياء","امتحان","t",null,60,19*60,20*60))
        val slot = ActivityPlanner.suggestSlot(tasks, emptyList(), 30)
        assertTrue(slot == null || slot >= 20 * 60 + 15) }
}
