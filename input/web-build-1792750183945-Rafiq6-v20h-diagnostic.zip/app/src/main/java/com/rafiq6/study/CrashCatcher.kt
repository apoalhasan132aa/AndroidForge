package com.rafiq6.study

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/** يلتقط أي استثناء غير معالج (crash) ويحفظه ثم يفتح شاشة تعرضه للمستخدم. */
object CrashCatcher {
    private const val FILE = "crash.txt"
    fun file(c: android.content.Context): File = File(c.getExternalFilesDir(null), FILE)
    fun install(c: android.content.Context) {
        val def = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, err ->
            runCatching {
                file(c).writeText(err.stackTraceToString())
                val i = android.content.Intent(c, CrashDisplayActivity::class.java).apply {
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK)
                }
                c.startActivity(i)
            }
            def?.uncaughtException(thread, err)
        }
    }
}

class CrashDisplayActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val text = runCatching { CrashCatcher.file(this).readText() }.getOrDefault("لا يوجد سجل عطل.")
        val pad = (16 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            this.text = "تفاصيل العطل — أرسل لقطة شاشة من هذه الشاشة:\n\n$text"
            setTextIsSelectable(true)
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(pad, pad, pad, pad)
        }
        val sv = ScrollView(this).apply { addView(tv) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#11161D"))
            gravity = Gravity.TOP
            addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT))
        }
        setContentView(root)
    }
}
