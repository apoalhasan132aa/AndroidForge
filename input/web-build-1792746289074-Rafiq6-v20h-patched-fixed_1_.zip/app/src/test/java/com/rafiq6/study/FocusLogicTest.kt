package com.rafiq6.study

import org.junit.Assert.*
import org.junit.Test

class FocusLogicTest {
    private fun state(plan: Int = 25, startE: Long = 1000) =
        FocusState("id1", "فيزياء", plan, startE, startE + plan * 60_000L,
            1_700_000_000_000L, 1_700_000_000_000L + plan * 60_000L, true)

    @Test fun phrasesAreExactly50AndUnique() {
        assertEquals(50, FocusPhrases.all.size)
        assertEquals(50, FocusPhrases.all.toSet().size)
        assertTrue(FocusPhrases.all.all { it.isNotBlank() })
    }

    @Test fun randomNeverRepeatsLastImmediately() {
        val last = FocusPhrases.all[0]
        repeat(300) { assertNotEquals(last, FocusPhrases.randomExcept(last)) }
    }

    @Test fun remainingCountsDownWithMonotonicClock() {
        val s = state()
        assertEquals(25 * 60_000L, FocusMath.remainingMs(s, 1000, 1_700_000_000_000L))
        assertEquals(10 * 60_000L, FocusMath.remainingMs(s, 1000 + 15 * 60_000L, 0))
        assertTrue(FocusMath.isExpired(s, 1000 + 25 * 60_000L, 0))
    }

    @Test fun fallsBackToWallClockAfterReboot() {
        // بعد إعادة التشغيل: nowElapsed أصغر من startElapsed → نستخدم الساعة الجدارية.
        val s = state(startE = 500_000)
        assertEquals(20 * 60_000L, FocusMath.remainingMs(s, 1000, 1_700_000_000_000L + 5 * 60_000L))
    }

    @Test fun progressGrowsTo100() {
        val s = state(plan = 30)
        assertEquals(0, FocusMath.progressPct(s, 1000, 0))
        assertEquals(50, FocusMath.progressPct(s, 1000 + 15 * 60_000L, 0))
        assertEquals(100, FocusMath.progressPct(s, 1000 + 30 * 60_000L, 0))
    }

    @Test fun notRunningMeansNoRemaining() {
        val s = state().copy(running = false)
        assertEquals(0, FocusMath.remainingMs(s, 1000, 0))
        val empty = state().copy(sessionId = "")
        assertFalse(empty.running || FocusMath.remainingMs(empty, 1000, 0) != 0L)
    }

    @Test fun clockFormat() {
        assertEquals("25:00", FocusMath.fmtClock(25 * 60_000L))
        assertEquals("0:59", FocusMath.fmtClock(59_000L))
        assertEquals("0:00", FocusMath.fmtClock(-5))
    }

    // ===== اختيار التطبيقات (حتى تطبيقين، بمعرّف الحزمة) =====
    @Test fun selectionAllowsAtMostTwoAndNeverReplacesSilently() {
        var l = emptyList<String>()
        l = FocusSelection.toggle(l, "com.a"); l = FocusSelection.toggle(l, "com.b")
        assertEquals(listOf("com.a", "com.b"), l)
        assertEquals(l, FocusSelection.toggle(l, "com.c"))             // ممتلئ: لا يتغير
        assertEquals(listOf("com.b"), FocusSelection.toggle(l, "com.a")) // إزالة
        assertEquals(l, FocusSelection.toggle(l, ""))                  // معرّف فارغ يُتجاهل
    }

    @Test fun selectionEncodingRoundTripsDedupesAndCaps() {
        assertEquals(listOf("com.a", "com.b"), FocusSelection.decode(FocusSelection.encode(listOf("com.a", "com.a", "com.b", "com.c"))))
        assertTrue(FocusSelection.decode(null).isEmpty())
        assertEquals(listOf("com.a"), FocusSelection.decode(" com.a \n\n"))
    }

    @Test fun removedAppsAreSeparatedFromValidOnes() {
        val (ok, gone) = FocusSelection.sanitize(listOf("com.a", "com.b"), setOf("com.b"))
        assertEquals(listOf("com.b"), ok); assertEquals(listOf("com.a"), gone)
    }

    @Test fun lockTaskPackagesIncludeOwnAndDialerWithoutDuplicates() {
        assertEquals(listOf("com.rafiq6.study", "com.a", "com.dialer"),
            FocusSelection.lockTaskPackages("com.rafiq6.study", listOf("com.a", "com.rafiq6.study"), "com.dialer"))
        assertEquals(listOf("com.rafiq6.study"), FocusSelection.lockTaskPackages("com.rafiq6.study", emptyList(), null))
    }

    @Test fun modeIsDecidedByDeviceCapabilityNotWishes() {
        assertEquals(FocusMode.LOCK_TASK_ALLOWLIST, FocusPolicy.decide(true, false))
        assertEquals(FocusMode.LOCK_TASK_ALLOWLIST, FocusPolicy.decide(true, true))
        assertEquals(FocusMode.SCREEN_PIN_SELF, FocusPolicy.decide(false, true))
        assertEquals(FocusMode.TIMER_ONLY, FocusPolicy.decide(false, false))
        assertTrue(FocusPolicy.opensAllowedApps(FocusMode.SCREEN_PIN_SELF))
        assertTrue(FocusPolicy.pinsSelf(FocusMode.SCREEN_PIN_SELF, false))
        assertFalse(FocusPolicy.pinsSelf(FocusMode.SCREEN_PIN_SELF, true))   // تطبيق مختار: لا نحبسك في رفيق
        assertFalse(FocusPolicy.pinsSelf(FocusMode.TIMER_ONLY, false))
        assertTrue(FocusPolicy.opensAllowedApps(FocusMode.LOCK_TASK_ALLOWLIST))
    }

    @Test fun sessionStateCarriesAllowedAppsAndDefaultsAreBackwardCompatible() {
        val s = state()
        assertTrue(s.allowed.isEmpty()); assertFalse(s.enforced)
        val e = s.copy(allowed = listOf("com.a"), enforced = true)
        assertTrue(e.enforced && e.allowed == listOf("com.a"))
        // الحساب الزمني لا يتأثر بالحقول الجديدة
        assertEquals(FocusMath.remainingMs(s, 1000, 0), FocusMath.remainingMs(e, 1000, 0))
    }
}
