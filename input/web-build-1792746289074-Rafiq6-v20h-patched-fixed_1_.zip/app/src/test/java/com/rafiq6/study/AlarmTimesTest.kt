package com.rafiq6.study

import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class AlarmTimesTest {
    private val zone = ZoneId.of("Asia/Baghdad")
    private fun ms(h: Int, m: Int, day: Int = 5) =
        ZonedDateTime.of(2026, 1, day, h, m, 0, 0, zone).toInstant().toEpochMilli()

    @Test fun threeAlarmsForFutureTaskAtExactTimes() {
        val r = AlarmTimes.compute("2026-01-05", 18 * 60, 19 * 60, 15, ms(8, 0), zone)
        assertEquals(listOf(0 to ms(17, 45), 1 to ms(18, 0), 2 to ms(19, 15)), r)
    }

    @Test fun pastAlarmsAreSkippedNotFiredLate() {
        assertEquals(listOf(1, 2), AlarmTimes.compute("2026-01-05", 18 * 60, 19 * 60, 15, ms(17, 50), zone).map { it.first })
        assertEquals(listOf(2), AlarmTimes.compute("2026-01-05", 18 * 60, 19 * 60, 15, ms(18, 30), zone).map { it.first })
        assertTrue(AlarmTimes.compute("2026-01-05", 18 * 60, 19 * 60, 15, ms(19, 16), zone).isEmpty())
    }

    @Test fun noEndMeansNoLateReminder() {
        assertEquals(listOf(0, 1), AlarmTimes.compute("2026-01-05", 18 * 60, null, 15, ms(8, 0), zone).map { it.first })
    }

    @Test fun dayOfTaskIsRespected() {
        val a = AlarmTimes.compute("2026-01-05", 600, 645, 10, 0L, zone)
        val b = AlarmTimes.compute("2026-01-06", 600, 645, 10, 0L, zone)
        assertEquals(24 * 3600_000L, b[1].second - a[1].second)
    }
}
