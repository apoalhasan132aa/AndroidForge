package com.rafiq6.study

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class ScheduleValidatorTest {
    private fun validJson() = """
    {
      "format":"rafiq_schedule",
      "formatVersion":1,
      "metadata":{"scheduleName":"اختبار","timeZone":"Asia/Baghdad"},
      "startDate":"2026-10-18",
      "endDate":"2026-10-20",
      "days":[{
        "date":"2026-10-18",
        "weekday":"الأحد",
        "tasks":[{
          "id":"t1","subject":"رياضيات","type":"newLecture",
          "title":"محاضرة رياضيات 1","lectureNo":1,
          "durationMin":75,"start":"14:00","end":"15:15",
          "flexible":false,"fixed":false,"notify":true
        }]
      }]
    }
    """.trimIndent()

    @Test fun `valid v1 file is accepted`() {
        val r = ScheduleParser.parse(validJson())
        assertTrue(r.errorText(), r.ok)
        assertEquals("اختبار", r.file!!.meta.name)
        assertEquals(1, r.file.taskCount())
    }

    @Test fun `invalid json is rejected`() {
        val r = ScheduleParser.parse("{not-json")
        assertFalse(r.ok)
        assertTrue(r.errors.any { it.path == "json" })
        assertNull(r.file)
    }

    @Test fun `missing basic fields are rejected`() {
        val r = ScheduleParser.parse("""{"format":"rafiq_schedule","formatVersion":1,"days":[]}""")
        assertFalse(r.ok)
    }

    @Test fun `duplicate ids are rejected`() {
        val json = validJson().replace("\"id\":\"t1\"", "\"id\":\"x\"", false).replaceFirst("x", "t1") + ""
        val duplicated = json.replace("\"id\":\"t1\"", "\"id\":\"t1\"", false)
        val withTwo = duplicated.replace("""],"constraints":[]}] }""", "")
        // اختبار مباشر وبسيط على مستند مكرر
        val text = """
        {"format":"rafiq_schedule","formatVersion":1,"days":[{"date":"2026-10-18","tasks":[
        {"id":"a","subject":"رياضيات","type":"newLecture","title":"أ","durationMin":30,"start":"10:00","end":"10:30"},
        {"id":"a","subject":"فيزياء","type":"newLecture","title":"ب","durationMin":30,"start":"11:00","end":"11:30"}
        ]}]}
        """.trimIndent()
        val r = ScheduleParser.parse(text)
        assertFalse(r.ok)
        assertTrue(r.errorText().contains("مكرر"))
    }

    @Test fun `overlapping tasks are rejected`() {
        val text = """
        {"format":"rafiq_schedule","formatVersion":1,"days":[{"date":"2026-10-18","tasks":[
        {"id":"a","subject":"رياضيات","type":"newLecture","title":"أ","durationMin":45,"start":"10:00","end":"10:45"},
        {"id":"b","subject":"فيزياء","type":"newLecture","title":"ب","durationMin":45,"start":"10:30","end":"11:15"}
        ]}]}
        """.trimIndent()
        assertFalse(ScheduleParser.parse(text).ok)
    }

    @Test fun `exam before 7pm is rejected`() {
        val text = """
        {"format":"rafiq_schedule","formatVersion":1,"days":[{"date":"2026-10-18","tasks":[
        {"id":"a","subject":"كيمياء","type":"dailyExam","title":"امتحان","durationMin":30,"start":"18:30","end":"19:00"}
        ]}]}
        """.trimIndent()
        assertFalse(ScheduleParser.parse(text).ok)
    }

    @Test fun `task outside schedule range is rejected`() {
        val text = """
        {"format":"rafiq_schedule","formatVersion":1,"startDate":"2026-10-18","endDate":"2026-10-18",
        "days":[{"date":"2026-10-19","tasks":[
        {"id":"a","subject":"رياضيات","type":"newLecture","title":"أ","durationMin":30}
        ]}]}
        """.trimIndent()
        assertFalse(ScheduleParser.parse(text).ok)
    }

    @Test fun `legacy v2 seed is accepted`() {
        val text = javaClass.classLoader!!.getResourceAsStream("schedule.json")!!.bufferedReader().readText()
        val r = ScheduleParser.parse(text)
        assertTrue(r.errorText(), r.ok)
        assertEquals(237, r.file!!.days.size)
        assertEquals(1388, r.file.taskCount())
    }
}

class ExamSequencerTest {
    @Test fun `exams start sequentially from 7pm`() {
        assertEquals(listOf(19 * 60, 19 * 60 + 30, 20 * 60 + 30), ExamSequencer.sequentialStarts(listOf(30, 60, 45)))
    }
    @Test fun `sequenced exams do not overlap`() {
        val d = listOf(30, 60, 45)
        val starts = ExamSequencer.sequentialStarts(d)
        assertFalse(ExamSequencer.hasOverlap(starts, d))
    }
    @Test fun `zero exam duration is rejected`() {
        var failed = false
        try { ExamSequencer.sequentialStarts(listOf(0)) } catch (e: IllegalArgumentException) { failed = true }
        assertTrue(failed)
    }
}

class RescheduleEngineTest {
    private fun settings() = Settings(wakeMin = 6 * 60, schoolStart = 8 * 60, schoolEnd = 14 * 60,
        sleepMin = 22 * 60, breakMin = 15, dailyGoalMin = 900, maxPostponeDays = 7)
    private fun task(id: String, date: String, start: Int?, duration: Int = 60,
                     flexible: Boolean = false, fixed: Boolean = false, done: Boolean = false): UiTask {
        val row = TaskEntity(
            id = "s::$id", scheduleId = "s", sourceId = id, date = date,
            dayName = ScheduleParser.weekday(LocalDate.parse(date)), subject = "رياضيات",
            type = TaskTypes.NEW, title = "مهمة $id", lectureNo = null, durationMin = duration,
            startMin = start, endMin = start?.plus(duration), flexible = flexible, fixed = fixed
        )
        return UiTask(row, ProgressEntity(row.id, done = done))
    }

    @Test fun `flexible outing task is moved to a later day without overlap`() {
        val outing = LocalDate.of(2026, 10, 18)
        val tasks = listOf(
            task("move", "2026-10-18", 16 * 60, flexible = true),
            task("fixed-next", "2026-10-19", 15 * 60, fixed = true)
        )
        val plan = RescheduleEngine.plan(tasks, outing, settings())
        assertTrue(plan.moved.isNotEmpty())
        val moved = plan.moved.single { it.sourceId == "move" }
        assertTrue(moved.date > outing.toString())
        val targetTasks = tasks.map { t -> if (t.id == moved.id) moved else t }
        val timed = targetTasks.filter { it.date == moved.date && it.startMin != null }
        for (i in timed.indices) for (j in i + 1 until timed.size) {
            val a = timed[i]; val b = timed[j]
            assertFalse("تداخل بعد إعادة الجدولة", a.startMin!! < b.endMin!! && b.startMin!! < a.endMin!!)
        }
    }

    @Test fun `fixed task is not moved by outing`() {
        val outing = LocalDate.of(2026, 10, 18)
        val fixedTask = task("fixed", "2026-10-18", 18 * 60, fixed = true)
        val plan = RescheduleEngine.plan(listOf(fixedTask), outing, settings())
        assertTrue(plan.moved.isEmpty())
        assertEquals(listOf("fixed"), plan.protectedTasks.map { it.sourceId })
    }

    @Test fun `done task is not moved`() {
        val outing = LocalDate.of(2026, 10, 18)
        val doneTask = task("done", "2026-10-18", 16 * 60, flexible = true, done = true)
        val plan = RescheduleEngine.plan(listOf(doneTask), outing, settings())
        assertTrue(plan.moved.isEmpty())
    }

    @Test fun `task is not moved before original date and original time is preserved`() {
        val outing = LocalDate.of(2026, 10, 18)
        val candidate = task("move", "2026-10-18", 16 * 60, flexible = true)
        val plan = RescheduleEngine.plan(listOf(candidate), outing, settings())
        val moved = plan.moved.single()
        assertTrue(moved.date >= candidate.date)
        assertEquals("2026-10-18", moved.originalDate)
        assertEquals(16 * 60, moved.originalStartMin)
    }

    @Test fun `unplaceable task remains listed and is not deleted`() {
        val outing = LocalDate.of(2026, 10, 18)
        val blocked = Settings(wakeMin = 6 * 60, schoolStart = 6 * 60 + 30, schoolEnd = 6 * 60 + 60,
            sleepMin = 7 * 60, breakMin = 15, dailyGoalMin = 30, maxPostponeDays = 2)
        val candidate = task("blocked", "2026-10-18", null, duration = 90, flexible = true)
        val plan = RescheduleEngine.plan(listOf(candidate), outing, blocked)
        assertTrue(plan.hasUnplaced)
        assertEquals("blocked", plan.unplaced.single().sourceId)
    }

    // ===== إعادة الجدولة تحترم قيود «توزيع الأسبوع» المحفوظة مع الجدول (WeekPlanSnapshot)، لا الوقت فقط =====
    @Test fun `outing skips a weekday not allowed for the task's subject per the saved week plan`() {
        val outing = LocalDate.of(2026, 10, 18)
        val candidate = task("move", "2026-10-18", 16 * 60, flexible = true)
        val dayPlus1 = ScheduleParser.weekday(outing.plusDays(1))
        val dayPlus2 = ScheduleParser.weekday(outing.plusDays(2))
        // «رياضيات» (مادة المهمة) مسموحة فقط يوم dayPlus2 — اليوم التالي مباشرة ممنوع رغم توفر الوقت فيه.
        val constraints = WeekPlanSnapshot(newDays = mapOf("رياضيات" to setOf(dayPlus2)))
        val plan = RescheduleEngine.plan(listOf(candidate), outing, settings(), constraints)
        val moved = plan.moved.single()
        assertEquals(outing.plusDays(2).toString(), moved.date)
        assertNotEquals(dayPlus1, ScheduleParser.weekday(LocalDate.parse(moved.date)))
    }

    @Test fun `outing never lands on a saved rest day even when the time slot is otherwise free`() {
        val outing = LocalDate.of(2026, 10, 18)
        val candidate = task("move", "2026-10-18", 16 * 60, flexible = true)
        val dayPlus1 = ScheduleParser.weekday(outing.plusDays(1))
        val constraints = WeekPlanSnapshot(restDays = setOf(dayPlus1))
        val plan = RescheduleEngine.plan(listOf(candidate), outing, settings(), constraints)
        val moved = plan.moved.single()
        assertNotEquals(outing.plusDays(1).toString(), moved.date)
    }

    @Test fun `task stays unplaced rather than violating its subject's allowed days`() {
        val outing = LocalDate.of(2026, 10, 18)
        val candidate = task("move", "2026-10-18", 16 * 60, flexible = true)
        // لا يوم فعلي يطابق «لا يوم» ضمن نافذة التأجيل بكاملها — يجب ألا تُخالَف القاعدة بإيجاد يوم بديل.
        val constraints = WeekPlanSnapshot(newDays = mapOf("رياضيات" to setOf("لا يوم")))
        val plan = RescheduleEngine.plan(listOf(candidate), outing, settings(), constraints)
        assertTrue(plan.hasUnplaced)
        assertEquals("move", plan.unplaced.single().sourceId)
    }
}

class JsonCodecTest {
    @Test fun `task and progress survive json round trip`() {
        val t = TaskEntity(
            id = "s::1", scheduleId = "s", sourceId = "1", date = "2026-10-18", dayName = "الأحد",
            subject = "فيزياء", type = TaskTypes.NEW, title = "محاضرة", lectureNo = 5,
            durationMin = 75, startMin = 16 * 60, endMin = 17 * 60 + 15, flexible = true,
            fixed = false, notify = true, note = "ملاحظة", originalDate = "2026-10-17",
            originalStartMin = 15 * 60, originalEndMin = 16 * 60, rescheduleReason = "طلعة"
        )
        val restored = JsonCodec.taskFromJson(JsonCodec.taskToJson(t))
        assertEquals(t, restored)
        val p = ProgressEntity("s::1", true, 123L, 50)
        assertEquals(p, JsonCodec.progressFromJson(JsonCodec.progressToJson(p)))
    }
}
