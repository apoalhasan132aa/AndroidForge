package com.rafiq6.study

import org.junit.Assert.*
import org.junit.Test

class ScheduleGeneratorTest {

    // فترة 2026-01-03 (سبت) → 2026-01-16 (جمعة). فيزياء تنشر الأحد والأربعاء، كيمياء الاثنين.
    private fun base(daily: Int = 240) = WizardDraft(
        subjects = listOf("الفيزياء", "الكيمياء"),
        backlogs = mapOf("الفيزياء" to 10, "الكيمياء" to 6),
        firstOldNo = mapOf("الفيزياء" to 5, "الكيمياء" to 1),
        firstNewNo = mapOf("الفيزياء" to 20),
        startDate = "2026-01-03", endDate = "2026-01-16",
        dailyStudyMin = daily, lectureDur = 45, oldOnly = false,
        newLectureDays = mapOf("الفيزياء" to setOf("الأحد", "الأربعاء"), "الكيمياء" to setOf("الاثنين")))

    private fun tasksOf(p: GeneratedPlan) = p.file!!.days.flatMap { day -> day.tasks.map { day.date.toString() to it } }

    @Test fun generatesImportableFileWithAllTasks() {
        val p = ScheduleGenerator.generate(base())
        assertTrue(p.errors.toString() + p.missingInputs, p.ok)
        val all = tasksOf(p)
        assertEquals(22, all.size)                                   // 6 جديد + 16 قديم
        assertEquals(6, all.count { it.second.type == TaskTypes.NEW })
        assertEquals(16, all.count { it.second.type == TaskTypes.OLD })
        assertEquals(22, all.map { it.second.id }.toSet().size)       // لا تكرار
        // الاستيراد الفعلي: نص JSON → محلل التطبيق → كيانات قاعدة البيانات
        val re = ScheduleParser.parse(p.json!!)
        assertTrue(re.errors.toString(), re.ok)
        val ents = ScheduleParser.toEntities("t", re.file!!)
        assertEquals(22, ents.size)
        assertEquals(22, ents.map { it.id }.toSet().size)
        assertEquals(all.map { it.second.id }.toSet(), ents.map { it.sourceId }.toSet())
    }

    @Test fun newLecturesAppearOnTheirPublishDatesOnly() {
        val all = tasksOf(ScheduleGenerator.generate(base()))
        val phys = all.filter { it.second.type == TaskTypes.NEW && it.second.subject == "الفيزياء" }
        assertEquals(listOf("2026-01-04", "2026-01-07", "2026-01-11", "2026-01-14"), phys.map { it.first })
        assertEquals(listOf(20, 21, 22, 23), phys.map { it.second.lectureNo })
        val chem = all.filter { it.second.type == TaskTypes.NEW && it.second.subject == "الكيمياء" }
        assertEquals(listOf("2026-01-05", "2026-01-12"), chem.map { it.first })
        assertTrue(chem.all { it.second.lectureNo == null })          // لا رقم مُدخل → لا نخمّن
    }

    @Test fun oldLectureNumbersAreSequentialFromUserInputAndNeverRepeat() {
        val old = tasksOf(ScheduleGenerator.generate(base())).filter { it.second.type == TaskTypes.OLD }
        assertEquals((5..14).toList(), old.filter { it.second.subject == "الفيزياء" }.mapNotNull { it.second.lectureNo }.sorted())
        assertEquals((1..6).toList(), old.filter { it.second.subject == "الكيمياء" }.mapNotNull { it.second.lectureNo }.sorted())
    }

    @Test fun dailyMinutesNeverExceedLimitAndDeficitIsReported() {
        val d = base(90).copy(backlogs = mapOf("الفيزياء" to 20, "الكيمياء" to 12), autoExtend = false)
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.ok)
        assertTrue(p.summary!!.dailyMin.values.all { it <= 90 })
        assertEquals(10, p.summary!!.leftoverOld)
        assertFalse(p.summary!!.feasible)
        val phys = p.summary!!.perSubject.first { it.subject == "الفيزياء" }
        assertEquals(15, phys.oldPlaced); assertEquals(5, phys.oldLeftover)
        assertEquals(5 + 15, phys.firstLeftoverNo)                    // أول رقم لم يُجدول
        assertTrue(p.warnings.any { it.contains("عجز") })
    }

    @Test fun missingFirstOldNumberBlocksGenerationInsteadOfGuessing() {
        val p = ScheduleGenerator.generate(base().copy(firstOldNo = mapOf("الكيمياء" to 1)))
        assertFalse(p.ok); assertNull(p.json)
        assertTrue(p.missingInputs.any { it.contains("الفيزياء") && it.contains("رقم أول محاضرة") })
    }

    @Test fun zeroBacklogDoesNotRequireFirstNumber() {
        val d = base().copy(backlogs = mapOf("الفيزياء" to 0, "الكيمياء" to 0), firstOldNo = emptyMap())
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString() + p.missingInputs, p.ok)
        assertEquals(0, p.summary!!.oldCount); assertEquals(6, p.summary!!.newCount)
    }

    @Test fun restDayDefersNewLectureWithoutDroppingIt() {
        val p = ScheduleGenerator.generate(base().copy(restDays = setOf("الأحد")))
        assertTrue(p.ok)
        val all = tasksOf(p)
        assertTrue(all.none { it.first == "2026-01-04" || it.first == "2026-01-11" })   // أيام الأحد
        val mon = all.filter { it.first == "2026-01-05" && it.second.type == TaskTypes.NEW }
        assertEquals(2, mon.size)
        assertTrue(mon.any { it.second.note?.contains("نُقلت") == true })
        assertEquals(6, all.count { it.second.type == TaskTypes.NEW })
    }

    @Test fun examsAreSeparateTypesAndNotCountedAsNewLectures() {
        val ex = ExamEntry(id = "e1", day = "الاثنين", kind = "daily", subjects = listOf("الفيزياء"),
            time = "19:00", durationMin = 30)
        val p = ScheduleGenerator.generate(base().copy(exams = listOf(ex)))
        assertTrue(p.errors.toString() + p.missingInputs, p.ok)
        val all = tasksOf(p)
        val exams = all.filter { it.second.type == TaskTypes.DAILY_EXAM }
        assertEquals(listOf("2026-01-05", "2026-01-12"), exams.map { it.first })
        assertEquals(19 * 60, exams.first().second.startMin)
        assertEquals(6, all.count { it.second.type == TaskTypes.NEW })
        assertEquals(2, p.summary!!.examCount)
        assertTrue(p.summary!!.dailyMin.values.all { it <= 240 })
    }

    @Test fun examWithoutDurationIsRejectedAndEarlyTimeIsNotForced() {
        val noDur = ExamEntry(id = "e2", day = "الاثنين", kind = "daily", subjects = listOf("الفيزياء"), durationMin = null)
        assertFalse(ScheduleGenerator.generate(base().copy(exams = listOf(noDur))).ok)
        val early = noDur.copy(durationMin = 30, time = "17:00")
        val p = ScheduleGenerator.generate(base().copy(exams = listOf(early)))
        assertTrue(p.errors.toString(), p.ok)                          // لا يكسر الاستيراد
        val e = tasksOf(p).first { it.second.type == TaskTypes.DAILY_EXAM }.second
        assertNull(e.startMin)
        assertTrue(e.note!!.contains("7:00"))
    }

    @Test fun weekPlanRestrictsOldOnly() {
        val d = base().copy(weekPlan = mapOf("السبت" to setOf("الفيزياء", "الكيمياء")), autoExtend = false, oldOnly = true)
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString(), p.ok)
        val old = tasksOf(p).filter { it.second.type == TaskTypes.OLD }
        assertEquals(10, old.size)                                     // 5 كل سبت × سبتين
        assertTrue(old.all { it.first == "2026-01-03" || it.first == "2026-01-10" })
        assertEquals(6, p.summary!!.leftoverOld)
    }

    @Test fun oldOnlyCreatesNoNewLectures() {
        val p = ScheduleGenerator.generate(base().copy(oldOnly = true))
        assertTrue(p.ok)
        assertEquals(0, p.summary!!.newCount)
        assertEquals(16, p.summary!!.oldCount)
    }

    @Test fun matchesPlanAllocatorTotals() {
        val d = base(120)
        val r = PlanAllocator.allocate(d)!!
        val p = ScheduleGenerator.generate(d)
        assertEquals(r.totalNewMin, p.summary!!.newMin)
        assertEquals(r.totalOldFittedMin, p.summary!!.oldMin)
        assertEquals(r.totalOldLeftover, p.summary!!.leftoverOld)
    }

    @Test fun statsAndComplianceAcceptGeneratedFile() {
        val d = base()
        val p = ScheduleGenerator.generate(d)
        assertTrue(WizardVerify.compliance(p.file!!, d).isEmpty())
        val st = WizardVerify.stats(p.file!!, d)
        assertEquals(16, st.oldLectures); assertEquals(6, st.newLectures)
        assertTrue(st.missingNew.isEmpty())
        assertTrue(st.warnings.toString(), st.warnings.isEmpty())
    }

    @Test fun draftCodecKeepsFirstNumbersAndOldDraftsStillLoad() {
        val back = WizardDraftCodec.fromJson(WizardDraftCodec.toJson(base()))
        assertEquals(base().firstOldNo, back.firstOldNo)
        assertEquals(base().firstNewNo, back.firstNewNo)
        val legacy = WizardDraftCodec.toJson(base()).apply { remove("firstOldNo"); remove("firstNewNo") }
        val d = WizardDraftCodec.fromJson(legacy)
        assertTrue(d.firstOldNo.isEmpty() && d.firstNewNo.isEmpty())
    }

    @Test fun promptCarriesFirstOldNumber() {
        assertTrue(WizardPromptBuilder.build(base()).contains("أول محاضرة قديمة متبقية رقم 5"))
    }
}
