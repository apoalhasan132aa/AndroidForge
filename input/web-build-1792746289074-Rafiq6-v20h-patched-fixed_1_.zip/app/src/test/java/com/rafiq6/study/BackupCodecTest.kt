package com.rafiq6.study

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class BackupCodecTest {
    private fun sched(id: String, active: Boolean, hash: String? = null) =
        ScheduleEntity(scheduleId = id, name = "جدول $id", importedAt = 1_700_000_000_000L, active = active, contentHash = hash)

    private fun task(sid: String, n: Int, date: String = "2026-01-0${n}") = TaskEntity(
        id = "$sid::t$n", scheduleId = sid, sourceId = "t$n", date = date, dayName = "السبت", subject = "الفيزياء",
        type = TaskTypes.OLD, title = "تراكم $n", lectureNo = n, durationMin = 45, startMin = null, endMin = null)

    private fun data(): BackupData {
        val t = listOf(task("a", 1), task("a", 2), task("a", 3), task("b", 1), task("b", 2))
        return BackupData(
            schedules = listOf(sched("a", true, "h1"), sched("b", false)),
            tasks = t,
            progress = listOf(ProgressEntity("a::t1", true, 111L, 45), ProgressEntity("a::t2", true, 222L, 40), ProgressEntity("b::t1", false)),
            activities = listOf(ActivityEntity("x1", "2026-01-02", "قراءة", "رواية", 30, null)),
            documents = emptyList(), pageTexts = emptyList(), questions = emptyList(), attempts = emptyList(), answers = emptyList(),
            settings = Settings(dark = true, focusPin = false, dailyGoalMin = 600, outingDates = "2026-01-02"),
            focusHistory = JSONObject().put("sessions", 7L).put("minutes", 175L).put("recent", org.json.JSONArray()))
    }

    private fun json(d: BackupData = data()): JSONObject = BackupCodec.toJson(d, 1_700_000_000_123L)

    @Test fun roundTripKeepsEveryCountAndValue() {
        val before = data()
        val r = BackupCodec.parse(json(before).toString(2))
        assertTrue(r.errorText(), r.ok)
        val after = r.data!!
        assertEquals(before.schedules, after.schedules)           // يشمل contentHash والنشاط
        assertEquals(before.tasks, after.tasks)
        assertEquals(before.progress.toSet(), after.progress.toSet())
        assertEquals(before.activities, after.activities)
        assertEquals(before.settings, after.settings)
        assertEquals(7L, after.focusHistory!!.getLong("sessions"))
        val s = r.summary!!
        assertEquals(2, s.schedules); assertEquals(5, s.tasks); assertEquals(2, s.doneTasks)
        assertEquals(1_700_000_000_123L, s.createdAt)
        assertTrue(r.warnings.isEmpty())
    }

    @Test fun oldBackupWithoutNewOptionalFieldsStillRestores() {
        val o = json()
        o.remove("settings"); o.remove("focusHistory")
        o.getJSONArray("schedules").let { a -> for (i in 0 until a.length()) a.getJSONObject(i).remove("contentHash") }
        val r = BackupCodec.parse(o.toString())
        assertTrue(r.errorText(), r.ok)
        assertNull(r.data!!.settings); assertNull(r.data!!.focusHistory)
        assertTrue(r.data!!.schedules.all { it.contentHash == null })
        assertFalse(r.summary!!.hasSettings)
    }

    @Test fun corruptOrTruncatedFileGivesClearMessageAndNoData() {
        val text = json().toString()
        val r = BackupCodec.parse(text.substring(0, text.length / 2))
        assertFalse(r.ok); assertNull(r.data)
        assertTrue(r.errors.first().contains("JSON"))
        assertFalse(BackupCodec.parse("").ok)
    }

    @Test fun wrongFormatAndFutureVersionAreRejectedExplicitly() {
        assertTrue(BackupCodec.parse("""{"format":"other","formatVersion":1}""").errors.first().contains("format"))
        val future = json().put("formatVersion", 2)
        assertTrue(BackupCodec.parse(future.toString()).errors.first().contains("أحدث"))
    }

    @Test fun missingRequiredSectionsAndBrokenElementsAreReportedWithPaths() {
        val noTasks = json().apply { remove("tasks") }
        assertTrue(BackupCodec.parse(noTasks.toString()).errors.any { it.contains("tasks") })
        val broken = json().apply { getJSONArray("tasks").getJSONObject(2).remove("subject") }
        val r = BackupCodec.parse(broken.toString())
        assertFalse(r.ok); assertTrue(r.errors.any { it.startsWith("tasks[2]") })
    }

    @Test fun integrityProblemsBlockRestore() {
        // مهمة بجدول غير موجود
        val orphan = data().let { it.copy(tasks = it.tasks + task("zzz", 9)) }
        assertTrue(BackupCodec.parse(json(orphan).toString()).errors.any { it.contains("جدول غير موجود") })
        // معرّف مهمة مكرر
        val dup = data().let { it.copy(tasks = it.tasks + it.tasks.first()) }
        assertTrue(BackupCodec.parse(json(dup).toString()).errors.any { it.contains("مكرر") })
        // تاريخ غير صالح
        val badDate = data().let { it.copy(tasks = it.tasks + task("a", 8, "2026-02-30")) }
        assertTrue(BackupCodec.parse(json(badDate).toString()).errors.any { it.contains("تاريخ غير صالح") })
        // لا جداول
        val none = data().copy(schedules = emptyList(), tasks = emptyList(), progress = emptyList())
        assertFalse(BackupCodec.parse(json(none).toString()).ok)
    }

    @Test fun orphanAndDuplicateProgressAreDroppedWithWarningNotSilently() {
        val d = data().let { it.copy(progress = it.progress + ProgressEntity("ghost::t1", true) + ProgressEntity("a::t1", true, 999L)) }
        val r = BackupCodec.parse(json(d).toString())
        assertTrue(r.errorText(), r.ok)
        assertEquals(3, r.data!!.progress.size)                   // a::t1 مرة واحدة + a::t2 + b::t1
        assertTrue(r.warnings.any { it.contains("إنجاز") })
    }

    @Test fun settingsCodecUsesDefaultsForMissingKeys() {
        val s = BackupCodec.settingsFromJson(JSONObject().put("dark", true))
        assertEquals(Settings(dark = true), s)
    }

    @Test fun backupContainsNoSecretsOrDeviceBoundSelections() {
        val text = json().toString()
        listOf("allowed", "focus_allowed", "draft", "sid", "password", "token").forEach {
            assertFalse("لا يجب أن تظهر $it", text.contains("\"$it\""))
        }
    }
}
