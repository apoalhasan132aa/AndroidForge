package com.rafiq6.study

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

/** اختبارات التوزيع الذكي وتمديد الجدول تلقائيًا (الخطوة 3). فترة الأساس: 2026-01-03 (سبت) → 2026-01-09 (جمعة). */
class ScheduleExtensionTest {
    private val phys = "الفيزياء"; private val chem = "الكيمياء"

    private fun draft(
        backlogs: Map<String, Int>, dur: Int = 45, daily: Int = 240,
        plan: Map<String, Set<String>> = emptyMap(), rest: Set<String> = emptySet(),
        oldOnly: Boolean = true, pub: Map<String, Set<String>> = emptyMap(),
        durBy: Map<String, Int> = emptyMap(), end: String = "2026-01-09", extend: Boolean = true
    ) = WizardDraft(
        subjects = backlogs.keys.toList(), backlogs = backlogs,
        firstOldNo = backlogs.keys.associateWith { 1 }, startDate = "2026-01-03", endDate = end,
        dailyStudyMin = daily, lectureDur = dur, lectureDurBy = durBy, weekPlan = plan,
        restDays = rest, oldOnly = oldOnly, newLectureDays = pub, autoExtend = extend)

    private fun tasks(p: GeneratedPlan) = p.file!!.days.flatMap { day -> day.tasks.map { day.date to it } }
    private fun dayName(d: LocalDate) = WizardConst.dayOfWeekName(d.dayOfWeek)
    private val fourDays = setOf("الأحد", "الاثنين", "الأربعاء", "الخميس")

    // 1) تراكم قليل يكتمل في الأسبوع الأول بلا تمديد
    @Test fun smallBacklogFinishesInOneWeekWithoutExtension() {
        val p = ScheduleGenerator.generate(draft(mapOf(phys to 5, chem to 3)))
        assertTrue(p.errors.toString(), p.ok)
        assertEquals(0, p.summary!!.extraDays)
        assertEquals("2026-01-09", p.summary!!.effectiveEnd)
        assertEquals(0, p.summary!!.leftoverOld)
    }

    // 2) تراكم كبير يحتاج أسابيع إضافية (90 × 75د، 4 أيام، 6 ساعات) — الأرقام مثال المتطلبات
    @Test fun bigBacklogExtendsByWholeWeeksAndFinishes() {
        val d = draft(mapOf(phys to 90), dur = 75, daily = 360, plan = mapOf(
            "الأحد" to setOf(phys), "الاثنين" to setOf(phys), "الأربعاء" to setOf(phys), "الخميس" to setOf(phys)))
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString(), p.ok)
        // 4 محاضرات (300د) في اليوم → 23 يوم دراسة؛ الأسبوع الأول يحوي 4 أيام فقط
        assertEquals(33, p.summary!!.extraDays)
        assertEquals(5, p.summary!!.extraWeeks)
        assertEquals("2026-02-11", p.summary!!.effectiveEnd)
        assertEquals(0, p.summary!!.leftoverOld); assertTrue(p.summary!!.feasible)
        assertEquals(90, tasks(p).count { it.second.type == TaskTypes.OLD })
        assertEquals(LocalDate.of(2026, 2, 11), p.file!!.endDate)
        assertTrue(WizardVerify.compliance(p.file!!, d).isEmpty())
        // المُخصص (معاينة الخطوة 3) يطابق المولّد
        val r = PlanAllocator.allocate(d)!!
        assertEquals(33, r.extendedDays); assertEquals(LocalDate.of(2026, 2, 11), r.effectiveEnd)
        assertTrue(r.feasible); assertFalse(r.extensionBlocked)
    }

    // 3) مادة بأيام دراسة محددة فقط — حتى في الأسابيع الممدّدة
    @Test fun subjectOnlyOnItsAllowedDaysEvenInExtension() {
        val plan = mapOf("الأحد" to setOf(phys), "الاثنين" to setOf(phys), "الثلاثاء" to setOf(chem))
        val p = ScheduleGenerator.generate(draft(mapOf(phys to 40, chem to 20), plan = plan))
        assertTrue(p.errors.toString(), p.ok)
        assertTrue(p.summary!!.extraDays > 0)
        tasks(p).forEach { (date, t) ->
            val allowed = plan[dayName(date)] ?: emptySet()
            assertTrue("${t.subject} يوم ${dayName(date)}", t.subject in allowed)
        }
        assertEquals(0, p.summary!!.leftoverOld)
    }

    // 4) يوم راحة لا تُجدول فيه مهام (أصل الفترة وبعدها)
    @Test fun restDaysStayEmptyThroughExtension() {
        val rest = setOf("الجمعة", "الأحد")
        val p = ScheduleGenerator.generate(draft(mapOf(phys to 60), rest = rest, oldOnly = false,
            pub = mapOf(phys to setOf("الأحد", "الأربعاء"))))
        assertTrue(p.errors.toString(), p.ok)
        assertTrue(p.summary!!.extraDays > 0)
        assertTrue(tasks(p).none { dayName(it.first) in rest })
    }

    // 5) لا يُتجاوز الحد اليومي أبدًا، وتُحسب المحاضرة بدقائقها كاملة
    @Test fun dailyLimitNeverExceededWithOddDurations() {
        val d = draft(mapOf(phys to 40, chem to 25), dur = 75, daily = 360, oldOnly = false,
            pub = mapOf(phys to setOf("الأحد", "الأربعاء"), chem to setOf("الاثنين")))
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString(), p.ok)
        assertTrue(p.summary!!.dailyMin.values.all { it <= 360 })
        tasks(p).forEach { assertEquals(75, it.second.durationMin) }
        assertTrue(PlanAllocator.allocate(d)!!.days.all { it.newMin + it.examMin + it.oldMin <= 360 })
    }

    // 6) مدد مختلفة بين المواد
    @Test fun perSubjectDurationsAreRespected() {
        val d = draft(mapOf(phys to 8, chem to 8), dur = 45, daily = 240, durBy = mapOf(phys to 75, chem to 30))
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString(), p.ok)
        val t = tasks(p).map { it.second }
        assertTrue(t.filter { it.subject == phys }.all { it.durationMin == 75 })
        assertTrue(t.filter { it.subject == chem }.all { it.durationMin == 30 })
        assertEquals(8 * 75 + 8 * 30, p.summary!!.oldMin)
        assertEquals(8 * 75 + 8 * 30, PlanAllocator.allocate(d)!!.totalOldNeededMin)
        assertTrue(p.summary!!.dailyMin.values.all { it <= 240 })
    }

    // 7) قديم وجديد معًا: الجديد يستمر في الأسابيع الممدّدة والقديم يكتمل
    @Test fun oldAndNewCoexistAndNewContinuesInExtension() {
        val d = draft(mapOf(phys to 30), dur = 45, daily = 135, oldOnly = false,
            pub = mapOf(phys to setOf("الأحد", "الأربعاء")))
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString(), p.ok)
        val s = p.summary!!
        assertTrue(s.extraDays > 0); assertEquals(0, s.leftoverOld)
        val origEnd = LocalDate.of(2026, 1, 9)
        assertTrue(tasks(p).any { it.second.type == TaskTypes.NEW && it.first.isAfter(origEnd) })
        assertTrue(s.dailyMin.values.all { it <= 135 })
        val r = PlanAllocator.allocate(d)!!
        assertEquals(r.totalNewMin, s.newMin); assertEquals(r.totalOldFittedMin, s.oldMin)
        assertEquals(LocalDate.parse(s.effectiveEnd), r.effectiveEnd)
    }

    // 8) لا تكرار ولا إسقاط: أرقام القديم متسلسلة بلا فجوات ولا معرّفات مكررة
    @Test fun noDuplicatesOrDroppedLectures() {
        val p = ScheduleGenerator.generate(draft(mapOf(phys to 37, chem to 22), daily = 180))
        assertTrue(p.errors.toString(), p.ok)
        val old = tasks(p).map { it.second }.filter { it.type == TaskTypes.OLD }
        assertEquals((1..37).toList(), old.filter { it.subject == phys }.mapNotNull { it.lectureNo }.sorted())
        assertEquals((1..22).toList(), old.filter { it.subject == chem }.mapNotNull { it.lectureNo }.sorted())
        val ids = tasks(p).map { it.second.id }
        assertEquals(ids.size, ids.toSet().size)
    }

    // 9) مادة بلا أي يوم مسموح: لا توليد ولا حلقة، والرسالة تسمّي المادة
    @Test fun subjectWithNoAllowedDayIsReportedNotExtended() {
        val d = draft(mapOf(phys to 5, chem to 5), plan = mapOf("الأحد" to setOf(chem)))
        val p = ScheduleGenerator.generate(d)
        assertFalse(p.ok); assertNull(p.json)
        assertTrue(p.missingInputs.any { it.contains(phys) })
        // أيام المادة كلها راحة = نفس الحالة
        val allRest = draft(mapOf(phys to 5), plan = mapOf("الأحد" to setOf(phys)), rest = setOf("الأحد"))
        assertTrue(ScheduleGenerator.generate(allRest).missingInputs.any { it.contains(phys) })
    }

    // 10) جديد مستمر يستهلك كل الوقت: لا إدّعاء بالإكمال، ويُقصّ الجدول بلا تمديد عبثي
    @Test fun continuousNewLoadBlocksExtensionWithHonestWarning() {
        val d = draft(mapOf(phys to 5), dur = 60, daily = 60, oldOnly = false,
            pub = mapOf(phys to WizardConst.DAYS.toSet()))
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString(), p.ok)
        assertTrue(p.summary!!.extensionBlocked)
        assertEquals(5, p.summary!!.leftoverOld); assertFalse(p.summary!!.feasible)
        assertEquals("2026-01-09", p.summary!!.effectiveEnd)
        assertTrue(p.warnings.any { it.contains("لم يُمدَّد") })
        val r = PlanAllocator.allocate(d)!!
        assertTrue(r.extensionBlocked); assertEquals(5, r.totalOldLeftover); assertFalse(r.feasible)
    }

    // 11) الحفظ وإعادة التحميل: المسودة والملف الناتج يعودان كما هما
    @Test fun draftAndGeneratedFileSurviveReload() {
        val d = draft(mapOf(phys to 30), durBy = mapOf(phys to 50), extend = false)
        val back = WizardDraftCodec.fromJson(JSONObject(WizardDraftCodec.toJson(d).toString()))
        assertEquals(50, back.durOf(phys)); assertFalse(back.autoExtend)
        // مسودة قديمة بلا الحقلين: تمديد مفعّل ومدة عامة
        val old = JSONObject(WizardDraftCodec.toJson(d).toString()).apply { remove("lectureDurBy"); remove("autoExtend") }
        val legacy = WizardDraftCodec.fromJson(old)
        assertTrue(legacy.autoExtend); assertEquals(legacy.lectureDur, legacy.durOf(phys))
        // الملف الممدّد يُستورد بنفس عدد الأيام والمهام
        val p = ScheduleGenerator.generate(draft(mapOf(phys to 60)))
        val reparsed = ScheduleParser.parse(p.json!!)
        assertTrue(reparsed.ok)
        assertEquals(p.file!!.days.size, reparsed.file!!.days.size)
        assertEquals(p.file!!.taskCount(), reparsed.file!!.taskCount())
        assertEquals(p.file!!.endDate, reparsed.file!!.endDate)
    }

    // 12) لا حلقة لا نهائية: تراكم ضخم بيوم واحد يتوقف عند السقف، وعدد الأسابيع منطقي
    @Test fun hugeBacklogStopsAtCapAndReportsDeficit() {
        val d = draft(mapOf(phys to 1000), daily = 45, plan = mapOf("السبت" to setOf(phys)))
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString(), p.ok)
        val s = p.summary!!
        assertTrue(s.extensionBlocked)
        assertTrue(s.extraDays in 1..ExtensionTracker.MAX_EXTRA_DAYS)
        assertEquals((s.extraDays + 6) / 7, s.extraWeeks)
        assertTrue(s.leftoverOld > 0); assertFalse(s.feasible)
        assertEquals(1000, s.leftoverOld + tasks(p).count { it.second.type == TaskTypes.OLD })
        assertTrue(p.warnings.any { it.contains("عجز") })
    }

    // الخطوة 3 = أيام الجديد؛ والتراكم يُوزَّع بالتساوي على كل أيام الدراسة (لا يتكدس في البداية)
    @Test fun oldBacklogIsLeveledAcrossDaysAroundNewLectures() {
        val d = draft(mapOf(phys to 14), dur = 60, daily = 240, oldOnly = false,
            plan = mapOf("الأحد" to setOf(phys), "الأربعاء" to setOf(phys)))   // أيام الجديد من الخطوة 3
        val p = ScheduleGenerator.generate(d)
        assertTrue(p.errors.toString(), p.ok)
        val t = tasks(p)
        assertEquals(0, p.summary!!.extraDays); assertEquals(0, p.summary!!.leftoverOld)
        val newT = t.filter { it.second.type == TaskTypes.NEW }
        assertEquals(2, newT.size)
        assertTrue(newT.all { dayName(it.first) == "الأحد" || dayName(it.first) == "الأربعاء" })
        val oldByDay = t.filter { it.second.type == TaskTypes.OLD }.groupBy { it.first }
        assertEquals(14, oldByDay.values.sumOf { it.size })
        assertTrue("موزّع على ${oldByDay.size} أيام فقط", oldByDay.size >= 6)
        assertTrue(oldByDay.values.all { it.size <= 3 })
        assertTrue(p.summary!!.dailyMin.values.all { it <= 240 })
        val r = PlanAllocator.allocate(d)!!
        assertEquals(14 * 60, r.totalOldFittedMin)
        assertTrue(r.days.count { it.oldMin > 0 } >= 6)
    }

    // تعطيل التمديد يحافظ على السلوك القديم (عجز ضمن الفترة)
    @Test fun extensionCanBeDisabled() {
        val p = ScheduleGenerator.generate(draft(mapOf(phys to 90), daily = 90, extend = false))
        assertTrue(p.ok)
        assertEquals(0, p.summary!!.extraDays); assertTrue(p.summary!!.leftoverOld > 0)
        assertFalse(p.summary!!.extensionBlocked)
    }
}
