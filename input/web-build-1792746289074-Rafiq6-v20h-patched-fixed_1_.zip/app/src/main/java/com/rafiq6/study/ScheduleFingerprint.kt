package com.rafiq6.study

import java.security.MessageDigest

/**
 * بصمة محتوى الجدول: SHA-256 لمحتوى المهام فقط (التاريخ، المعرّف، المادة، النوع، العنوان، الرقم، المدة،
 * الأوقات، العلامات، الملاحظة) بعد ترتيبها. لا تدخل فيها أسماء الجدول ولا بياناته الوصفية،
 * فلا يُحجب جدول مختلف لمجرد تشابه اسمه أو نطاق تواريخه، ولا يفلت نسخة مطابقة بتغيير اسمها.
 */
object ScheduleFingerprint {
    private fun rec(
        date: String, id: String, subject: String, type: String, title: String, lectureNo: Int?,
        dur: Int, start: Int?, end: Int?, flexible: Boolean, fixed: Boolean, notify: Boolean, note: String?
    ): String = listOf(date, id, subject, type, title, lectureNo?.toString() ?: "", dur.toString(),
        start?.toString() ?: "", end?.toString() ?: "", flexible.toString(), fixed.toString(),
        notify.toString(), note ?: "").joinToString("\u001F")

    private fun digest(lines: List<String>): String {
        val md = MessageDigest.getInstance("SHA-256")
        lines.sorted().forEach { md.update(it.toByteArray(Charsets.UTF_8)); md.update('\n'.code.toByte()) }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** بصمة ملف مُحلَّل (قبل الحفظ). */
    fun ofFile(f: ScheduleFile): String = digest(f.days.flatMap { d ->
        d.tasks.map { t -> rec(d.date.toString(), t.id, t.subject, t.type, t.title, t.lectureNo,
            t.durationMin, t.startMin, t.endMin, t.flexible, t.fixed, t.notify, t.note) } })

    /**
     * بصمة جدول محفوظ لم تُخزَّن له بصمة (قبل الترقية): تُعاد بناؤها من القيم الأصلية (original*)
     * فتطابق الملف المستورد ما دامت المهام لم تُعدَّل يدويًا.
     */
    fun ofEntities(ts: List<TaskEntity>): String = digest(ts.map { t ->
        // original* تُضبط عند الاستيراد (حتى لو كانت القيمة null) وتحافظ عليها كل عمليات النقل/التعديل؛
        // لذا إن وُجد originalDate فالأوقات الأصلية (ولو null) هي المرجع بلا رجوع للحالية.
        val hasOrig = t.originalDate != null
        rec(t.originalDate ?: t.date, t.sourceId, t.subject, t.type, t.title, t.lectureNo, t.durationMin,
            if (hasOrig) t.originalStartMin else t.startMin, if (hasOrig) t.originalEndMin else t.endMin,
            t.flexible, t.fixed, t.notify, t.note) })
}
