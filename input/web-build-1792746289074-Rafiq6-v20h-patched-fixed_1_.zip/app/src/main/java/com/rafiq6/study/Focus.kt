package com.rafiq6.study

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import java.util.UUID

val Context.focusDs by preferencesDataStore("rafiq6_focus")

object FocusStore {
    private val SID = stringPreferencesKey("sid"); private val TITLE = stringPreferencesKey("title")
    private val PLAN = longPreferencesKey("plan")
    private val SEL = longPreferencesKey("sel"); private val EEL = longPreferencesKey("eel")
    private val SWL = longPreferencesKey("swl"); private val EWL = longPreferencesKey("ewl")
    private val PK = stringPreferencesKey("pk"); private val ENF = booleanPreferencesKey("enf")

    suspend fun state(c: Context): FocusState { val p = c.focusDs.data.first()
        return FocusState(p[SID] ?: "", p[TITLE] ?: "", (p[PLAN] ?: 0L).toInt(),
            p[SEL] ?: 0L, p[EEL] ?: 0L, p[SWL] ?: 0L, p[EWL] ?: 0L, p[SID] != null,
            FocusSelection.decode(p[PK]), p[ENF] ?: false) }

    suspend fun start(c: Context, title: String, planMin: Int, allowed: List<String> = emptyList()): FocusState {
        val nowE = SystemClock.elapsedRealtime(); val nowW = System.currentTimeMillis()
        val s = FocusState(UUID.randomUUID().toString(), title, planMin,
            nowE, nowE + planMin * 60_000L, nowW, nowW + planMin * 60_000L, true,
            allowed.distinct().take(FocusSelection.MAX_APPS), false)
        save(c, s); return s
    }

    suspend fun save(c: Context, s: FocusState) { c.focusDs.edit {
        it[SID] = s.sessionId; it[TITLE] = s.title; it[PLAN] = s.planMin.toLong()
        it[SEL] = s.startElapsedMs; it[EEL] = s.endElapsedMs
        it[SWL] = s.startWallMs; it[EWL] = s.endWallMs
        it[PK] = FocusSelection.encode(s.allowed); it[ENF] = s.enforced } }

    // يمسح مفاتيح الجلسة فقط. (كان clear() يمسح كل شيء فيضيع سجل الجلسات والتطبيقات المختارة.)
    suspend fun clear(c: Context) { c.focusDs.edit {
        it.remove(SID); it.remove(TITLE); it.remove(PLAN); it.remove(SEL); it.remove(EEL)
        it.remove(SWL); it.remove(EWL); it.remove(PK); it.remove(ENF) } }
}

object FocusHistory {
    private val TS = longPreferencesKey("fh_ts"); private val TM = longPreferencesKey("fh_tm")
    private val RC = stringPreferencesKey("fh_rc")
    suspend fun record(c: Context, s: FocusState) { c.focusDs.edit { p ->
        p[TS] = (p[TS] ?: 0L) + 1; p[TM] = (p[TM] ?: 0L) + s.planMin
        val line = "${Subjects.now().toLocalDate()} · ${s.title} · ${s.planMin} دقيقة"
        p[RC] = (listOf(line) + (p[RC] ?: "").lines().filter { it.isNotBlank() }).distinct().take(10).joinToString("\n")
    } }
    suspend fun export(c: Context): org.json.JSONObject { val p = c.focusDs.data.first()
        return org.json.JSONObject().apply {
            put("sessions", p[TS] ?: 0L); put("minutes", p[TM] ?: 0L)
            put("recent", org.json.JSONArray((p[RC] ?: "").lines().filter { it.isNotBlank() }))
        } }
    suspend fun restore(c: Context, o: org.json.JSONObject) { c.focusDs.edit { p ->
        p[TS] = o.optLong("sessions"); p[TM] = o.optLong("minutes")
        val a = o.optJSONArray("recent")
        p[RC] = if (a == null) "" else (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }.take(10).joinToString("\n")
    } }
    suspend fun totals(c: Context): Pair<Long, Long> { val p = c.focusDs.data.first()
        return (p[TS] ?: 0L) to (p[TM] ?: 0L) }
}

object FocusScheduler {
    private const val REQ = 7101
    private fun pi(c: Context) = PendingIntent.getBroadcast(c, REQ,
        Intent(c, FocusEndReceiver::class.java).setAction("com.rafiq6.study.FOCUS_END"),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun arm(c: Context, s: FocusState) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, s.endWallMs, pi(c)) }
        catch (se: SecurityException) { am.setWindow(AlarmManager.RTC_WAKEUP, s.endWallMs, 60_000L, pi(c)) }
    }

    fun disarm(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pi(c))
    }

    // إعادة تسليح المنبه بعد إعادة تشغيل الجهاز (elapsedRealtime تصفّر).
    fun reArmAfterBoot(c: Context) = runBlocking {
        val s = FocusStore.state(c)
        if (s.running && !FocusMath.isExpired(s, SystemClock.elapsedRealtime(), System.currentTimeMillis()))
            arm(c, s)
        else FocusLockdown.release(c)      // انتهت المدة أو لا جلسة: لا نترك قائمة Lock Task مفتوحة
    }
}

class FocusEndReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        if (intent.action != "com.rafiq6.study.FOCUS_END") return
        val go = goAsync()
        try { runBlocking {
            val s = FocusStore.state(c)
            FocusScheduler.disarm(c)
            FocusLockdown.release(c)       // فك التقييد حتى لو كان التطبيق مغلقًا
            if (s.sessionId.isNotEmpty()) {
                FocusHistory.record(c, s)
                Notify.notify(c, 7100, "انتهت جلسة التركيز 🎉",
                    "أكملت «${s.title}» لمدة ${s.planMin} دقيقة. أحسنت!", null)
                FocusStore.clear(c)
            }
        } } finally { go.finish() }
    }
}
