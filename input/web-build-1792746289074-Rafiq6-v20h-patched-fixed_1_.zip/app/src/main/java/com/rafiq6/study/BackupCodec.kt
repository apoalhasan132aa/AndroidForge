package com.rafiq6.study

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

// ===== ترميز النسخة الاحتياطية — منطق نقي (بلا Android) قابل للاختبار على JVM =====
// الصيغة: format=rafiq_full_backup, formatVersion=1. الحقول الجديدة (settings, focusHistory, contentHash)
// اختيارية، فتبقى النسخ القديمة قابلة للاسترجاع وتبقى النسخ الجديدة مقروءة بالإصدارات التي تتجاهلها.
// لا تُحفظ: مسودة المعالج، جلسة التركيز الجارية، حالة المؤقت، التطبيقات المختارة (خاصة بالجهاز)، أي أسرار.

data class BackupData(
    val schedules: List<ScheduleEntity>, val tasks: List<TaskEntity>, val progress: List<ProgressEntity>,
    val activities: List<ActivityEntity>, val documents: List<PdfDocumentEntity>, val pageTexts: List<PdfPageTextEntity>,
    val questions: List<QuestionEntity>, val attempts: List<QuizAttemptEntity>, val answers: List<AttemptAnswerEntity>,
    val settings: Settings? = null, val focusHistory: JSONObject? = null
)

data class BackupSummary(
    val createdAt: Long?, val schedules: Int, val tasks: Int, val doneTasks: Int, val activities: Int,
    val questions: Int, val hasSettings: Boolean, val focusSessions: Long?
)

data class BackupParseResult(
    val data: BackupData?, val summary: BackupSummary?, val errors: List<String>, val warnings: List<String>
) {
    val ok: Boolean get() = data != null && errors.isEmpty()
    fun errorText(): String = errors.take(15).joinToString("\n") { "• $it" } +
        if (errors.size > 15) "\n• … و${errors.size - 15} أخطاء أخرى" else ""
}

object BackupCodec {
    const val FORMAT = "rafiq_full_backup"
    const val VERSION = 1

    fun settingsToJson(s: Settings): JSONObject = JSONObject().apply {
        put("wakeMin", s.wakeMin); put("sleepMin", s.sleepMin); put("schoolStart", s.schoolStart)
        put("schoolEnd", s.schoolEnd); put("breakMin", s.breakMin); put("dailyGoalMin", s.dailyGoalMin)
        put("maxPostponeDays", s.maxPostponeDays); put("dark", s.dark); put("fridayLight", s.fridayLight)
        put("outingDates", s.outingDates); put("focusExitDelaySec", s.focusExitDelaySec)
        put("focusPin", s.focusPin); put("focusDnd", s.focusDnd)
    }

    fun settingsFromJson(o: JSONObject): Settings {
        val d = Settings()
        return Settings(
            wakeMin = o.optInt("wakeMin", d.wakeMin), sleepMin = o.optInt("sleepMin", d.sleepMin),
            schoolStart = o.optInt("schoolStart", d.schoolStart), schoolEnd = o.optInt("schoolEnd", d.schoolEnd),
            breakMin = o.optInt("breakMin", d.breakMin), dailyGoalMin = o.optInt("dailyGoalMin", d.dailyGoalMin),
            maxPostponeDays = o.optInt("maxPostponeDays", d.maxPostponeDays),
            dark = o.optBoolean("dark", d.dark), fridayLight = o.optBoolean("fridayLight", d.fridayLight),
            outingDates = o.optString("outingDates", d.outingDates),
            focusExitDelaySec = o.optInt("focusExitDelaySec", d.focusExitDelaySec),
            focusPin = o.optBoolean("focusPin", d.focusPin), focusDnd = o.optBoolean("focusDnd", d.focusDnd)
        )
    }

    fun activityToJson(a: ActivityEntity): JSONObject = JSONObject().apply {
        put("id", a.id); put("date", a.date); put("kind", a.kind); put("title", a.title)
        put("durationMin", a.durationMin)
        a.startMin?.let { put("startMin", it) } ?: put("startMin", JSONObject.NULL)
        put("done", a.done)
        a.postponedFrom?.let { put("postponedFrom", it) } ?: put("postponedFrom", JSONObject.NULL)
    }

    fun activityFromJson(o: JSONObject): ActivityEntity = ActivityEntity(
        id = o.getString("id"), date = o.getString("date"), kind = o.getString("kind"),
        title = o.getString("title"), durationMin = o.getInt("durationMin"),
        startMin = if (o.isNull("startMin")) null else o.getInt("startMin"),
        done = o.optBoolean("done"),
        postponedFrom = if (o.isNull("postponedFrom")) null else o.optString("postponedFrom")
    )

    fun toJson(d: BackupData, createdAt: Long): JSONObject = JSONObject().apply {
        put("format", FORMAT); put("formatVersion", VERSION); put("createdAt", createdAt)
        put("schedules", JSONArray().apply { d.schedules.forEach { put(JsonCodec.scheduleToJson(it)) } })
        put("tasks", JSONArray().apply { d.tasks.forEach { put(JsonCodec.taskToJson(it)) } })
        put("progress", JSONArray().apply { d.progress.forEach { put(JsonCodec.progressToJson(it)) } })
        put("activities", JSONArray().apply { d.activities.forEach { put(activityToJson(it)) } })
        put("pdfDocuments", JSONArray().apply { d.documents.forEach { put(BankJsonCodec.document(it)) } })
        put("pdfPageTexts", JSONArray().apply { d.pageTexts.forEach { put(BankJsonCodec.page(it)) } })
        put("questions", JSONArray().apply { d.questions.forEach { put(BankJsonCodec.question(it)) } })
        put("quizAttempts", JSONArray().apply { d.attempts.forEach { put(BankJsonCodec.attempt(it)) } })
        put("attemptAnswers", JSONArray().apply { d.answers.forEach { put(BankJsonCodec.answer(it)) } })
        d.settings?.let { put("settings", settingsToJson(it)) }
        d.focusHistory?.let { put("focusHistory", it) }
    }

    fun summarize(d: BackupData, createdAt: Long?): BackupSummary = BackupSummary(
        createdAt, d.schedules.size, d.tasks.size, d.progress.count { it.done }, d.activities.size,
        d.questions.size, d.settings != null, d.focusHistory?.optLong("sessions")
    )

    private fun fail(msg: String) = BackupParseResult(null, null, listOf(msg), emptyList())

    /** يفحص الملف كاملًا قبل أي مساس بقاعدة البيانات. أي خطأ ⇒ لا استرجاع. */
    fun parse(text: String): BackupParseResult {
        val root = try { JSONObject(text.trim()) } catch (e: Exception) {
            return fail("الملف ليس JSON صالحًا (قد يكون تالفًا أو مقطوعًا): ${e.message ?: "خطأ في القراءة"}")
        }
        if (root.optString("format") != FORMAT) return fail("ليس ملف نسخة احتياطية كاملة من رفيق (الحقل format غير صحيح).")
        val ver = root.optInt("formatVersion", -1)
        if (ver != VERSION) return fail(
            if (ver > VERSION) "النسخة أحدث من هذا التطبيق (إصدار الصيغة $ver) — حدّث التطبيق أولًا."
            else "إصدار صيغة النسخة غير مدعوم: $ver.")

        val errors = mutableListOf<String>(); val warnings = mutableListOf<String>()
        fun <T> list(name: String, required: Boolean, f: (JSONObject) -> T): List<T> {
            val a = root.optJSONArray(name)
            if (a == null) { if (required) errors += "الحقل «$name» مفقود أو ليس قائمة."; return emptyList() }
            val out = mutableListOf<T>()
            for (i in 0 until a.length()) {
                try { out += f(a.getJSONObject(i)) }
                catch (e: Exception) { errors += "$name[$i]: بيانات ناقصة أو غير صالحة (${e.message ?: "خطأ"})." }
            }
            return out
        }
        val schedules = list("schedules", true) { JsonCodec.scheduleFromJson(it) }
        val tasks = list("tasks", true) { JsonCodec.taskFromJson(it) }
        val progress = list("progress", true) { JsonCodec.progressFromJson(it) }
        val activities = list("activities", false) { activityFromJson(it) }
        val documents = list("pdfDocuments", false) { BankJsonCodec.document(it) }
        val pageTexts = list("pdfPageTexts", false) { BankJsonCodec.page(it) }
        val questions = list("questions", false) { BankJsonCodec.question(it) }
        val attempts = list("quizAttempts", false) { BankJsonCodec.attempt(it) }
        val answers = list("attemptAnswers", false) { BankJsonCodec.answer(it) }

        if (schedules.isEmpty() && errors.isEmpty()) errors += "النسخة الاحتياطية لا تحتوي أي جدول."
        schedules.groupBy { it.scheduleId }.filter { it.value.size > 1 }.keys
            .forEach { errors += "معرّف جدول مكرر: $it." }
        tasks.groupBy { it.id }.filter { it.value.size > 1 }.keys.take(5)
            .forEach { errors += "معرّف مهمة مكرر: $it." }
        val sIds = schedules.map { it.scheduleId }.toSet()
        val orphanTasks = tasks.count { it.scheduleId !in sIds }
        if (orphanTasks > 0) errors += "$orphanTasks مهمة تشير إلى جدول غير موجود داخل النسخة."
        val badDates = tasks.filter { t -> try { LocalDate.parse(t.date); false } catch (e: Exception) { true } }
        if (badDates.isNotEmpty()) errors += "${badDates.size} مهمة بتاريخ غير صالح (مثل «${badDates.first().date}»)."

        val tIds = tasks.map { it.id }.toSet()
        val keptProgress = progress.filter { it.taskId in tIds }.associateBy { it.taskId }.values.toList()
        val orphanProgress = progress.size - keptProgress.size
        if (orphanProgress > 0) warnings += "$orphanProgress سجل إنجاز بلا مهمة مطابقة أو مكرر — سيُتجاهل."

        val settings = root.optJSONObject("settings")?.let {
            try { settingsFromJson(it) } catch (e: Exception) { warnings += "قسم الإعدادات تالف — ستبقى إعداداتك الحالية."; null }
        }
        val focus = root.optJSONObject("focusHistory")?.takeIf {
            it.optLong("sessions", -1) >= 0 && it.optLong("minutes", -1) >= 0
        }
        if (root.has("focusHistory") && focus == null) warnings += "قسم سجل التركيز غير صالح — سيبقى سجلك الحالي."

        if (errors.isNotEmpty()) return BackupParseResult(null, null, errors, warnings)
        val data = BackupData(schedules, tasks, keptProgress, activities, documents, pageTexts,
            questions, attempts, answers, settings, focus)
        return BackupParseResult(data, summarize(data, if (root.has("createdAt")) root.optLong("createdAt") else null), emptyList(), warnings)
    }
}
