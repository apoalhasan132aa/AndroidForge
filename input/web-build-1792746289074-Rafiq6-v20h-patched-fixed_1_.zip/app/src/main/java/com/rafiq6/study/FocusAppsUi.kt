package com.rafiq6.study

import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

fun Drawable.toBitmapCompat(size: Int): android.graphics.Bitmap {
    val bmp = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bmp)
    setBounds(0, 0, size, size)
    draw(canvas)
    return bmp
}

// شاشة اختيار تطبيقات جلسة التركيز: تطبيق واحد أو تطبيقان، محفوظان بمعرّف الحزمة
@Composable fun FocusAppsScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf<List<LaunchableApp>>(emptyList()) }
    var q by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<List<String>>(emptyList()) }
    var missing by remember { mutableStateOf<List<String>>(emptyList()) }
    var notice by remember { mutableStateOf("") }

    var loading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf(false) }
    fun refresh() {
        loading = true; loadError = false
        apps = try { queryLaunchableApps(ctx) }
        catch (e: Exception) { loadError = true; emptyList() }
        loading = false
    }
    LaunchedEffect(Unit) {
        refresh()
        val saved = try { FocusAppsStore.allowedOf(ctx) } catch (e: Exception) { emptyList() }
        // تطبيق حُذف أو عُطّل بعد حفظه: نخبر المستخدم ونزيله من الاختيار بدل الاحتفاظ به صامتًا
        val (ok, gone) = FocusLockdown.launchable(ctx, saved)
        selected = ok; missing = gone
        if (gone.isNotEmpty()) FocusAppsStore.setAllowed(ctx, ok)
    }

    fun Drawable.bmp() = runCatching { this.toBitmapCompat(48).asImageBitmap() }.getOrNull()
    fun save(list: List<String>) { selected = list; scope.launch { FocusAppsStore.setAllowed(ctx, list) } }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("التطبيقات المسموحة في الجلسة", style = MaterialTheme.typography.headlineSmall)
        Text("اختر تطبيقًا واحدًا أو تطبيقين (محاضرات / PDF / ملاحظات). رفيق مسموح دائمًا.")
        OutlinedTextField(value = q, onValueChange = { q = it }, modifier = Modifier.fillMaxWidth(),
            label = { Text("بحث عن تطبيق بالاسم…") })
        Text("المختار (${selected.size}/${FocusSelection.MAX_APPS}): " +
            (selected.joinToString("، ") { FocusAppsStore.labelOf(ctx, it) }.ifBlank { "لا شيء — رفيق فقط" }),
            color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        if (missing.isNotEmpty()) Text("⚠ أُزيل من الاختيار لأنه لم يعد مثبتًا أو قابلًا للتشغيل: ${missing.joinToString("، ")}",
            color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        if (notice.isNotBlank()) Text(notice, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        when {
            loading -> Column(Modifier.weight(1f).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                CircularProgressIndicator() }
            loadError -> Column(Modifier.weight(1f).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("تعذر قراءة قائمة التطبيقات — قيود نظام Android على رؤية التطبيقات.")
                TextButton(onClick = { refresh() }) { Text("إعادة المحاولة") } }
            apps.isEmpty() -> Column(Modifier.weight(1f).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("لم يُعثر على تطبيقات يمكن للنظام كشفها.") }
            else -> {
                val shown = apps.filter { it.launchable && (q.isBlank() || it.label.contains(q.trim(), ignoreCase = true)) }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (shown.isEmpty()) Text("لا نتائج مطابقة.")
                    shown.forEach { app ->
                        val isSel = app.pkg in selected
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                app.icon?.bmp()?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.size(36.dp)) }
                                Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                                    Text(app.label, style = MaterialTheme.typography.titleSmall)
                                    Text(app.pkg, style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Button(onClick = {
                                    val next = FocusSelection.toggle(selected, app.pkg)
                                    if (next == selected && !isSel) notice = "الحد الأقصى تطبيقان — أزل أحدهما أولًا."
                                    else { notice = ""; save(next) }
                                }) { Text(if (isSel) "إزالة" else "اختيار") }
                            }
                        }
                    }
                }
            }
        }
        OutlinedButton(onClick = { refresh() }, modifier = Modifier.fillMaxWidth()) { Text("🔄 تحديث القائمة") }
        OutlinedButton(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("رجوع") }
    }
}
