package com.rafiq6.study

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    // الجداول
    @Query("SELECT * FROM schedules ORDER BY importedAt DESC") fun schedules(): Flow<List<ScheduleEntity>>
    @Query("SELECT * FROM schedules WHERE active=1 LIMIT 1") fun activeSchedule(): Flow<ScheduleEntity?>
    @Query("SELECT * FROM schedules WHERE scheduleId=:scheduleId") suspend fun scheduleById(scheduleId: String): ScheduleEntity?
    @Query("SELECT COUNT(*) FROM schedules") suspend fun scheduleCount(): Int
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertSchedule(s: ScheduleEntity)
    @Query("UPDATE schedules SET active=0") suspend fun deactivateAllSchedules()
    @Query("UPDATE schedules SET active=1 WHERE scheduleId=:id") suspend fun activateSchedule(id: String)
    @Query("DELETE FROM schedules WHERE scheduleId=:id") suspend fun deleteSchedule(id: String)
    @Query("DELETE FROM schedule_tasks WHERE scheduleId=:scheduleId") suspend fun deleteTasks(scheduleId: String)
    @Query("DELETE FROM schedule_tasks") suspend fun clearTasksAll()
    @Query("DELETE FROM progress") suspend fun clearProgressAll()
    @Query("DELETE FROM reschedule_snapshots") suspend fun clearSnapshotsAll()
    @Query("DELETE FROM progress WHERE taskId IN (SELECT id FROM schedule_tasks WHERE scheduleId=:scheduleId)") suspend fun deleteProgressForSchedule(scheduleId: String)

    // المهام
    @Query("SELECT * FROM schedule_tasks") fun allTasks(): Flow<List<TaskEntity>>
    @Query("SELECT * FROM schedule_tasks WHERE scheduleId=:scheduleId ORDER BY date, COALESCE(startMin,9999), sourceId") fun tasksFor(scheduleId: String): Flow<List<TaskEntity>>
    @Query("SELECT * FROM schedule_tasks WHERE scheduleId=:scheduleId AND date=:d ORDER BY COALESCE(startMin,9999), sourceId") fun day(scheduleId: String, d: String): Flow<List<TaskEntity>>
    @Query("SELECT * FROM schedule_tasks WHERE id=:id") suspend fun byId(id: String): TaskEntity?
    @Query("SELECT * FROM schedule_tasks WHERE scheduleId=:scheduleId") suspend fun tasksForOnce(scheduleId: String): List<TaskEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertTask(t: TaskEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertTasks(l: List<TaskEntity>)

    // الإنجازات منفصلة عن الجدول
    @Query("SELECT * FROM progress") fun allProgress(): Flow<List<ProgressEntity>>
    @Query("SELECT * FROM progress WHERE taskId=:id") suspend fun progressById(id: String): ProgressEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertProgress(p: ProgressEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertProgress(l: List<ProgressEntity>)

    // لقطات إعادة الجدولة
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertSnapshot(s: RescheduleSnapshotEntity)
    @Query("SELECT * FROM reschedule_snapshots WHERE scheduleId=:scheduleId ORDER BY createdAt DESC LIMIT 1") suspend fun latestSnapshot(scheduleId: String): RescheduleSnapshotEntity?
    @Query("DELETE FROM reschedule_snapshots WHERE id=:id") suspend fun deleteSnapshot(id: String)

    @Transaction
    suspend fun replaceSchedule(schedule: ScheduleEntity, tasks: List<TaskEntity>, progress: List<ProgressEntity>) {
        deactivateAllSchedules()
        upsertSchedule(schedule.copy(active = true))
        deleteProgressForSchedule(schedule.scheduleId)
        deleteTasks(schedule.scheduleId)
        insertTasks(tasks)
        insertProgress(progress)
    }

    @Transaction
    suspend fun activateOnly(scheduleId: String) {
        deactivateAllSchedules()
        activateSchedule(scheduleId)
    }

    @Transaction
    suspend fun restoreCore(schedules: List<ScheduleEntity>, tasks: List<TaskEntity>, progress: List<ProgressEntity>) {
        clearSnapshotsAll(); clearProgressAll(); clearTasksAll()
        schedules.forEach { upsertSchedule(it.copy(active = false)) }
        schedules.lastOrNull()?.let { activateSchedule(it.scheduleId) }
        insertTasks(tasks)
        insertProgress(progress)
    }
}

@Dao
interface BankDao {
    @Query("SELECT * FROM pdf_documents ORDER BY importedAt DESC") fun documents(): Flow<List<PdfDocumentEntity>>
    @Query("SELECT * FROM pdf_documents WHERE id=:id") suspend fun documentById(id: String): PdfDocumentEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertDocument(d: PdfDocumentEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertPageTexts(l: List<PdfPageTextEntity>)
    @Query("SELECT * FROM pdf_page_texts WHERE documentId=:docId ORDER BY pageNumber") fun pagesFor(docId: String): Flow<List<PdfPageTextEntity>>

    @Query("SELECT * FROM questions ORDER BY updatedAt DESC") fun questions(): Flow<List<QuestionEntity>>
    @Query("SELECT * FROM questions WHERE documentId=:docId ORDER BY pageNumber, updatedAt DESC") fun questionsForDocument(docId: String): Flow<List<QuestionEntity>>
    @Query("SELECT * FROM questions WHERE id=:id") suspend fun questionById(id: String): QuestionEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertQuestion(q: QuestionEntity)
    @Query("DELETE FROM questions WHERE id=:id") suspend fun deleteQuestion(id: String)
    @Query("DELETE FROM pdf_page_texts WHERE documentId=:id") suspend fun deletePageTexts(id: String)
    @Query("DELETE FROM questions WHERE documentId=:id") suspend fun deleteQuestionsForDocument(id: String)
    @Query("DELETE FROM pdf_documents WHERE id=:id") suspend fun deleteDocumentRow(id: String)

    @Query("SELECT * FROM quiz_attempts ORDER BY startedAt DESC") fun attempts(): Flow<List<QuizAttemptEntity>>
    @Query("SELECT * FROM quiz_attempts WHERE status='ACTIVE' ORDER BY startedAt DESC LIMIT 1") suspend fun activeAttempt(): QuizAttemptEntity?
    @Query("SELECT * FROM quiz_attempts WHERE id=:id") suspend fun attemptById(id: String): QuizAttemptEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAttempt(a: QuizAttemptEntity)
    @Query("SELECT * FROM attempt_answers WHERE attemptId=:attemptId ORDER BY answeredAt") suspend fun answersForAttempt(attemptId: String): List<AttemptAnswerEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAnswer(a: AttemptAnswerEntity)
    @Query("SELECT * FROM attempt_answers") fun allAnswers(): Flow<List<AttemptAnswerEntity>>

    // بيانات النسخ الاحتياطي
    @Query("SELECT * FROM pdf_documents") suspend fun documentsOnce(): List<PdfDocumentEntity>
    @Query("SELECT * FROM pdf_page_texts") suspend fun pageTextsOnce(): List<PdfPageTextEntity>
    @Query("SELECT * FROM questions") suspend fun questionsOnce(): List<QuestionEntity>
    @Query("SELECT * FROM quiz_attempts") suspend fun attemptsOnce(): List<QuizAttemptEntity>
    @Query("SELECT * FROM attempt_answers") suspend fun answersOnce(): List<AttemptAnswerEntity>
    @Query("DELETE FROM pdf_documents") suspend fun clearDocuments()
    @Query("DELETE FROM pdf_page_texts") suspend fun clearPageTexts()
    @Query("DELETE FROM questions") suspend fun clearQuestions()
    @Query("DELETE FROM quiz_attempts") suspend fun clearAttempts()
    @Query("DELETE FROM attempt_answers") suspend fun clearAnswers()

    @Transaction
    suspend fun importDocument(document: PdfDocumentEntity, pages: List<PdfPageTextEntity>) {
        upsertDocument(document); insertPageTexts(pages)
    }

    @Transaction
    suspend fun deleteDocument(id: String) {
        deletePageTexts(id); deleteQuestionsForDocument(id); deleteDocumentRow(id)
    }

    @Transaction
    suspend fun restoreBank(documents: List<PdfDocumentEntity>, pages: List<PdfPageTextEntity>, questions: List<QuestionEntity>, attempts: List<QuizAttemptEntity>, answers: List<AttemptAnswerEntity>) {
        clearAnswers(); clearAttempts(); clearQuestions(); clearPageTexts(); clearDocuments()
        documents.forEach { upsertDocument(it) }
        insertPageTexts(pages)
        questions.forEach { upsertQuestion(it) }
        attempts.forEach { upsertAttempt(it) }
        answers.forEach { insertAnswer(it) }
    }
}

@Dao
interface ActivityDao {
    @Query("SELECT * FROM activities WHERE date=:d ORDER BY COALESCE(startMin,9999)") fun day(d: String): Flow<List<ActivityEntity>>
    @Query("SELECT * FROM activities ORDER BY date") fun all2(): Flow<List<ActivityEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(a: ActivityEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(l: List<ActivityEntity>)
    @Query("DELETE FROM activities WHERE id=:id") suspend fun delete(id: String)
    @Query("DELETE FROM activities") suspend fun clear()
}


@Dao
interface RestoreDao {
    @Query("DELETE FROM schedules") suspend fun clearSchedules()
    @Query("DELETE FROM schedule_tasks") suspend fun clearTasks()
    @Query("DELETE FROM progress") suspend fun clearProgress()
    @Query("DELETE FROM reschedule_snapshots") suspend fun clearSnapshots()
    @Query("DELETE FROM activities") suspend fun clearActivities()
    @Query("DELETE FROM pdf_documents") suspend fun clearDocuments()
    @Query("DELETE FROM pdf_page_texts") suspend fun clearPageTexts()
    @Query("DELETE FROM questions") suspend fun clearQuestions()
    @Query("DELETE FROM quiz_attempts") suspend fun clearAttempts()
    @Query("DELETE FROM attempt_answers") suspend fun clearAnswers()

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertSchedules(l: List<ScheduleEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertTasks(l: List<TaskEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertProgress(l: List<ProgressEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertActivities(l: List<ActivityEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertDocuments(l: List<PdfDocumentEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertPageTexts(l: List<PdfPageTextEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertQuestions(l: List<QuestionEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAttempts(l: List<QuizAttemptEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAnswers(l: List<AttemptAnswerEntity>)

    @Transaction
    suspend fun restoreAll(
        schedules: List<ScheduleEntity>, tasks: List<TaskEntity>, progress: List<ProgressEntity>,
        activities: List<ActivityEntity>, documents: List<PdfDocumentEntity>, pageTexts: List<PdfPageTextEntity>,
        questions: List<QuestionEntity>, attempts: List<QuizAttemptEntity>, answers: List<AttemptAnswerEntity>
    ) {
        clearAnswers(); clearAttempts(); clearQuestions(); clearPageTexts(); clearDocuments()
        clearActivities(); clearSnapshots(); clearProgress(); clearTasks(); clearSchedules()
        val activeId = schedules.firstOrNull { it.active }?.scheduleId ?: schedules.lastOrNull()?.scheduleId
        insertSchedules(schedules.map { it.copy(active = it.scheduleId == activeId) })
        insertTasks(tasks); insertProgress(progress); insertActivities(activities)
        insertDocuments(documents); insertPageTexts(pageTexts); insertQuestions(questions)
        insertAttempts(attempts); insertAnswers(answers)
    }
}

@Database(
    entities = [ScheduleEntity::class, TaskEntity::class, ProgressEntity::class, RescheduleSnapshotEntity::class, ActivityEntity::class, PdfDocumentEntity::class, PdfPageTextEntity::class, QuestionEntity::class, QuizAttemptEntity::class, AttemptAnswerEntity::class],
    version = 6,
    exportSchema = true
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): TaskDao
    abstract fun act(): ActivityDao
    abstract fun bank(): BankDao
    abstract fun restoreDao(): RestoreDao
    companion object {
        private val M1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS activities (id TEXT PRIMARY KEY NOT NULL, date TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, durationMin INTEGER NOT NULL, startMin INTEGER, done INTEGER NOT NULL, postponedFrom TEXT)")
            }
        }

        private val M2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS schedules (scheduleId TEXT PRIMARY KEY NOT NULL, name TEXT NOT NULL, studentAlias TEXT, stage TEXT, country TEXT, timeZone TEXT NOT NULL, startDate TEXT, endDate TEXT, importedAt INTEGER NOT NULL, active INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS schedule_tasks (id TEXT PRIMARY KEY NOT NULL, scheduleId TEXT NOT NULL, sourceId TEXT NOT NULL, date TEXT NOT NULL, dayName TEXT NOT NULL, subject TEXT NOT NULL, type TEXT NOT NULL, title TEXT NOT NULL, lectureNo INTEGER, durationMin INTEGER NOT NULL, startMin INTEGER, endMin INTEGER, flexible INTEGER NOT NULL, fixed INTEGER NOT NULL, notify INTEGER NOT NULL, note TEXT, originalDate TEXT, originalStartMin INTEGER, originalEndMin INTEGER, rescheduleReason TEXT, remindBeforeMin INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS progress (taskId TEXT PRIMARY KEY NOT NULL, done INTEGER NOT NULL, doneAt INTEGER, actualMin INTEGER)")
                db.execSQL("CREATE TABLE IF NOT EXISTS reschedule_snapshots (id TEXT PRIMARY KEY NOT NULL, scheduleId TEXT NOT NULL, createdAt INTEGER NOT NULL, reason TEXT NOT NULL, payload TEXT NOT NULL)")
                db.execSQL("INSERT OR IGNORE INTO schedules (scheduleId,name,studentAlias,stage,country,timeZone,startDate,endDate,importedAt,active) VALUES ('local-default','جدول رفيق الحالي',NULL,NULL,NULL,'Asia/Baghdad',NULL,NULL,${System.currentTimeMillis()},1)")
                db.execSQL("INSERT OR IGNORE INTO schedule_tasks (id,scheduleId,sourceId,date,dayName,subject,type,title,lectureNo,durationMin,startMin,endMin,flexible,fixed,notify,note,originalDate,originalStartMin,originalEndMin,rescheduleReason,remindBeforeMin) SELECT id,'local-default',id,date,dayName,subject,type,title,lectureNo,durationMin,startMin,endMin,flexible,0,1,note,date,startMin,endMin,NULL,15 FROM tasks")
                db.execSQL("INSERT OR IGNORE INTO progress (taskId,done,doneAt,actualMin) SELECT id,done,doneAt,actualMin FROM tasks")
                db.execSQL("UPDATE schedules SET startDate=(SELECT MIN(date) FROM schedule_tasks WHERE scheduleId='local-default'), endDate=(SELECT MAX(date) FROM schedule_tasks WHERE scheduleId='local-default') WHERE scheduleId='local-default'")
                db.execSQL("DROP TABLE IF EXISTS tasks")
            }
        }


        private val M3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS pdf_documents (id TEXT PRIMARY KEY NOT NULL, uri TEXT NOT NULL, displayName TEXT NOT NULL, pageCount INTEGER NOT NULL, textAvailable INTEGER NOT NULL, importWarning TEXT, importedAt INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS pdf_page_texts (documentId TEXT NOT NULL, pageNumber INTEGER NOT NULL, text TEXT NOT NULL, PRIMARY KEY(documentId, pageNumber))")
                db.execSQL("CREATE TABLE IF NOT EXISTS questions (id TEXT PRIMARY KEY NOT NULL, documentId TEXT NOT NULL, documentName TEXT NOT NULL, pageNumber INTEGER NOT NULL, subject TEXT NOT NULL, topic TEXT NOT NULL, question TEXT NOT NULL, correctAnswer TEXT, errorCount INTEGER NOT NULL, reviewStage INTEGER NOT NULL, nextReviewAt TEXT, lastResult TEXT, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS quiz_attempts (id TEXT PRIMARY KEY NOT NULL, subject TEXT, topic TEXT, total INTEGER NOT NULL, answered INTEGER NOT NULL, correct INTEGER NOT NULL, status TEXT NOT NULL, startedAt INTEGER NOT NULL, finishedAt INTEGER)")
                db.execSQL("CREATE TABLE IF NOT EXISTS attempt_answers (id TEXT PRIMARY KEY NOT NULL, attemptId TEXT NOT NULL, questionId TEXT NOT NULL, userAnswer TEXT NOT NULL, isCorrect INTEGER NOT NULL, answeredAt INTEGER NOT NULL, previousStage INTEGER NOT NULL, nextStage INTEGER NOT NULL, nextReviewAt TEXT)")
            }
        }

        // إضافة عمود البصمة فقط. لا حذف ولا إعادة إنشاء: كل الجداول والإنجازات الحالية تبقى كما هي.
        private val M4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE schedules ADD COLUMN contentHash TEXT")
            }
        }

        // إضافة عمود لقطة «توزيع الأسبوع» (أيام الراحة وأيام كل مادة) فقط — لا حذف ولا فقدان بيانات. الجداول
        // الحالية تبقى بقيمة NULL (بلا قيود محفوظة) فتسلك كما كانت قبل هذا التحديث في إعادة الجدولة التلقائية.
        private val M5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE schedules ADD COLUMN weekPlanJson TEXT")
            }
        }

        @Volatile private var I: AppDb? = null
        fun get(c: Context): AppDb = I ?: synchronized(this) {
            I ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "rafiq6.db")
                .addMigrations(M1_2, M2_3, M3_4, M4_5, M5_6)
                .build().also { I = it }
        }
        fun close() = synchronized(this) { I?.close(); I = null }
    }
}

object SeedImporter {
    suspend fun ensureDefault(ctx: Context, db: AppDb) {
        if (db.dao().scheduleCount() > 0) return
        val parsed = ScheduleParser.parse(ctx.assets.open("schedule.json").bufferedReader().readText())
        val file = parsed.file ?: throw IllegalStateException("ملف الجدول المدمج غير صالح:\n${parsed.errorText()}")
        val id = "local-default"
        val schedule = ScheduleEntity(
            scheduleId = id, name = file.meta.name, stage = "السادس العلمي",
            country = "العراق", timeZone = "Asia/Baghdad",
            startDate = file.startDate?.toString(), endDate = file.endDate?.toString(),
            active = true
        )
        db.dao().replaceSchedule(schedule, ScheduleParser.toEntities(id, file), emptyList())
    }
}
